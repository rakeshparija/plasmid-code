# Databricks notebook source

# COMMAND ----------

%sh
set -x
echo "version check"
libreoffice --version