%sh
#!/bin/bash
set -x

if [ ! -d "/Volumes/hub_mlops_dev/b_plasmid/b_plasmid_volume/init_script/libre_office/LibreOffice_25.2.5.2_Linux_x86-64_deb" ]; then
    wget https://download.documentfoundation.org/libreoffice/stable/25.2.5/deb/x86_64/LibreOffice_25.2.5_Linux_x86-64_deb.tar.gz --no-check-certificate
    tar xvzf "LibreOffice_25.2.5_Linux_x86-64_deb.tar.gz" -C "/Volumes/hub_mlops_dev/b_plasmid/b_plasmid_volume/init_script/libre_office/"
else
    echo "LibreOffice folder already exists, skipping download."
fi

cd /Volumes/hub_mlops_dev/b_plasmid/b_plasmid_volume/init_script/libre_office/LibreOffice_25.2.5.2_Linux_x86-64_deb/DEBS/
sudo dpkg -i *.deb
echo $PATH
sudo ln -s /opt/libreoffice25.2/program/soffice /usr/bin/libreoffice

echo "=== Checking spaCy installation ==="
if ! python -m spacy validate | grep -q "en_core_web_sm"; then
    echo "Installing spaCy and the en_core_web_sm model..."
    pip install --upgrade spacy==3.5.0 cymem==2.0.7
    python -m spacy download en_core_web_sm
else
    echo "spaCy model already installed."
fi
libreoffice --version
