import logging

def get_logger(name: str = __name__):
    logger = logging.getLogger(name)
    if not logger.handlers:  # Prevent adding multiple handlers
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()  # Logs will print to console
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.propagate = False  # Avoid double logging
    return logger
