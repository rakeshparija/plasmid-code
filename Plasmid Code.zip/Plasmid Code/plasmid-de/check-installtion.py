# Databricks notebook source
import subprocess
from logs.logger import get_logger
logger = get_logger()
# COMMAND ----------
def check_command(cmd, success_msg, fail_msg):
    """Run a shell command and print result."""
    try:
        result = subprocess.run(
            cmd, shell=True, check=True, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT
        )
        logger.info(f"{success_msg}")
        logger.info(result.stdout.strip())
    except subprocess.CalledProcessError as e:
        logger.error(f"{fail_msg}")
        logger.error(e.output)

# COMMAND ----------
# 1. Check libreoffice
check_command(
    "soffice --version",
    "LibreOffice is installed.",
    "LibreOffice is NOT installed."
)

# COMMAND ----------
# 2. Check poppler-utils (pdfinfo is a good test)
check_command(
    "pdftotext -v",
    "poppler-utils is installed.",
    "poppler-utils is NOT installed."
)

# COMMAND ----------
# 3. Check spaCy
check_command(
    "python -m spacy --version",
    "spaCy is installed.",
    "spaCy is NOT installed."
)