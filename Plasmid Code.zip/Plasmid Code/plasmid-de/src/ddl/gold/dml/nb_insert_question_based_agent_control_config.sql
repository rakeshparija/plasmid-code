INSERT INTO {{control_table}} VALUES 
-- Question 1: Forward expand BOM for given SKUs
('1', 'Find all components for the given SKUs', '1', '#sku_id', 
 'Use the bill of materials agent to forward expand the bill of materials for the provided SKU(s).', 
 'bom_agent', 
 'expand the bill of materials for the given SKU(s)', 
 """
  - This question is about finding components for one or more given SKUs.
  - In the question, SKUs may be referred to as 'SKU', 'product', 'finished good', 'medical device', or 'finished product'.
  - Components may be referred to as 'component', 'material', 'constituent', 'raisin', 'composition', or 'raw material'.
  - The user may provide SKU names, descriptions, or partial matches instead of exact SKUs.
  # Examples          
  - Give all components for SKU MZ1000
  - MZ1000 give all materials
  - Give all raw materials for MZ1000 and all finished products starting with 'MZ'
""", 'structured'),

-- Question 2: Reverse expand BOM for given components
('2', 'Find all SKUs that use given components', '1', '#component_id', 
 'Use the bill of materials agent to reverse expand the bill of materials for the provided component(s).', 
 'bom_agent', 
 'reverse expand the bill of materials for the given component(s)', 
 """
  - This question is about finding SKUs that use one or more given components.
  - Components may be referred to as 'component', 'material', 'constituent', 'raisin', 'composition', or 'raw material'.
  - SKUs may be referred to as 'SKU', 'product', 'finished good', 'medical device', or 'finished product'.
  - The user may provide component names, descriptions, or partial matches instead of exact component IDs.
  # Examples          
  - Give all SKUs that use MZ100 material
  - For MZ100, give all finished products
  - Find all products that use spike and stop cock
""", 'structured'),

-- Question 3: Search for SKUs by component features
('3', 'Find all SKUs that have one or more features', '1', '#component_desc', 
 'Use the component search agent to identify SKUs that match the provided feature descriptions.', 
 'component_search_agent', 
 'search for components matching the given description', 
 """
  - This question is about finding SKUs that have one or more specified features.
  - Features may be referred to as 'product feature', 'component feature', 'configuration', or 'keyword'.
  - SKUs may be referred to directly or identified via partial matches of SKU names or descriptions.
  # Examples          
  - Which SKUs and their components have the following features: spike, luer lock, stop cock
  - SKU keyword: starts with MZ
""", 'structured'),

-- Question 4: Find manufacturing site information for SKUs
('4', 'Give manufacturing site information for the given SKUs', '1', '#sku_id', 
 'Use the plant search agent to find plant(s) associated with the given SKU(s).', 
 'plant_search_agent', 
 'retrieve plant_id associated with the given SKU(s)', 
 """
  - This question is about identifying manufacturing sites for specified SKUs.
  - SKUs may be referred to as 'SKU', 'product', 'finished good', 'medical device', or 'finished product'.
  - The user may also refer to products indirectly via keywords or descriptions.
  # Examples:
  - Give me manufacturing site information for MZ1000
  - Give me manufacturing site information for luer lock, medicine delivery system
""", 'structured'),

-- Question 5: Find SKUs manufactured in a plant
('5', 'Give a list of SKUs/products/components/materials/SKU IDs/SKU names that are manufactured in the provided plant ID/plant name/location/manufacturing site', '1', '#plant_name', 
 'Use the plant search agent to find SKUs associated with the given plant.', 
 'plant_search_agent', 
 'retrieve SKUs associated with the given plant', 
 """
  - This question is about finding SKUs manufactured in a specific plant.
  - Plants may be referred to by name, ID, location, or manufacturing site.
  # Examples:
  - Give me SKU information for plant: xyz (name)
""", 'structured'),

-- Question 6: Multi-step retrieval of design verification data for SKU and requirement
('6', 'For a given SKU find design verification data for given particular test', '1', '#sku_id, #requirement', 
 'Use the bill of materials agent to forward expand the bill of materials for the provided SKU(s).', 
 'bom_agent', 
 'expand the bill of materials for the given SKU(s)', 
 'This question asks for design verification data (i.e., the results, evidence, documentation generated during verification activities, etc) associated with a specific test/requirement for a particular SKU and its related components. The focus is on retrieving the test outcome details and verification evidence, not issues or deviations.', 'unstructured'),

('6', 'For a given SKU find design verification data for given particular test', '2', '#sku_id', 
 'Use the metadata filtering agent to extract DIRs associated with SKUs/components expanded in step-1 ', 
 'metadata_filtering_agent', 
 'extract DIRs using metadata filtering for SKU and components from step-1', 
 'This question asks for design verification data (i.e., the results, evidence, documentation generated during verification activities, etc) associated with a specific test/requirement for a particular SKU and its related components. The focus is on retrieving the test outcome details and verification evidence, not issues or deviations.', 'unstructured'),

('6', 'For a given SKU find design verification data for given particular test', '3', '#dir_number', 
 'Use the RAG agent to perform an exact keyword match using the specified requirement within the identified DIRs in step-2.', 
 'rag_agent', 
 'perform exact keyword search in DIRs using RAG from step-2', 
 'This question asks for design verification data (i.e., the results, evidence, documentation generated during verification activities, etc) associated with a specific test/requirement for a particular SKU and its related components. The focus is on retrieving the test outcome details and verification evidence, not issues or deviations.', 'unstructured'),

-- Question 7: Multi-step retrieval of deviations in design verification for SKU
('7', 'For a given SKU find deviations recorded during design verification', '1', '#sku_id', 
 'Use the bill of materials agent to forward expand the bill of materials for the provided SKU(s).', 
 'bom_agent', 
 'expand the bill of materials for the given SKU(s)', 
 'This question asks for deviations (i.e., non-conformities, failures, exceptions, etc) that were recorded during the design verification process for a specific SKU and its related components. The focus is on retrieving records of deviations or anomalies. It may also talk only about defects, defect records, failures, and deviations.', 'unstructured'),

('7', 'For a given SKU find deviations recorded during design verification', '2', '#sku_id', 
 'Use the expanded SKUs/components to extract associated DIRs using metadata filtering from step-1.', 
 'metadata_filtering_agent', 
 'extract DIRs using metadata filtering for SKU and components from step-1', 
 'This question asks for deviations (i.e., non-conformities, failures, exceptions, etc) that were recorded during the design verification process for a specific SKU and its related components. The focus is on retrieving records of deviations or anomalies. It may also talk only about defects, defect records, failures, and deviations.', 'unstructured'),

('7', 'For a given SKU find deviations recorded during design verification', '3', '#dir_number', 
 'Use the RAG agent to search DIRs obtained from step-2 for documents that mention deviations and related functional specifications.', 
 'rag_agent', 
 'search DIRs using RAG for deviations and associated requirements from step-2', 
 'This question asks for deviations (i.e., non-conformities, failures, exceptions, etc) that were recorded during the design verification process for a specific SKU and its related components. The focus is on retrieving records of deviations or anomalies. It may also talk only about defects, defect records, failures, and deviations.', 'unstructured'),

 -- Question 10: Exact match of keyword for SKU
('10', 'For a given SKU find all documents containing keyword', '1', '#sku_id', 
 'Use the bill of materials agent to forward expand bill of materials for material (obtain SKUs/parents)', 
 'bom_agent', 
 'expand bill of materials for the given SKUs', 
 'This question is about retrieving information that exactly matches a keyword in documents related to a given SKU. It involves exploding the bill of materials (BOM) for the SKU to identify all relevant components.', 'unstructured'),

('10', 'For a given SKU find all documents containing keyword', '2', '#sku_id', 
 'Use metadata filtering to extract all DIRs (Design Input Records) associated with the given SKU and its expanded components from step-1.', 
 'metadata_filtering_agent', 
 'extract DIRs using metadata filtering for SKU and components', 
 'This question is about retrieving information that exactly matches a keyword in documents related to a given SKU. It involves exploding the bill of materials (BOM) for the SKU to identify all relevant components.', 'unstructured'),

('10', 'For a given SKU find all documents containing keyword', '3', '#dir_number', 
 'Use the RAG agent to perform an exact keyword match in the DIRs using the user-provided keyword.', 
 'rag_agent', 
 'perform exact keyword search in DIRs using RAG', 
 'This question is about retrieving information that exactly matches a keyword in documents related to a given SKU. It involves exploding the bill of materials (BOM) for the SKU to identify all relevant components.', 'unstructured'),

-- Question 8: Find recent changes for a SKU
('8', 'Find changes to given SKU in last X years', '1', '#sku_id', 
 'Use the bill of materials agent to forward expand bill of materials for material (obtain SKUs/parents)', 
 'bom_agent', 
 'expand bill of materials for the given SKUs', 
 'This question is about finding recent changes (e.g., engineering change requests/orders) for a given SKU. It involves exploding the bill of materials (BOM) for the SKU to identify all related components.', 'unstructured'),

('8', 'Find changes to given SKU in last X years', '2', '#sku_id', 
 'Use metadata filtering agent to extract ECROs (Engineering Change Request/Orders) associated with the given SKU and its expanded components from step-1, filtered by recency (e.g., last X years).', 
 'metadata_filtering_agent', 
 'extract recent ECROs using metadata filtering for SKU and components', 
 'This question is about finding recent changes (e.g., engineering change requests/orders) for a given SKU. It involves exploding the bill of materials (BOM) for the SKU to identify all related components.', 'unstructured'),

 -- Question 9: Find SKUs where packaging material was changed
('9', 'Find SKUs that were impacted due to changes in keyword', '1', '#ecro_description', 
 'Use metadata filtering agent to extract ECROs (Engineering Change Request/Orders), ECROs description, DIR numbers, materials IDs for a given feature and keyword from step-0 to match the ECRO description',
 'metadata_filtering_agent',
 'extract ECROs, DIR numbers, materials IDs for a given change from ECRO description keyword matching',
 'This question is about finding SKUs for which the given feature/keyword was changed or modified.', 'unstructured'),

('9', 'Find SKUs that were impacted due to changes in keyword', '2', '#ecro_description',
 'Use RAG agent to extract DIR numbers linked to the specified keyword/feature from step-0 to match the ECRO description',
 'rag_agent',
 'extract DIRs using RAG for a given feature and keyword matching from ECRO description',
 'This question is about finding SKUs for which the given feature/keyword was changed or modified.', 'unstructured'),
 
('9', 'Find SKUs that were impacted due to changes in keyword', '3', '#dir_number',
 'Use metadata filtering agent to extract ECROs (Engineering Change Request/Orders), ECROs description, DIR numbers, material IDs that are associated with DIR numbers retrieved in step-2',
 'metadata_filtering_agent',
 'extract ECROs, ECROs description, DIR numbers, material IDs associated with the DIR numbers',
 'This question is about finding SKUs for which the given feature/keyword was changed or modified.', 'unstructured'),

('9', 'Find SKUs that were impacted due to changes in keyword', '4', '#dir_number',
 "['Use logical agent to find the union of the ECROs, ECROs description, DIR numbers, material IDs extracted in step-1 and the ECROs, ECROs description, DIR numbers, material IDs extracted in step-3',
        {'Agent': 'metadata_filtering_agent', 'Step': 'step1'},
        {'Agent': 'metadata_filtering_agent', 'Step': 'step3'},
        {'Operation': 'Union'}]",
 'logical_agent',
 'extract ECROs, ECROs description, DIR numbers, material IDs associated with the given feature, combining two previous steps',
 'This question is about finding SKUs for which the given feature/keyword was changed or modified.', 'unstructured'),

('11', 'Unknown', '', '','','','','','unstructured'),
 
('12', 'Invalid', '', '','','','','','unstructured');