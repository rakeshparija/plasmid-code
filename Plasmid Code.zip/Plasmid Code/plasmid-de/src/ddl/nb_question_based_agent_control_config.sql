CREATE OR REPLACE TABLE {{control_table}} (
  number STRING,
  question STRING,
  step_number STRING,
  input STRING,
  instruction STRING,
  agent STRING,
  step_description STRING,
  question_description STRING,
  question_category STRING)
USING delta
TBLPROPERTIES (
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.deletionVectors' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');
