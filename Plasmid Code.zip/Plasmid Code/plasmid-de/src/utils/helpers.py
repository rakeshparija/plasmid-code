import yaml
import json
import os
import os.path
from pyspark.dbutils import DBUtils
import mlflow
import mlflow.sklearn
import pandas as pd
from io import StringIO
from azure.storage.blob import BlobServiceClient
from datetime import datetime
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, LongType, FloatType, DoubleType, StructType, StructField
import re
from logs.logger import get_logger
logger = get_logger()
 
 
def remove_invalid_characters(df):
    # Define a regular expression pattern to match invalid characters
    pattern = r'[ ,;{}()\n\t=]'
    # Remove invalid characters from column names
    new_columns = [re.sub(pattern, '', col) for col in df.columns]
    # Rename the columns with the cleaned names
    df = df.toDF(*new_columns)
    return df
 
def get_file_content(container,filename,sheet_name=None,is_excel=False):
    str_stream=container.get_blob_client(filename).download_blob().readall()
    return pd.read_csv(StringIO(str_stream.decode('utf-8'))) if not is_excel else \
        pd.read_excel(StringIO(str_stream.decode('utf-8')))
 
def rename_daily_data_files(daily_data_dir, azure_container, catalog_name):
    """
    Rename the daily data files in the `daily_data_dir` appropriately to be used during daily batch prediction
    based on the list of columns present in each file
 
    Parameters:
    ----------
    daily_data_dir : str
        Path containing the csv files for the daily batch prediction.
    Returns:
    -------
    None
    """
 
    try:
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
    except ImportError:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
   
    with open(os.path.join(daily_data_dir,'cols_dict.json')) as f:
        cols_dict_str_keys = json.load(f)
 
    cols_dict = {eval(k): v for k,v in cols_dict_str_keys.items()}
    logger.info("Fetching connection string...")
    connection_string = read_secret("AZURE-CONNECTION-STRING")
    logger.info(f"Connection string fetched: {connection_string is not None}")
 
 
    # Define the connection string, container name, and blob name
    # connection_string = read_secret("AZURE-CONNECTION-STRING")
 
   
    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        logger.info("Blob service client initialized.")
       
        # Check if the container name is correct
        logger.info(f"Azure container name: {azure_container}")
        container_client = blob_service_client.get_container_client(azure_container)
       
        # Check if the container client is working
        logger.info(f"Attempting to access container: {azure_container}")
        blob_list = container_client.list_blobs(name_starts_with="daily_data")
        logger.info("Successfully accessed container. Listing blobs...")
 
        logger.info('Renaming data files...')
        for blob in blob_list:
            blob_name = blob.name
            logger.info(f"Processing blob: {blob_name}")
           
            if blob_name.endswith('.csv'):
                df = get_file_content(container_client, blob_name)
                logger.info(f"File content retrieved for: {blob_name}")
               
                cols = tuple(df.columns)
                logger.info(f"Columns found: {cols}")
               
                new_file_name = cols_dict.get(cols, f"default_{blob_name}")
                logger.info(f"New file name: {new_file_name}")
               
                spark_table = f"{new_file_name.replace('.csv', '')}"
                logger.info(f"Spark table name: {spark_table}")
               
                df_spark = spark.createDataFrame(rename_cols_spark(df))
                logger.info(f"Dataframe for {blob_name} successfully converted to Spark DataFrame.")
               
                upload_date = datetime.now().strftime('%m-%d-%Y')
                df_spark = df_spark.withColumn('upload_date', F.lit(upload_date))
                logger.info(f"Upload date added: {upload_date}")
               
                save_to_delta(df_spark, spark_table, catalog_name, overwrite=False)
                logger.info(f"Saved to Delta table: {spark_table}")
               
                df.to_csv(os.path.join(daily_data_dir, new_file_name))
                logger.info(f"File saved locally: {new_file_name}")
           
    except Exception as e:
        logger.error(f"An error occurred: {e}")
 
 
 
    # blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    # container_client = blob_service_client.get_container_client(azure_container)
    # blob_list=container_client.list_blobs(name_starts_with="daily_data")
 
    # print('Renaming data files...')
    # for blob in blob_list:
    #     blob_name=blob.name
    #     if blob_name.endswith('.csv'):
    #         df=get_file_content(container_client,blob_name)
    #         cols=tuple(df.columns)
    #         new_file_name = cols_dict[cols]
    #         spark_table = f"{new_file_name.replace('.csv','')}"
    #         print(blob_name,new_file_name)
    #         df_spark=spark.createDataFrame(rename_cols_spark(df))
    #         upload_date = (datetime.now()).strftime('%m-%d-%Y')
    #         df_spark=df_spark.withColumn('upload_date',F.lit(upload_date))
    #         save_to_delta(df_spark, spark_table, catalog_name, overwrite=False)
    #         df.to_csv(os.path.join(daily_data_dir,new_file_name))
 
def pandas_to_spark_with_schema(df):
    """
    Convert a pandas dataframe to a spark dataframe with a specific schema
 
    Parameters:
    ----------
    df : pd.DataFrame
       
    Returns:
    -------
    Spark Dataframe
    """
    pandas_df = df.copy()
    pandas_df.columns = [c.replace(' ', '_').replace('.', '').replace('-', '_').replace('/', '_') for c in pandas_df.columns]
    dtype_mapping = {
        'object':StringType(),
        'datetime64[ns]':StringType(),
        'datetime64':StringType(),
        'int64':LongType(),
        'float64':DoubleType()
    }
    schema=StructType([
        StructField(col,dtype_mapping.get(str(pandas_df[col].dtype),StringType()),True) for col in pandas_df.columns
    ])
 
    try:
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
    except ImportError:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
 
    return spark.createDataFrame(pandas_df, schema)
 
def rename_cols_spark(df):
    """
    Rename the columns in a pandas dataframe so that spaces, . and hyphens are converted to underscores
 
    Parameters:
    ----------
    df : pd.DataFrame
   
    Returns:
    -------
    Renamed pandas dataframe
    """
    df_copy=df.copy()
    df_copy.columns = [c.replace(' ', '_').replace('.', '').replace('-', '_').replace('/', '_') for c in df_copy.columns]
    return df_copy
 
 
def rename_cols_pandas(df):
    """
    Reverse the operation of rename_cols_spark
 
    Parameters:
    ----------
    df : pd.DataFrame
   
    Returns:
    -------
    Renamed pandas dataframe
    """
    df_copy=df.copy()
    df_copy = df_copy.rename(columns={
        'Case_Number':'Case Number',
        'Product_Business':'Product Business',
        'Date_Time_Opened':'Date/Time Opened',
        'Model_Run_Date':'Model Run Date',
        'Model_Run_Time':'Model Run Time',
        'AI_Tag':'AI Tag',
        'SMAX_Tag':'SMAX Tag',
        'Flag_for_Review':'Flag for Review',
        'Feedback_Comments':'Feedback/Comments',
        'Reasons_For_Changing_AI_Tag':'Reasons For Changing AI Tag',
        'Feedback_Comments_Updated_On':'Feedback/Comments Updated On'
    })
    return df_copy
 
 
def save_to_delta(df,table_name, catalog_name, overwrite=True):
    """
    Save the contents of a Spark Dataframe into a Delta table (can either append or overwrite)
 
    Parameters:
    ----------
    df : Spark Dataframe
    table_name: str
        Name of the table
    catalog_name: str
        Name of the catalog/database
    overwrite: Boolean (optional)
        This flag specifies if the table should be overwritten or appended
   
    Returns:
    -------
    None
    """
    if overwrite:
        df.write \
        .format("delta") \
        .mode('overwrite') \
        .option("overwriteSchema", "true") \
        .saveAsTable(f"{catalog_name}.{table_name}")
    else:
        logger.info(f"Appendig data to Delta table {catalog_name}.{table_name}")
        df.write \
        .format("delta") \
        .mode('append') \
        .saveAsTable(f"{catalog_name}.{table_name}")
 
def delete_data_from_delta(table_name: str, catalog_name: str, column_name: str, values_to_delete: list):
    """
    Delete data from a Delta table in Unity Catalog.
 
    Args:
        table_full_name (str): Full name of the table in format 'catalog.schema.table_name'.
        df (DataFrame): Spark DataFrame to save.
        mode (str): Save mode ('overwrite' or 'append'). Default is 'overwrite'.
    """
    try:
        table_full_name = f"{catalog_name}.{table_name}"
        # Convert the list to a string format suitable for SQL IN clause
        values_str = ', '.join([f"'{value}'" for value in values_to_delete])
       
        # Construct the SQL query to delete rows
        delete_query = f"""DELETE FROM {table_full_name} WHERE {column_name} IN ({values_str})"""
        logger.info(delete_query)
        # Execute the delete query
        spark.sql(delete_query)
    except Exception as e:
        logger.error(f"Error deleting data to Delta table {table_full_name}: {e}")
 
 
def read_config(config_file='config.yml'):
    """
    Reads and returns the configuration from a YAML file.
 
 
    This function reads a YAML configuration file specified by `config_file` and returns its content as a dictionary.
    The default file name is 'config.yml', but you can specify a different file if needed.
 
 
    Args:
        config_file (str): The name of the YAML configuration file to read. Default is 'config.yml'.
 
 
    Returns:
        dict: A dictionary containing the configuration settings from the YAML file.
 
 
    Raises:
        FileNotFoundError: If the specified configuration file does not exist at the determined path.
        yaml.YAMLError: If the YAML file is invalid or cannot be parsed.
 
 
    Usage:
        config = read_config('path/to/config.yml')
        print(config)
    """
    logger.info(f"config_file - {config_file}")
    config_path = get_root_dir(config_file)
    logger.info(f"config_path - {config_path}")
    with open(config_path, "r") as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
   
    # environment = get_env()
    # env_vars = {'environment': environment}
    # config = recursive_replace(config, env_vars)
    return config
 
 
def get_root_dir(filename='config.yml', start_directory=os.getcwd()):
    """
    Recursively searches for a file starting from the current directory and moving up the directory tree.
 
 
    This function starts from `start_directory` and looks for the specified file (`filename`). If the file is not found,
    it moves up to the parent directory and continues the search. The search stops when the root directory is reached.
 
 
    Args:
        filename (str): The name of the file to search for. Default is 'config.yml'.
        start_directory (str): The directory from which the search begins. Default is the current working directory.
 
 
    Returns:
        str: The full path to the file if found. Returns None if the file is not found in the directory tree.
 
 
    Usage:
        file_path = get_root_dir('config.yml')
        if file_path:
            print(f"File found: {file_path}")
        else:
            print("File not found")
    """
    from pyspark.dbutils import DBUtils
    try:
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
    except ImportError:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
 
    dbutils = DBUtils(spark)
   
    start_directory = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath()
    start_directory = str(start_directory).replace('Some(','/Workspace')
    current_dir = start_directory
 
    # Iterate over directories starting from current directory and going up
    while True:
        file_path = os.path.join(current_dir, filename)
 
        if os.path.isfile(file_path):
            return file_path  # Found the file, return its full path
 
        # Move up to the parent directory
        parent_dir = os.path.dirname(current_dir)
       
        # Check if reached the root directory (on Unix-like systems '/')
        if parent_dir == current_dir:
            logger.info("file not found")
            return None  # File not found
 
 
        # Update current directory to parent directory
        current_dir = parent_dir
 
def replace_placeholders(value, env_vars):
    # Check if the value is a string and contains placeholders
    PLACEHOLDER_PATTERN = re.compile(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\}')
    if isinstance(value, str):
        matches = PLACEHOLDER_PATTERN.findall(value)
        for match in matches:
            # Replace placeholder with corresponding environment variable
            value = value.replace(f"${{{match}}}", env_vars.get(match, f"<{match}_NOT_SET>"))
    return value
 
def recursive_replace(config, env_vars):
    if isinstance(config, dict):
        return {k: recursive_replace(v, env_vars) for k, v in config.items()}
    elif isinstance(config, list):
        return [recursive_replace(i, env_vars) for i in config]
    else:
        return replace_placeholders(config, env_vars)
 
from pyspark.sql import SparkSession
def get_spark_instance():
    # This method returns a SparkSession instance. If it doesn't exist, it creates a new one.
    if 'spark' not in globals():
        logger.info("Creating new SparkSession")
        global spark
        spark = SparkSession.builder \
            .appName("Classification") \
            .getOrCreate()
    return spark
 
spark = get_spark_instance()
 
def get_env():
    config=read_config()
    return(config['env'])
 
def update_config(key: str, value, config_file='config.yml'):
    """
    Updates a specific key-value pair in the configuration file.
 
 
    This function reads the configuration file specified by `config_file`, updates the specified key with the new value,
    and writes the updated configuration back to the file.
 
 
    Args:
        key (str): The key to update in the configuration file.
        value: The new value to set for the specified key.
        config_file (str): The name of the configuration file to update. Default is 'config.yml'.
 
 
    Raises:
        FileNotFoundError: If the configuration file does not exist at the determined path.
        yaml.YAMLError: If the YAML file is invalid or cannot be parsed.
        IOError: If there is an issue writing to the configuration file.
 
 
    Usage:
        update_config('new_key', 'new_value', 'path/to/config.yml')
        print("Configuration updated successfully.")
    """
    config_path = get_root_dir(config_file)
    logger.info(config_path)
    logger.info(f'key {key}, value - {value}')
    with open(config_path, "r") as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
        logger.info(config)
    config[key] = value
 
 
    with open(config_path, "w") as f:
        yaml.dump(config, f)
 
 
    logger.info(f"Config file '{config_path}' updated successfully.")
 
 
 
 
def get_current_mlflow_run_id():
    """
    Retrieves the current MLflow run ID from Databricks task values.
 
 
    This function initializes a Spark session, uses Databricks utilities to fetch the MLflow run ID associated with a
    specific task key ('pre_execution'). If the MLflow run ID is not found, it returns None.
 
 
    Returns:
        str or None: The MLflow run ID if found, otherwise None.
 
 
    Usage:
        mlflow_run_id = get_current_mlflow_run_id()
        if mlflow_run_id:
            print(f"MLflow Run ID: {mlflow_run_id}")
        else:
            print("MLflow Run ID not found")
    """
    try:
        # Try to import and initialize DatabricksSession
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
    except ImportError:
        # Fallback to SparkSession if DatabricksSession is not available
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
 
 
    # Initialize DBUtils
    dbutils = DBUtils(spark)
 
 
    # Fetch the MLflow run ID from task values
    mlflow_run_id = dbutils.jobs.taskValues.get(
        taskKey='pre_execution',
        key='mlflow_run_id',
        default='None',
        debugValue='manual'
    )
 
 
    # Return None if the MLflow run ID is not found
    if mlflow_run_id == 'None':
        return None
 
 
    return mlflow_run_id
 
 
 
 
def read_secret(secret_name):
    """
    Retrieves a secret from a specified secret scope.
 
 
    This function reads the secret scope from the configuration file and uses Databricks utilities to fetch the value
    of the specified secret from that scope. If the secret scope or secret name is invalid, the function handles errors
    and returns None.
 
 
    Args:
        secret_name (str): The name of the secret to retrieve.
 
 
    Returns:
        str: The value of the retrieved secret, or None if an error occurs.
 
 
    Raises:
        KeyError: If 'secret_scope' is not found in the configuration.
        Exception: If there is an issue reading the secret from Databricks.
 
 
    Usage:
        secret_value = read_secret('my_secret')
        if secret_value:
            print(f"Secret Value: {secret_value}")
        else:
            print("Failed to retrieve secret")
    """
    # Store config.yml as a dictionary
    config = read_config()
 
    try:
        # Try to import and initialize DatabricksSession
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
    except ImportError:
        # Fallback to SparkSession if DatabricksSession is not available
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
 
 
    # Initialize DBUtils
    dbutils = DBUtils(spark)
 
 
    # Extract the secret_scope from the config
    secret_scope = config.get('secret_scope', None)
   
    # If secret_scope is not found, return None
    if not secret_scope:
        logger.info("Error: 'secret_scope' not found in config.")
        return None
 
 
    # Read and return secret value, return None if Error
    try:
        return dbutils.secrets.get(scope=secret_scope, key=secret_name)
    except Exception as e:
        logger.error(f"Error reading secret {secret_name} from scope {secret_scope}: {str(e)}")
        return None
 
 
 
 
def get_storage_output_path():
    """
    Determines the storage output path based on the current job run ID.
 
 
    This function reads the configuration to obtain the output storage path and uses Databricks utilities to get the
    current job run ID. It then constructs the storage output path accordingly and creates the necessary directories
    in the file system.
 
 
    Returns:
        str: The storage output path.
 
 
    Raises:
        KeyError: If 'output_storage_path' is not found in the configuration.
        Exception: If there is an issue creating directories in the file system.
 
 
    Usage:
        storage_path = get_storage_output_path()
        print(f"Storage Output Path: {storage_path}")
    """
    # Read the configuration
    config = read_config()
 
 
    try:
        # Try to import and initialize DatabricksSession
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
    except ImportError:
        # Fallback to SparkSession if DatabricksSession is not available
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
 
    # Initialize DBUtils
    dbutils = DBUtils(spark)
 
 
    # Get the current job context details in JSON format
    details = dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()
    details_json = json.loads(details)
    current_job_run_id = details_json['tags']['jobRunId']
 
 
    # Determine the storage output path based on the job run ID
    if current_job_run_id is not None:
        storage_output_path = f"/Volumes/{config['mlops_catalog']}/{config['mlops_s_schema']}/{config['mlops_s_volume']}/{config['output_storage_path']}/{current_job_run_id}"
        file_path = f"/Volumes/{config['mlops_catalog']}/{config['mlops_s_schema']}/{config['mlops_s_volume']}/{config['output_storage_path']}".split('/', 1)[1]
        # dbutils.fs.mkdirs(f"{file_path}/{current_job_run_id}")
    else:
 
 
 
 
        storage_output_path = f"/Volumes/{config['mlops_catalog']}/{config['mlops_s_schema']}/{config['mlops_s_volume']}/{config['output_storage_path']}/manual"
        file_path = f"/Volumes/{config['mlops_catalog']}/{config['mlops_s_schema']}/{config['mlops_s_volume']}/{config['output_storage_path']}".split('/', 1)[1]
        # dbutils.fs.mkdirs(f"{file_path}/manual")
 
    return storage_output_path
 
 
def load_mlflow_model(model_name):
    """
    Loads a logged model from MLflow.
 
    This function retrieves the latest version of the model specified by `model_name` from MLflow and loads it using
    MLflow's model loading functions. The model name must correspond to a model registered in MLflow.
 
    Args:
        model_name (str): The name of the model stored in MLflow.
 
    Returns:
        object: The loaded model object.
 
    Raises:
        mlflow.exceptions.MlflowException: If there is an issue retrieving the model or its version.
        KeyError: If the model name does not exist or the version cannot be retrieved.
 
    Usage:
        model = load_mlflow_model('my_model_name')
        # Use the loaded model for predictions or further processing
    """
    # Retrieve the latest version of the model
    client = mlflow.tracking.MlflowClient()
    latest_version_info = client.get_latest_versions(model_name,stages=["Production"])[0]
    latest_version = latest_version_info.version
 
    # Load the latest version of the model logged in MLflow
    model_uri = f"models:/{model_name}/{latest_version}"
    logger.info("model_uri: ", model_uri)
    model = mlflow.sklearn.load_model(model_uri)
 
    # Return the loaded model
    return model
 
def get_current_workflow_run_id():
    """
    Retrieves the current workflow job run ID from Databricks task values.
 
 
    This function initializes a Spark session, uses Databricks utilities to fetch the MLflow run ID associated with a
    specific task key ('pre_execution'). If the workflow run ID is not found, it returns None.
 
 
    Returns:
        str or None: The Current job run ID if found, otherwise None.
 
 
    Usage:
        current_job_run_id = get_current_workflow_run_id()
        if current_job_run_id:
            print(f"current_job_run_id Run ID: {current_job_run_id}")
        else:
            print("Running manually Run ID not found")
    """
    try:
        # Try to import and initialize DatabricksSession
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
    except ImportError:
        # Fallback to SparkSession if DatabricksSession is not available
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
 
 
    # Initialize DBUtils
    dbutils = DBUtils(spark)
 
 
    # Fetch the MLflow run ID from task values
    current_job_run_id = dbutils.jobs.taskValues.get(
        taskKey='pre_execution',
        key='current_job_run_id',
        default='None',
        debugValue='manual'
    )
 
    # Return None if the MLflow run ID is not found
    if current_job_run_id == 'None':
        return None
 
    return current_job_run_id
 
 