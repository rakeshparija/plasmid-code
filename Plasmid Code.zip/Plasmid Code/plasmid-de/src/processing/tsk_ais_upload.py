1  from concurrent.futures import ThreadPoolExecutor, as_completed
2  from pyspark.sql.functions import regexp_replace
3  from azure.search.documents import SearchClient
4  from azure.core.credentials import AzureKeyCredential
5  from pyspark.dbutils import DBUtils
6  import time
7  import re
8  
9  from logs.logger import get_logger
10 
11 logger = get_logger()
12 
13 def run_ais_upload(spark, config):
14     try:
15 
16         catalog = config['TARGET_CATALOG']
17         schema = config['SILVER_SCHEMA']
18         input_table = config['TARGET_TABLE_NAME_EMBEDDING_DETAILS']
19         keyvault_scope = config['KEYVAULT_SCOPE']
20         dbutils = DBUtils(spark)
21         search_endpoint = dbutils.secrets.get(scope=keyvault_scope, key="AZURE-SEARCH-ENDPOINT")
22         search_api_key = dbutils.secrets.get(scope=keyvault_scope, key="AZURE-SEARCH-KEY")
23         index_name = config['SEARCH_INDEX_NAME']
24 
25         search_client = SearchClient(
26             endpoint=search_endpoint,
27             index_name=index_name,
28             credential=AzureKeyCredential(search_api_key)
29         )
30 
31         i = 0
32         while True:
33             # Fetch records & clean text in Spark (much faster than Python loop)
34             df = (
35                 spark.sql(f"""
36                     SELECT Id AS id, DirNumber as dir_number, TextType as text_type, 
37                            Text as text, Vector as vector, Source as source, 
38                            OriginalFileName as original_file_name, 
39                            BusinessUnit as business_unit, PageNumber as page_number
40                     FROM {catalog}.{schema}.{input_table}
41                     WHERE Source = 'Everest' AND IsAisUpload = 'no' AND Error = ''
42                     LIMIT 20000
43                 """)
44                 .withColumn("text", regexp_replace("text", r"{2,}|_{2,}|[-]{2,}", ''))
45                 .withColumnRenamed("original_file_name", "doc_name")
46             )
47 
48             documents = [row.asDict() for row in df.toLocalIterator()]
49 
50             if len(documents) == 0:
51                 logger.info("No new records to upload.")
52                 break
53 
54             # Helper for batching
55             def chunked(iterable, size):
56                 for i in range(0, len(iterable), size):
57                     yield iterable[i:i+size]
58 
59             successful_documents = []
60 
61             # Parallel batch uploads
62             def upload_batch(batch):
63                 try:
64                     results = search_client.upload_documents(documents=batch)
65                     return [doc for doc, result in zip(batch, results) if result.succeeded]
66                 except Exception as e:
67                     logger.error(f"Batch upload failed: {e}")
68                     return []
69 
70             logger.info(f"Started uploading records to AI search for iteration-{i}")
71 
72             with ThreadPoolExecutor(max_workers=5) as executor:  # tune threads based on CPU/network
73                 futures = [executor.submit(upload_batch, batch) for batch in chunked(documents, 100)]
74                 for f in as_completed(futures):
75                     successful_documents.extend(f.result())
76 
77             logger.info(f"Completed uploading records to AI search for iteration-{i}, success={len(successful_documents)}")
78 
79             if successful_documents:
80                 # Instead of IN (...), use temp DataFrame for faster update
81                 success_ids_df = spark.createDataFrame([(d["id"],) for d in successful_documents], ["id"])
82                 success_ids_df.createOrReplaceTempView("success_ids_tmp")
83 
84                 spark.sql(f"""
85                     MERGE INTO {catalog}.{schema}.{input_table} t
86                     USING success_ids_tmp s
87                     ON t.Id = s.id
88                     WHEN MATCHED THEN UPDATE SET t.IsAisUpload = 'yes'
89                 """)
90                 i += 1
91             else:
92                 logger.info("No successful document uploads to update.")
93                 break
94 
95     except Exception as e:
96         logger.error(f"Error: {e}")
97         raise
