# tsk_sku_and_related_component_plant_details.py

from pyspark.sql.functions import col, when, lit, concat_ws, coalesce, regexp_replace
from logs.logger import get_logger

# Configure logging
logger = get_logger()


def process_plant_details(spark, config):
    """ Function to retrieve and process plant details using t001w table. """

    try:
        logger.info("Initializing plant details processing.")

        # Extract relevant values from config
        source_schema_tahiti = config["SOURCE_SCHEMA_TAHITI"]
        source_schema_everest = config["SOURCE_SCHEMA_EVEREST"]
        flatten_target_table_name = config["TARGET_TABLE_NAME_COMPONENT_BU_DETAILS"]
        flatten_table_name_everest = config["TARGET_TABLE_NAME_FLATTENED_EVEREST"]
        material_table_name_mzle = config["MATERIAL_TABLE_NAME_MZLE"]
        material_table_name_plastipak = config["MATERIAL_TABLE_NAME_PLASTIPAK"]
        silver_schema = config["SILVER_SCHEMA"]
        gold_schema = config["GOLD_SCHEMA"]
        bronze_schema = config["BRONZE_SCHEMA"]
        target_table_name_plant = config["TARGET_TABLE_NAME_PLANT"]
        target_catalog = config["TARGET_CATALOG"]
        source_catalog = config["SOURCE_CATALOG"]

        # Query plant details for MZLE
        logger.info("Fetching plant details for MZLE.")
        df_mzle = spark.sql(
            f"""SELECT REGEXP_REPLACE(werks, '^0+', '') AS WERKS, PSTLZ, ORT01, NAME2, NAME1, 'Tahiti' as source, 'mzle' as business_unit 
                FROM {source_catalog}.{source_schema_tahiti}.t001w
                WHERE REGEXP_REPLACE(werks, '^0+', '') IN (
                    SELECT DISTINCT PrtChldWers FROM {target_catalog}.{silver_schema}.{flatten_target_table_name} 
                    where Source = 'Tahiti' and BusinessUnit = 'mzle'
                )"""
        )

        # Query plant details for Plastipack
        logger.info("Fetching plant details for Plastipack.")
        df_plastipack = spark.sql(
            f"""SELECT REGEXP_REPLACE(werks, '^0+', '') AS WERKS, PSTLZ, ORT01, NAME2, NAME1, 'Everest' as source, 'plastipak' as business_unit 
                FROM {source_catalog}.{source_schema_everest}.t001w
                WHERE REGEXP_REPLACE(werks, '^0+', '') IN (
                    SELECT DISTINCT PrtChldWers FROM {target_catalog}.{silver_schema}.{flatten_target_table_name} 
                    where Source = 'Everest' and BusinessUnit = 'plastipak'
                )"""
        )

        # Union the dataframes
        logger.info("Merging plant details from MZLE and Plastipack.")
        df_final = df_mzle.union(df_plastipack)

        df_final = df_final.select(
            col("WERKS").alias("PlantId"),
            col("PSTLZ").alias("PostalCode"),
            col("ORT01").alias("City"),
            col("NAME2").alias("Name2"),
            col("NAME1").alias("Name"),
            col("source"),
            col("business_unit")
        )

        # Modify dataframe processing
        logger.info("Cleaning and formatting plant details.")
        df_result = df_final.withColumn("SearchTerm1", lit("TBD")) \
            .withColumn("SearchTerm2", lit("TBD")) \
            .withColumn(
                "PlantName",
                when(col("Name") == col("Name2"), col("Name")) 
                .otherwise(concat_ws(" ", coalesce(col("Name"), lit("")), coalesce(col("Name2"), lit(""))))
            )

        df_result = df_result.select(
            col("PlantId").alias("plant_id"),
            col("PlantName").alias("plant_name"),
            col("City").alias("city"),
            col("PostalCode").alias("postal_code"),
            col("SearchTerm1").alias("search_term_1"),
            col("SearchTerm2").alias("search_term_2"),
            col("source"),
            col("business_unit")
        )

        final_table = f"{target_catalog}.{gold_schema}.{target_table_name_plant}"

        # Save as Delta Table
        logger.info(f"Saving plant details table as {final_table}.")
        df_result.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(final_table)

        logger.info(f"Number of records in final plant table: {df_result.count()}")
        logger.info("Plant details processing completed successfully.")

    except Exception as e:
        logger.error(f"An error occurred during plant details processing: {e}")
        raise(f"Exception : {e}")
