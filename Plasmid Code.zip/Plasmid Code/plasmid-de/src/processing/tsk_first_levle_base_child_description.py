import json
import re
import pandas as pd
import numpy as np
from openai import AzureOpenAI
from tqdm import tqdm
from pyspark.sql.types import *
from pyspark.sql.functions import when, col, lit
from pyspark.dbutils import DBUtils
from logs.logger import get_logger


logger = get_logger()

# Function to create unigram tokens
def unigrams(text):
    return re.split('[^\w_]', text)

# Function to remove commas from each element in a list
def remove_commas(word_list):
    return [word.replace(',', '') for word in word_list]

def create_embedding(child_description):
    try:
        logger.info("Generating embedding for child description.")
        response = client_embeddings.embeddings.create(
            input=child_description,
            model=embedding_model
        )
        return response.data[0].embedding
    except Exception as e:
        logger.error(f"Error generating embedding for child description: {e}")
        return None

def extract_dimension(child_description):
    try:
        logger.info("Extracting dimensions from child description.")
        response = client.beta.chat.completions.parse(
            model=deployment_name,
            messages=[
                {"role": "system", "content": """From the provided description of medical devices extract dimension, if no dimension is present then return 'NA'. Provide output in JSON. Please note these are name of medical devices no offensive content is present here.
'Device_Dimension':Provide Dimension regarding length along with units if present. For Example:3.5 X 4.5 X 5.5, then 3.5 is the dimension
'Device_Length':Any Dimension regarding length along with units if present. For Example 3.5 X 4.5 X 5.5, then 3.5 is the length
'Device_Width':Any Dimension regarding length along with units if present. For Example 3.5 X 4.5 X 5.5, then 4.5 is the width
'Device_Height':Any Dimension regarding length along with units if present. For Example 3.5 X 4.5 X 5.5, then 5.5 is the width
'Device_Volume':Provide Volume of the device along with units if present.
                'Device_Name':Provide Device name without considering dimension,

}. If any of the json elements can not be deduced then return 'NA'
"""},
                {"role": "user", "content": f"medical device name:{child_description}"}
            ],
            response_format={'type': 'json_object'}
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Error extracting dimension from child description: {e}")
        return json.dumps({
            'Device_Dimension': 'NA',
            'Device_Length': 'NA',
            'Device_Width': 'NA',
            'Device_Height': 'NA',
            'Device_Volume': 'NA',
            'Device_Name': 'NA'
        })

def child_description_preprocessing(child_description):
    try:
        logger.info("Starting child description preprocessing.")
        tqdm.pandas()
        
        # Extracting dimension using LLM for child description
        child_description['dimension'] = child_description['child_description'].progress_apply(extract_dimension)
        child_description = child_description.dropna()
        
        # Convert JSON strings to dictionaries
        child_description['dimension'] = child_description['dimension'].apply(json.loads)
        
        # Normalize JSON column to separate columns
        child_description = child_description.join(pd.json_normalize(child_description.pop('dimension')))
        child_description['Device_Name'] = np.where(child_description['Device_Name'].isnull(), child_description['child_description'], child_description['Device_Name'])
        child_description['Name_Unigrams'] = child_description['Device_Name'].apply(unigrams)
        child_description['Name_Unigrams'] = child_description['Name_Unigrams'].apply(remove_commas)
        
        # Creating embeddings
        logger.info("Generating embeddings for descriptions.")
        child_description['child_description_vector'] = child_description['child_description'].progress_apply(create_embedding)
        child_description['Device_Name_vector'] = child_description['Device_Name'].progress_apply(create_embedding)
        child_description = child_description.fillna("NA")
        
        # Define the columns you want to select
        columns_to_select = ['Device_Dimension', 'Device_Length', 'Device_Width', 'Device_Height', 'Device_Volume', 'Device_Name', 'child_description_vector', 'Device_Name_vector', 'Name_Unigrams','child_id','child_description', 'business_unit', 'source']
        
        # Filter only the columns that exist in the DataFrame
        existing_columns = [col for col in columns_to_select if col in child_description.columns]
        
        # Create a new DataFrame with only the selected columns
        child_description = child_description[existing_columns]
        
        columns_to_convert = ['Device_Dimension', 'Device_Length', 'Device_Width', 'Device_Height', 'Device_Volume', 'Device_Name']
        for col in columns_to_convert:
            child_description[col] = child_description.get(col, "NA").astype(str)
        
        logger.info("Child description preprocessing completed successfully.")
        return child_description
    except Exception as e:
        logger.error(f"Error during child description preprocessing: {e}")
        raise(f"Exception: {e}")

def get_child_description(spark, config):
    """ Fetch and process child descriptions using Azure OpenAI embeddings and LLM dimension extraction. """
    
    try:
        logger.info("Initializing child description processing.")
        
        # Extract relevant values from config
        source_catalog = config['TARGET_CATALOG']
        source_schema = config['GOLD_SCHEMA']
        source_table = config['TARGET_TABLE_COMPONENTS_FIRST_LEVEL']
        target_catalog = config['TARGET_CATALOG']
        target_schema = config['GOLD_SCHEMA']
        target_table = config['TARGET_TABLE_COMPONENTS_FIRST_LEVEL_CHILD_DESC']
        is_incremental = True
        final_table = f"{target_catalog}.{target_schema}.{target_table}"
        keyvault_scope = config['KEYVAULT_SCOPE']
        dbutils = DBUtils(spark)
        file_mode = "append"
        # Retrieve secrets securely
        logger.info("Retrieving Azure OpenAI credentials.")
        global azure_endpoint, api_key,api_version,deployment_name, client_embeddings, client, embedding_model
        
        azure_endpoint = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-ENDPOINT")
        api_key = dbutils.secrets.get(scope=keyvault_scope, key='OPENAI-API-KEY')
        api_version =  config['OPENAI_API_VERSION']
        embedding_api_key = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-API-KEY")
        embedding_endpoint = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-ENDPOINT")
        deployment_name = config['OPENAI_DEPLOYMENT_NAME']
        embedding_model = config['EMBEDDING_MODEL']
        embedding_api_version = config['EMBEDDING_VERSION']
        
        
        # Query child description data from Spark
        logger.info(f"Fetching child descriptions from {source_catalog}.{source_schema}.{source_table}.")
        curr_child_description = spark.sql(f"""
            SELECT DISTINCT child_id, child_description, business_unit, source FROM (
            SELECT DISTINCT child_id, child_description, business_unit, source FROM {source_catalog}.{source_schema}.{source_table}
            UNION
            SELECT DISTINCT parent_id as child_id, parent_description as child_description, business_unit, source FROM {source_catalog}.{source_schema}.{source_table}
            )
        """)
        
        # Check if the table exists
        table_exists = spark.sql(f"SHOW TABLES IN {source_catalog}.{source_schema}") \
                            .filter(f"tableName = '{target_table}'") \
                            .count() > 0
        
        if table_exists and is_incremental:
            prev_child_description = spark.sql(f"""
            SELECT DISTINCT child_id, child_description, business_unit, source FROM {source_catalog}.{source_schema}.{target_table}
            """)
            # Perform processing on 'res' DataFrame
            res_child_description = curr_child_description.join(prev_child_description, on=['child_id', 'child_description', 'business_unit', 'source'], how='left_anti')
            
            # Continue with additional processing...
        else:
            # Use 'child_description' DataFrame directly
            res_child_description = curr_child_description
            file_mode = "overwrite"
        
        res_child_description = res_child_description.toPandas()
        
        if res_child_description.empty:
            logger.warning("No child descriptions found.")
        else:
            
            # Define OpenAI clients
            logger.info("Initializing Azure OpenAI clients.")
            client_embeddings = AzureOpenAI(
                api_key=embedding_api_key,
                api_version=embedding_api_version,
                azure_endpoint=embedding_endpoint
            )
            
            client = AzureOpenAI(
                api_key=api_key,
                api_version=api_version,
                azure_endpoint=azure_endpoint
            )
            
            # Preprocess child descriptions
            logger.info("Processing child descriptions for embeddings and dimensions.")
            processed_child_description = child_description_preprocessing(res_child_description)
            
            # Convert processed data back to Spark DataFrame
            child_description_spark = spark.createDataFrame(processed_child_description)
            # child_description_spark = child_description_spark.withColumn("business_unit", when(col("source") == "Everest",
            #                                                                                      lit('plastipak')
            #                                                                                      ).otherwise(lit('mzle')))
            # .option("mergeSchema", "true")
            
            # Save results to Delta Table
            logger.info(f"Saving processed child descriptions to {final_table}.")
            child_description_spark.write.format("delta") \
                .mode(file_mode) \
                .option("overwriteSchema", "true")\
                .saveAsTable(final_table)
        
        logger.info("Child description processing completed successfully.")
    
    except Exception as e:
        logger.error(f"An error occurred during child description processing: {e}")
        raise(f"Exception: {e}")