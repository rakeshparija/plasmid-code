##Base Packages
import os
import re
import json
import time
import warnings
import regex as re
import numpy as np
import pandas as pd
from tqdm.notebook import tqdm

from collections import defaultdict, namedtuple

## Installed PAckages
import pymongo

## Pyspark
from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql import DataFrame
from pyspark.sql.functions import udf, explode, col, when, lit
import pyspark.sql.functions as F
from pyspark.dbutils import DBUtils
from pyspark.sql.types import ArrayType, StructType, StructField, StringType

from logs.logger import get_logger
logger = get_logger()
from urllib.parse import quote_plus

def replace_special_characters_with_nospace(id):
    """Replace special characters with no space."""
    return (' '.join(''.join(e if e.isalnum() or e.isspace() else '' for e in id).split())).lower().strip()

def replace_special_characters_with_space(id):
    """Replace special characters with space."""
    return (' '.join(''.join(e if e.isalnum() or e.isspace() else ' ' for e in id).split())).lower().strip()

def remove_leading_zeros(text):
    # Remove leading zeros only if there are more than one
    return re.sub(r'^0{2,}(?=\w)', '', text)

def extract_unique_special_characters(strings):
    """Extract unique special characters from strings."""
    special_characters = set()
    for string in strings:
        for char in string:
            if not char.isalnum() and not char.isspace():
                special_characters.add(char)
    return special_characters

def create_distance_between_scalar_and_unit(name):
    """Create distance between scalar and unit."""
    pattern = r'(\d+)(mL|L|cm|mm|m|g|kg|in|cc)'
    return re.sub(pattern, r'\1 \2', name)

def execute_query(spark, sql_query):
    """ Connect to Databricks SQL warehouse, execute query, and fetch results"""
    return spark.sql(sql_query).toPandas()

def read_sku_list(file_path):
    """ Load SKU list from a text file. """
    try:
        with open(file_path, "r") as file:
            sku_list = [line.strip() for line in file.readlines()]
        logger.info(f"Successfully read {len(sku_list)} SKUs from {file_path}.")
        return sku_list
    except Exception as e:
        logger.error(f"Error reading SKU list from {file_path}: {e}")
        raise(f"Exception: {e}")

class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end = False
        self.document_names = set()
        self.token_count = 0


class LinkageFinder:

    def __init__(self, document_names, min_scoring_length=3, ignore_tokens=set(), filter_char_count=0):

        
        self.SearchResult = namedtuple('SearchResult', ['matched_substring', 'matched_item', 'score'])
        self.min_scoring_length = min_scoring_length
        self.ignore_tokens = ignore_tokens
        self.filter_char_count = filter_char_count
        self.root = TrieNode()
        self.document_tokens = {}  # Cache for document tokens
        self.document_scoring_tokens = {}  # Cache for document tokens used in scoring
        self.token_to_docs = defaultdict(set)  # Inverse index
        # Cache for variations to avoid redundant calculations
        self.variation_cache = {}
        self.initialize_trie(document_names)

    def tokenize(self, text):
        return text.lower().split()

    def filter_tokens(self, tokens):
        return [t for t in tokens if (len(t) >= self.min_scoring_length) or (t.isnumeric()) and (t not in self.ignore_tokens)]

    def initialize_trie(self, document_names):
        for doc_name in document_names:
            all_tokens = self.tokenize(doc_name)
           
            # Store all tokens for reference
            self.document_tokens[doc_name] = all_tokens
           
            # Filter tokens for matching and scoring
            filtered_tokens = self.filter_tokens(all_tokens)
            self.document_scoring_tokens[doc_name] = filtered_tokens
           
            if not filtered_tokens:
                continue
           
            # Build token-to-document inverse index
            for token in filtered_tokens:
                self.token_to_docs[token].add(doc_name)
           
            # Insert all possible token subsequences into Trie
            for start_idx in range(len(filtered_tokens)):
                current = self.root
                for i, token in enumerate(filtered_tokens[start_idx:]):
                    if token not in current.children:
                        current.children[token] = TrieNode()
                    current = current.children[token]
                    current.document_names.add(doc_name)
                    current.token_count = i + 1

    def generate_variations(self, token, min_fuzzy_length=4, max_edits=1):
        # Return cached variations if available
        cache_key = (token, min_fuzzy_length, max_edits)
        if cache_key in self.variation_cache:
            return self.variation_cache[cache_key]
       
        if len(token) <= min_fuzzy_length or max_edits == 0:
            self.variation_cache[cache_key] = {token}
            return {token}
       
        variations = {token}
       
        # Single character substitutions
        for i in range(len(token)):
            for c in 'abcdefghijklmnopqrstuvwxyz0123456789':
                if c != token[i]:
                    variations.add(token[:i] + c + token[i+1:])
       
        # Single character deletions if resulting token still meets length requirement
        if len(token) > min_fuzzy_length:
            for i in range(len(token)):
                new_token = token[:i] + token[i+1:]
                if len(new_token) >= min_fuzzy_length:
                    variations.add(new_token)
       
        # Store in cache
        self.variation_cache[cache_key] = variations
        return variations

    def find_matches_in_window(self, tokens, start_idx,
                            min_fuzzy_length=4,
                            max_edits=1,
                            match_threshold=0.4):
        all_matches = []
        current = self.root
        matched_tokens = []
       
        for i in range(start_idx, len(tokens)):
            token = tokens[i]
            found_match = False
           
            # Try exact match first (faster path)
            if token in current.children:
                current = current.children[token]
                matched_tokens.append(token)
                found_match = True

            # Only attempt fuzzy matching for tokens longer than min_fuzzy_length
            elif len(token) > min_fuzzy_length:
                variations = self.generate_variations(token, min_fuzzy_length, max_edits)
                for variant in variations:
                    if variant in current.children:
                        current = current.children[variant]
                        matched_tokens.append(token)
                        found_match = True
                        break
           
            if not found_match:
                break
           
            if current.document_names:
                matched_substring = ' '.join(matched_tokens)
               
                for doc_name in current.document_names:
                    doc_scoring_tokens = self.document_scoring_tokens[doc_name]
                   
                    # Calculate score based on matched tokens compared to document tokens
                    if doc_scoring_tokens:
                        score = len(matched_tokens) / len(doc_scoring_tokens)
                       
                        # Only include if it meets threshold and filter_char_count condition
                        if score >= match_threshold and any(len(token) >= self.filter_char_count for token in matched_tokens):
                            all_matches.append((matched_substring, doc_name, score))
                    else:
                        # If document has no scoring tokens but there's a match (edge case)
                        all_matches.append((matched_substring, doc_name, 1.0))
       
        return all_matches

    def search_corpus(self, corpus,
                    min_fuzzy_length=4,
                    max_edits=1,
                    match_threshold=0.4):
        all_tokens = self.tokenize(corpus)
       
        # Filter tokens for matching and scoring
        tokens = self.filter_tokens(all_tokens)
       
        if not tokens:
            return []
       
        all_matches = []
        matched_docs = set()  # Track matches to avoid duplicates
       
        for i in range(len(tokens)):
            window_matches = self.find_matches_in_window(
                tokens, i,
                min_fuzzy_length,
                max_edits,
                match_threshold
            )
           
            for matched_substring, doc_name, score in window_matches:
                match_key = (doc_name, matched_substring)
                if match_key not in matched_docs:
                    all_matches.append(self.SearchResult(
                        matched_substring=matched_substring,
                        matched_item=doc_name,
                        score=score
                    ))
                    matched_docs.add(match_key)
       
        return sorted(all_matches, key=lambda x: x.score, reverse=True)

def generate_linkages(spark, config):
    
    # collection_name = 'ocr_mzle_28thmarch'
    catalog = config['TARGET_CATALOG']
    silver_schema = config['SILVER_SCHEMA']
    gold_schema = config['GOLD_SCHEMA']
    components_table = config['TARGET_TABLE_NAME_COMPONENT_BU_DETAILS']
    dir_table = config['TARGET_TABLE_NAME_DIR_SAP_METADATA']
    product_family_table = config['TARGET_TABLE_NAME_PRODUCT_FAMILY_DETAILS']
    direct_linkages_table = config['TARGET_TABLE_NAME_DIR_SKU_DIRECT_LINKAGES']
    ecro_linkages_table = config['TARGET_TABLE_NAME_ECRO_SKU_LINKAGES']
    ocr_data_transformation_table = config['TARGET_TABLE_NAME_DATA_TRANSFORMATION']
    document_linkages_table = config['TARGET_TABLE_NAME_DOCUMENT_LINKAGES']

    plasticpack_data = read_sku_list("data/plastipak_sku_list.txt")
    plasticpack_sku = set(plasticpack_data)
    logger.info(f"plasticpack unique items:  {len(plasticpack_sku)}")

    source = 'Everest'

    query = f"""
    select DISTINCT ParentMaterialNumber, ParentMaterialDescription, ChildMaterialNumber, ChildMaterialDescription from {catalog}.{silver_schema}.{components_table} 
    WHERE  Source = '{source}'
    """

    item_data = execute_query(spark, query)
    logger.info(f'total rows bom data: {len(item_data)}')

    query = f"""select ParentId, ParentIdPair, ParentIdPairDescription, ComponentSimilarity from {catalog}.{silver_schema}.{product_family_table} where Source = '{source}' """

    family_data = execute_query(spark, query)
    family_data_distinct_count = family_data['ParentId'].nunique()
    logger.info(f'unqie SKU count in product family : {family_data_distinct_count}')

    filter_list = plasticpack_sku

    filtered_item_data = item_data[ (item_data['ParentMaterialNumber'].isin(filter_list)) | (item_data['ChildMaterialNumber'].isin(filter_list)) ]

    filtered_id = filtered_item_data['ParentMaterialNumber'].tolist() + filtered_item_data['ChildMaterialNumber'].tolist() + list(filter_list)
    filtered_names = filtered_item_data['ParentMaterialDescription'].tolist() + filtered_item_data['ChildMaterialDescription'].tolist()
    ## logger.info the relevant info
    logger.info(f'Number of unique items in selected filter list: {len(set(filter_list))}')
    logger.info(f'Number of unique filtered IDs: {len(set(filtered_id))}')
    logger.info(f'Number of unique filtered names: {len(set(filtered_names))}')
    logger.info(f'Unique special characters in filtered IDs: {extract_unique_special_characters(filtered_id)}')
    logger.info(f'Unique special characters in filtered names: {extract_unique_special_characters(filtered_names)}')

    variations_dict_item_ids = {}
    all_variations_item_ids = set()

    for idx, item_id in enumerate(set(filtered_id)):
        variations = set([
            item_id.lower(),
            replace_special_characters_with_nospace(item_id)
        ]) ## create variations of special characters and lower case

        all_variations_item_ids = all_variations_item_ids.union(variations)
        variations_dict_item_ids[item_id.upper()] = variations

    logger.info(f'Number of unique item IDs: {len(variations_dict_item_ids)}')
    logger.info(f'Number of unique item ID variations: {len(all_variations_item_ids)}')

    variations_dict_item_names = {}
    all_variations_item_names = set()

    ## add the different relevant annoitations here
    annotations = { 'll': 'luer lok',
                    'ls': 'luer slip',
                    'st': 'slip tip',
                    'bns': 'bulk non sterile' }

    annotations = {}

    for idx, name in enumerate(filtered_names):

        variations = set([
            name.lower(),
            replace_special_characters_with_space(name),
            replace_special_characters_with_nospace(name)
        ]) ## create variations of special characters and lower case

        new_variations = set()
        for var in variations:
            new_var = create_distance_between_scalar_and_unit(var) ## add distance between scaler and unit
            new_variations.add(new_var)
        
        variations.update(new_variations)
        new_variations = set()
        for var in variations:
            for key, value in annotations.items():  ## add annotations based on annotations dict defined above
                new_var = ' '.join([y.replace(key, value) for y in var.split()])
                new_variations.add(new_var)

        variations.update(new_variations)
        item_id = filtered_id[idx]
        all_variations_item_names = all_variations_item_names.union(variations)
        variations_dict_item_names[item_id.upper()] = variations

    logger.info(f'Number of unique item names: {len(variations_dict_item_names)}')
    logger.info(f'Number of unique name variations: {len(all_variations_item_names)}')

    dir_data = spark.table(f"{catalog}.{silver_schema}.{dir_table}")
    dir_data = dir_data.filter(col('Source')=='Everest')
    dir_data = dir_data.toPandas()
    dir_list = dir_data['DocNumber'].dropna().astype(str).apply(remove_leading_zeros).unique().tolist()

    logger.info(f'Unique DIR: {len(dir_list)}')

    variations_dict_document_ids = {}
    all_variations_document_ids = set()

    for idx, dir_number in enumerate(dir_list):  

        variations = set([
            dir_number.lower(),
            replace_special_characters_with_nospace(dir_number)]) ## create variations of special characters and lower case
        
        all_variations_document_ids = all_variations_document_ids.union(variations)
        variations_dict_document_ids[ dir_number.upper() ] = variations
        
    logger.info(f'Number of unique document DIR: {len(variations_dict_document_ids)}')
    logger.info(f'Number of unique document DIR variations: {len(all_variations_document_ids)}')

    logger.info(f'Number of unique item ID variations: {len(all_variations_item_ids)}')
    logger.info(f'Minimum character count in item ID variations: {min(len(item) for item in all_variations_item_ids)}')

    logger.info(f'Number of unique name variations: {len(all_variations_item_names)}')
    logger.info(f'Minimum character count in name variations: {min(len(name) for name in all_variations_item_names)}')

    logger.info(f'Number of unique document DIR variations: {len(all_variations_document_ids)}')
    logger.info(f'Minimum character count in document DIR variations: {min(len(doc) for doc in all_variations_document_ids)}')

    # ID linkage
    item_id_linkage_finder = LinkageFinder(
        document_names=all_variations_item_ids,
        min_scoring_length=2,
        ignore_tokens=set(),
        filter_char_count=3
    )

    # Name linkage
    item_name_linkage_finder = LinkageFinder(
        document_names=all_variations_item_names,
        min_scoring_length=2,
        ignore_tokens=set(),
        filter_char_count=4
    )

    # Document ID linkage
    # ignore_tokens = {'becton dickinson', 'bd', 'becton', 'dickinson'}

    doc_id_linkage_finder = LinkageFinder(
        document_names=all_variations_document_ids,
        min_scoring_length=2,
        ignore_tokens=set(),
        filter_char_count=3
    )

    # all_ocr_data = list(ocr_collection.find())
    # ocr_df = spark.table(f"{catalog}.{silver_schema}.{ocr_table}").filter((col('source')=='Everest') & (col('status')=='OK') & (col('is_linkages')=='no'))

    # logger.info(f"OCR count: {ocr_df.count()}")

    COMPONENT_SIMILARITY_THRESHOLD = 0.11
    start_time = time.time() 


    Match = namedtuple('Match', ['dir_number', 'id', 'type'])
    COMPONENT_SIMILARITY_THRESHOLD = 0.11
    # Broadcast all lookup data
    bc_variations_item_ids = spark.sparkContext.broadcast(variations_dict_item_ids)
    bc_variations_item_names = spark.sparkContext.broadcast(variations_dict_item_names)
    bc_variations_doc_ids = spark.sparkContext.broadcast(variations_dict_document_ids)
    bc_family_data = spark.sparkContext.broadcast(family_data)
    bc_threshold = spark.sparkContext.broadcast(COMPONENT_SIMILARITY_THRESHOLD)


    # Step 2: Define UDF for matching logic
    def find_matches_udf(ocr_text, dir_number):
        search_corpus = ocr_text.lower()
        search_corpus += ' ' + replace_special_characters_with_space(ocr_text)
        search_corpus += ' ' + replace_special_characters_with_nospace(ocr_text)

        item_id_matches = item_id_linkage_finder.search_corpus(search_corpus, max_edits=0, min_fuzzy_length=4, match_threshold=1)
        # item_name_matches = item_name_linkage_finder.search_corpus(search_corpus, max_edits=0, min_fuzzy_length=4, match_threshold=0.6)
        doc_id_matches = doc_id_linkage_finder.search_corpus(search_corpus, max_edits=0, min_fuzzy_length=4, match_threshold=1)

        item_id_matches = set([x.matched_item for x in item_id_matches])
        # item_name_full = set([x.matched_item for x in item_name_matches if x.score == 1])
        # item_name_partial = set([x.matched_item for x in item_name_matches if x.score < 1])
        doc_id_matches = set([x.matched_item for x in doc_id_matches])

        var_item_ids = {k for k, v in bc_variations_item_ids.value.items() if item_id_matches & v}
        # var_item_names_full = {k for k, v in bc_variations_item_names.value.items() if item_name_full & v}
        # var_item_names_partial = {k for k, v in bc_variations_item_names.value.items() if item_name_partial & v}
        var_doc_ids = {k for k, v in bc_variations_doc_ids.value.items() if doc_id_matches & v}

        all_item_matches = var_item_ids #| (set(item_name_matches))
        family_df = bc_family_data.value
        family_matches = set(
            family_df[
                (family_df['ParentId'].isin(all_item_matches)) &
                (family_df['ComponentSimilarity'] >= bc_threshold.value)
            ]['ParentIdPair'].unique()
        ) - all_item_matches

        results = []
        results += [{'dir_number': dir_number, 'id': i, 'type': 'item_id_indirect'} for i in var_item_ids]
        # results += [{'dir_number': dir_number, 'id': i, 'type': 'item_name_indirect'} for i in var_item_names_full]
        # results += [{'dir_number': dir_number, 'id': i, 'type': 'item_name_indirect'} for i in var_item_names_partial]
        results += [{'dir_number': dir_number, 'id': i, 'type': 'document_id_indirect'} for i in var_doc_ids]
        results += [{'dir_number': dir_number, 'id': i, 'type': 'item_id_family'} for i in family_matches]

        return results

    match_schema = ArrayType(StructType([
        StructField("dir_number", StringType()),
        StructField("id", StringType()),
        StructField("type", StringType()),
    ]))

    @udf(returnType=match_schema)
    def run_matching_udf(ocr_list, dir_number):
        ocr_text = ' '.join(ocr_list)
        return find_matches_udf(ocr_text, dir_number)
    
    combined_matches_df = pd.DataFrame()
    i = 0
    while True:
        logger.info(f"Processing Iteration: {i}")
        spark.sql(f"""
            SELECT *, 
                SUM(TotalTokenCount) OVER (ORDER BY TotalTokenCount ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_token_count
            FROM {catalog}.{silver_schema}.{ocr_data_transformation_table}
            WHERE IsLinkages = 'no' and Source = 'Everest'
        """).createOrReplaceTempView("filtered_ack_df")

        # Step 2: Select only rows where cumulative word_count ≤ 300000
        ack_spark_df = spark.sql("""
            SELECT * 
            FROM filtered_ack_df 
            WHERE running_token_count <= 50000000
        """).dropDuplicates()
        # current_token_count = ack_spark_df.agg(sum(col("total_token_count"))).collect()
        # logger.info(f"Token count in this iteration-{iter}: {current_token_count}")
        logger.info(f"Total Document count in this iteration-{i}: {ack_spark_df.count()}")

        import datetime
        s=str(datetime.datetime.now())
        logger.info(s)

        max_retries = 3
        retry_delay = 10
        for attempt in range(max_retries):
            try:
                ack_spark_df.createOrReplaceTempView("ack_spark_df_view")
                spark.sql(f"""
                update {catalog}.{silver_schema}.{ocr_data_transformation_table}
                set IsLinkages = '{s}'
                where DocName in (SELECT distinct DocName FROM ack_spark_df_view) and IsLinkages = 'no'
                """)
                break
            except Exception as e:
                logger.error(f"Error in updating: {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    logger.info("Retrying Again")

        

        ocr_df = spark.sql(f"""
        SELECT Ocr, DocName, BlobPath, DirNumber, Source, TotalTokenCount  FROM {catalog}.{silver_schema}.{ocr_data_transformation_table}
        WHERE IsLinkages = '{s}'""")

        # current_token_count_iter = ocr_df.agg(sum(col("total_token_count"))).collect()
        # logger.info(f"Token count in this iteration-{iter}: {current_token_count_iter}")
        logger.info(f"Total Document count in this iteration-{i}: {ocr_df.count()}")

        if ocr_df.count() == 0:
            logger.info("No data to process")
            break

        # Step 3: Apply UDF and explode results
        matched_df = ocr_df.withColumn("matches", run_matching_udf("Ocr", "DirNumber"))
        matched_df = matched_df.select(explode("matches").alias("match"))
        matched_df = matched_df.select(
            col("match.dir_number"),
            col("match.id"),
            col("match.type")
        ).dropDuplicates()

        # Step 4: Collect or write output
        # logger.info(f"{matched_df.count()}")

        # logger.info(f'Linakges formed till this point: {matched_df.count()}')
        # temp_df = matched_df.toPandas()
        # logger.info(f"Linkages formed in this iteration-{i}: {temp_df.count()}")
        # combined_matches_df = pd.concat([combined_matches_df, temp_df], ignore_index=True)
        # logger.info(f'Linakges formed till this point: {len(combined_matches_df)}')
        logger.info("Writing Linakges to temp_linkages_table")
        matched_df.write.mode("append").saveAsTable(f"{catalog}.{silver_schema}.temp_linkages_table")
        logger.info("Completed writing Linakges to temp_linkages_table")

        for attempt in range(max_retries):
            try:
                spark.sql(f"""
                update {catalog}.{silver_schema}.{ocr_data_transformation_table}
                set IsLinkages = 'yes'
                where IsLinkages='{s}'  """)
                break
            except Exception as e:
                logger.error(f"Error in updating: {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    logger.info("Retrying Again")


        i+=1

    linkages_schema = StructType([
                StructField("dir_number", StringType(), True),
                StructField("id", StringType(), True),
                StructField("type", StringType(), True),
            ])
    try:
        combined_matches_df = spark.sql(f"""
        SELECT * FROM {catalog}.{silver_schema}.temp_linkages_table""")
    except Exception as e:
        combined_matches_df = spark.createDataFrame([],linkages_schema)
    
    try:
        existing_df = spark.table(f"{catalog}.{gold_schema}.{document_linkages_table}").select("dir_number", "id", "type")
    except Exception as e:
        existing_df = spark.createDataFrame([],linkages_schema)

    combined_matches_df = combined_matches_df.unionByName(existing_df).dropDuplicates()
    logger.info("Adding direct linkages now")

    # Step 1: direct_linkages
    query = f"""
    SELECT DISTINCT
    REGEXP_REPLACE(REGEXP_REPLACE(DOKNR, '^0+', ''), '^EVEREST-', '') AS doknr,
    REGEXP_REPLACE(MATNR, '^0+', '') AS matnr
    FROM {catalog}.{silver_schema}.{direct_linkages_table}
    WHERE DOKNR IS NOT NULL
    AND MATNR IS NOT NULL
    """

    direct_linkages = spark.sql(query)

    # Filter using dir_list and filtered_id
    direct_linkages = (
        direct_linkages
        .filter(
            (F.lower(F.col("doknr")).isin([d.lower() for d in dir_list])) &
            (F.lower(F.col("matnr")).isin([m.lower() for m in filtered_id]))
        )
        .withColumn("type", F.lit("item_id_direct"))
        .withColumnRenamed("doknr", "dir_number")
        .withColumnRenamed("matnr", "id")
    )

    # Append
    combined_matches_df = combined_matches_df.unionByName(direct_linkages).dropDuplicates()

    logger.info(f"Total In Scope Direct Linkages: {direct_linkages.count()}")
    logger.info(f"Total linkages after adding direct linkages : {combined_matches_df.count()}")

    # Step 2: ecro_linkages
    logger.info("Adding ECRO direct linkages now")

    query = f"""
    SELECT DISTINCT
    REGEXP_REPLACE(matnr, '^0+', '') AS matnr,
    REGEXP_REPLACE(REGEXP_REPLACE(doknr, '^0+', ''), '^EVEREST-', '') AS doknr
    FROM {catalog}.{gold_schema}.{ecro_linkages_table}
    WHERE doknr IS NOT NULL
    AND matnr IS NOT NULL
    """

    ecro_linkages = spark.sql(query)

    ecro_linkages = (
        ecro_linkages
        .filter(
            (F.lower(F.col("doknr")).isin([d.lower() for d in dir_list])) &
            (F.lower(F.col("matnr")).isin([m.lower() for m in filtered_id]))
        )
        .withColumn("type", F.lit("item_id_direct_ecro"))
        .withColumnRenamed("doknr", "dir_number")
        .withColumnRenamed("matnr", "id")
    )

    combined_matches_df = combined_matches_df.unionByName(ecro_linkages).dropDuplicates()

    logger.info(f"Total In Scope ECRO Direct Linkages: {ecro_linkages.count()}")
    logger.info(f"Total linkages after adding ECRO linkages : {combined_matches_df.count()}")


    # logger.info("Now creating item linkages for dirs with only document linkages (Linkage borrowing)")

    # no_linkages_data = combined_matches_df.filter(F.col("type") == "document_id_indirect")

    # logger.info(f"Total Data points selected {no_linkages_data.count()}")

    # # Step 2: Borrow linkages 
    # borrow_types = ['item_id_direct','item_id_indirect', 'item_name_indirect','item_id_family']

    # borrowed_linkages = (
    #     no_linkages_data
    #     .selectExpr("dir_number as original_dir", "id as original_id")
    #     .join(
    #         combined_matches_df.filter(F.col("type").isin(borrow_types)),
    #         F.col('original_id') == F.col('dir_number'),
    #         how="inner"
    #     )
    #     # .withColumn("dir_number", F.col("original_dir"))  # overwrite borrowed's dir_number with original
    #     .select(
    #     "original_dir",  "id", "type"
    #     )
    # )
    # borrowed_linkages = borrowed_linkages.withColumnRenamed("original_dir", "dir_number")
    # # Step 3: Append
    # combined_matches_df = combined_matches_df.unionByName(borrowed_linkages).dropDuplicates()

    # # Logging counts
    # total_borrowed_linkages = borrowed_linkages.count()
    # logger.info(f"Total borrowed linkages: {total_borrowed_linkages}")
    # logger.info(f"Total linkages after adding borrowed linkages : {combined_matches_df.count()}")

    combined_matches_spark_df = combined_matches_df.dropDuplicates()

    # logger.info(f'Total linkages after adding ECRO linkages : {len(combined_matches_df)}')

    # combined_matches_df['id'] = combined_matches_df['id'].str.lower().apply(remove_leading_zeros)
    # combined_matches_df['dir_number'] = combined_matches_df['dir_number'].str.lower().apply(remove_leading_zeros)
    # combined_matches_df['source'] = 'Everest'
    # combined_matches_spark_df = combined_matches_df
    # Register as Spark UDF
    remove_leading_zeros_udf = F.udf(remove_leading_zeros, StringType())

    # Apply UDF on Spark DataFrame
    combined_matches_spark_df = (
        combined_matches_df
        .withColumn("id", remove_leading_zeros_udf(F.lower(F.col("id"))))
        .withColumn("dir_number", remove_leading_zeros_udf(F.lower(F.col("dir_number"))))
        .withColumn("source", F.lit("Everest"))
    )
    query = f"""
    select distinct mat, desc from (
    select DISTINCT lower(ParentMaterialNumber) as mat, ParentMaterialDescription as desc from {catalog}.{silver_schema}.{components_table} WHERE  Source = '{source}'
    union
    select lower(ChildMaterialNumber) as mat, ChildMaterialDescription as desc from {catalog}.{silver_schema}.{components_table}
    WHERE  Source = '{source}'
    )
    """
    components_df = spark.sql(query)
    combined_matches_spark_df = combined_matches_spark_df.join(components_df, combined_matches_spark_df.id == components_df.mat, how='left').select(combined_matches_spark_df.dir_number, combined_matches_spark_df.id, combined_matches_spark_df.type, combined_matches_spark_df.source, components_df.desc)

    combined_matches_spark_df = combined_matches_spark_df.dropDuplicates()
    combined_matches_spark_df = combined_matches_spark_df.repartition(200)

    logger.info(f"Linkages Count: {combined_matches_spark_df.count()}")
    combined_matches_spark_df = combined_matches_spark_df.withColumn("business_unit", when( col("source") == "Everest",
                    lit('plastipak')
                ).otherwise(lit('mzle')))

    from delta.tables import DeltaTable

    # Example: Composite key on id and date
    merge_condition = """
    target.id = source.id AND
    target.dir_number = source.dir_number AND
    target.type = source.type AND
    target.source = source.source AND
    target.desc = source.desc
    """
    try:
        # Load Delta table
        delta_table = DeltaTable.forName(spark, f"{catalog}.{gold_schema}.{document_linkages_table}")

        logger.info("Delta Table Found, Starting Merging")

        # Perform merge with multiple match conditions
        delta_table.alias("target").merge(
            source=combined_matches_spark_df.alias("source"),
            condition=merge_condition
        ).whenNotMatchedInsertAll().execute()
        logger.info("Merging Completed")
    except Exception as e:
        logger.error(f"Error: {e}")
        logger.info("Delta table not found, overwriting table")
        combined_matches_spark_df.write.format("delta").option("overwriteSchema", "true").saveAsTable(f"{catalog}.{gold_schema}.{document_linkages_table}")
        logger.info("Linkages table got created")
    

    spark.sql(f"OPTIMIZE {catalog}.{gold_schema}.{document_linkages_table}")
    logger.info(f"Finished writing table {catalog}.{gold_schema}.{document_linkages_table}")

    logger.info("Dropping Intermediate Linkages table")
    spark.sql(f"DROP TABLE IF EXISTS {catalog}.{silver_schema}.temp_linkages_table")
    logger.info("Completed dropping Intermediate Linkages table")