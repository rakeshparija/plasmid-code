from pyspark.sql.functions import col, max, date_format, current_date,when, lit
from pyspark.sql import SparkSession
from logs.logger import get_logger

# Configure logging
logger = get_logger()

def generate_is_sub_component_column(base_df):
    try:
        # Performing a SELF LEFT JOIN - base_df
        logger.info("Generating is_sub_component column: Starting the self left join operation.")
        
        joined_df = base_df.alias("a").\
            join(base_df.alias("b"), col("a.ChildMaterialNumber") == col("b.ParentMaterialNumber"), "left").\
            withColumn("IsRawMaterial", when(col("b.ParentMaterialNumber").isNull() | col("b.ChildMaterialNumber").isNull(), "Y").otherwise("N")).\
            withColumn("IsSubComponent", when(col("b.ParentMaterialNumber").isNull() | col("b.ChildMaterialNumber").isNull(), "N").otherwise("Y")).\
            withColumn("Level", lit(1)).\
            select(
                col("a.ParentMaterialNumber"), 
                col("a.ParentMaterialDescription"),
                col("a.ParentBmeng"),
                col("a.ParentBmein"),
                col("a.ChildMaterialNumber"),
                col("a.ChildMaterialDescription"),
                col("a.ChildMaterialDescription"),
                col("a.ChildMenge"),
                col("a.ChildMeins"),
                col("a.Client"),
                col("a.PrtChdWerks"),
                col("a.PrtChdStlan"),
                col("a.PrtChdStlal"),
                col("a.PrtChdStlst"),
                col("a.PrtChdPosnr"),
                col("a.ChildDatuv"),
                col("a.BomHeaderInternalCounter"),
                col("a.BomHeaderDeletionIndicator"),
                col("a.BomHeaderDeletionFlag"),
                col("a.BomItemBomCategory"),
                col("a.BillOfMaterialNumber"),
                col("a.BomItemNodeNumber"),
                col("a.BomItemInternalCounter"),
                col("a.BomItemDeletionIndicator"),
                col("a.BomItemCategory"),
                col("a.LastChangeDate"),
                col("a.BomItemSelectionInternalCounter"),
                col("a.BomItemSelectionDeletionFlag"),
                col("IsRawMaterial"),
                col("IsSubComponent"),
                col("Level")
            ).distinct()
        
        logger.info("Successfully generated is_sub_component column for the dataframe.")

        return joined_df
    
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        return None



# Generating Dataframe with Is Finished Product Column for Level 1
def generate_is_finished_product_column(base_df):
    try:
        logger.info("Starting the self left join operation to determine finished products.")
        
        # Performing a SELF LEFT JOIN - base_df
        joined_df = base_df.alias("a").\
            join(base_df.alias("b"), col("a.ParentMaterialNumber") == col("b.ChildMaterialNumber"), "left").\
            withColumn("IsFinishedProduct", when(col("b.ChildMaterialNumber").isNull() | col("b.ParentMaterialNumber").isNull(), "Y").otherwise("N")).\
            select(
                col("a.ParentMaterialNumber"), 
                col("a.ParentMaterialDescription"),
                col("a.ParentBmeng"),
                col("a.ParentBmein"),
                col("a.ChildMaterialNumber"),
                col("a.ChildMaterialDescription"),
                col("a.ChildMenge"),
                col("a.ChildMeins"),
                col("a.Client"),
                col("a.PrtChdWerks"),
                col("a.PrtChdStlan"),
                col("a.PrtChdStlal"),
                col("a.PrtChdStlst"),
                col("a.PrtChdPosnr"),
                col("a.ChildDatuv"),
                col("a.BomHeaderInternalCounter"),
                col("a.BomHeaderDeletionIndicator"),
                col("a.BomHeaderDeletionFlag"),
                col("a.BomItemBomCategory"),
                col("a.BillOfMaterialNumber"),
                col("a.BomItemNodeNumber"),
                col("a.BomItemInternalCounter"),
                col("a.BomItemDeletionIndicator"),
                col("a.BomItemCategory"),
                col("a.LastChangeDate"),
                col("a.BomItemSelectionInternalCounter"),
                col("a.BomItemSelectionDeletionFlag"),
                col("a.IsRawMaterial"),
                col("a.IsSubComponent"),
                col("IsFinishedProduct"),
                col("a.Level")
            ).distinct()
        
        logger.info("Successfully processed the dataframe for finished products.")

        return joined_df
    
    except Exception as e:
        logger.error(f"An error occurred while processing the dataframe: {e}")
        return None


# Generating Dataframes for next Levels
def generate_next_level(base_df, current_level_df, level):
    try:
        logger.info(f"Starting the INNER JOIN operation to generate level {level}.")
        
        # Performing an INNER JOIN between base_df and current_level_df
        joined_df = base_df.alias("a").\
            join(current_level_df.alias("b"), col("a.ParentMaterialNumber") == col("b.ChildMaterialNumber"), "inner").\
            withColumn("NewLevel", lit(level)).\
            select(
                col("b.ParentMaterialNumber"), 
                col("b.ParentMaterialDescription"),
                col("b.ParentBmeng"),
                col("b.ParentBmein"),
                col("a.ChildMaterialNumber"),
                col("a.ChildMaterialDescription"),
                col("a.ChildMenge"),
                col("a.ChildMeins"),
                col("a.Client"),
                col("b.PrtChdWerks"),
                col("b.PrtChdStlan"),
                col("b.PrtChdStlal"),
                col("b.PrtChdStlst"),
                col("b.PrtChdPosnr"),
                col("a.ChildDatuv"),
                col("b.BomHeaderInternalCounter"),
                col("b.BomHeaderDeletionIndicator"),
                col("b.BomHeaderDeletionFlag"),
                col("a.BomItemBomCategory"),
                col("a.BillOfMaterialNumber"),
                col("a.BomItemNodeNumber"),
                col("a.BomItemInternalCounter"),
                col("a.BomItemDeletionIndicator"),
                col("a.BomItemCategory"),
                col("a.LastChangeDate"),
                col("a.BomItemSelectionInternalCounter"),
                col("a.BomItemSelectionDeletionFlag"),
                col("a.IsRawMaterial"),
                col("a.IsSubComponent"),
                col("b.IsFinishedProduct"),
                col("NewLevel").alias("Level")
            )
        
        logger.info(f"Successfully processed the dataframe for level {level}.")
        return joined_df
    
    except Exception as e:
        logger.error(f"An error occurred while processing level {level}: {e}")
        return None


# Helps in generating tables for all levels
def generate_recursive_tables(base_df, current_level_df, start, no_of_levels):
    try:
        logger.info(f"Starting recursive table generation from level {start} to {no_of_levels}.")
        finalDf = None

        for level in range(start, no_of_levels):
            logger.info(f"******** LEVEL {level} - Started **********")

            if level == 1:
                level_df = base_df
                # .filter(col("IsFinishedProduct") == "Y")
            elif level > no_of_levels:
                logger.warning("*** Break - Maximum Level Reached ***")
                break
            else:
                level_df = generate_next_level(base_df, current_level_df, level)

            # Check if the level_df is empty; break if no more levels
            if not level_df.take(1):
                logger.warning("*** Break - No more Levels ***")
                break

            current_level_df = level_df.select(
                "ParentMaterialNumber", "ParentMaterialDescription", "ParentBmeng", "ParentBmein",
                "ChildMaterialNumber", "ChildMaterialDescription", "ChildMenge", "ChildMeins",
                "Client", "PrtChdWerks", "PrtChdStlan", "PrtChdStlal", "PrtChdStlst", "PrtChdPosnr",
                "ChildDatuv", "BomHeaderInternalCounter", "BomHeaderDeletionIndicator", "BomHeaderDeletionFlag",
                "BomItemBomCategory", "BillOfMaterialNumber", "BomItemNodeNumber", "BomItemInternalCounter",
                "BomItemDeletionIndicator", "BomItemCategory", "LastChangeDate",
                "BomItemSelectionInternalCounter", "BomItemSelectionDeletionFlag",
                "IsRawMaterial", "IsSubComponent", "IsFinishedProduct", "Level"
            ).distinct()

            if finalDf is None:
                finalDf = current_level_df
            else:
                finalDf = finalDf.unionByName(current_level_df)

            logger.info(f"******** LEVEL {level} - Ended **********")

        logger.info("Recursive table generation completed successfully.")
        return finalDf

    except Exception as e:
        logger.error(f"An error occurred during recursive table generation: {e}")
        return None


def generate_next_batch(spark, batch, start_level, maximum_level, material_bom_base_df, config):
    try:
        logger.info(f"Starting batch {batch} table generation.")

        sap_source = "everest" 
        no_of_repartitions = config["NO_OF_REPARTITIONS"]
        target_catalog = config["TARGET_CATALOG"]
        max_level = config["MAX_LEVEL"]
        bronze_schema = config["BRONZE_SCHEMA"] 

        if batch == 1:
            prev_level_df = None
        else:
            # Loading the batch table
            prev_level_df = spark.table(f"{target_catalog}.{bronze_schema}.plasmid_{sap_source}_material_bom_batch_{batch - 1}")
            prev_level_df = prev_level_df.filter(col("level") == (start_level - 1))

            if not prev_level_df.take(1):
                logger.warning(f"Previous batch {batch - 1} is empty. Exiting.")
                return True

            prev_level_df = prev_level_df.repartition(no_of_repartitions)

            # Filtering to remove finished products
            material_bom_base_df = material_bom_base_df.filter(col("IsFinishedProduct") != "Y")

        logger.info(f"Generating batch {batch} table.")
        material_bom_multi_level_batch_df = generate_recursive_tables(material_bom_base_df, prev_level_df, start_level, maximum_level)

        if material_bom_multi_level_batch_df is not None:
            logger.info(f"Saving batch {batch} table.")
            material_bom_multi_level_batch_df = material_bom_multi_level_batch_df.repartition(no_of_repartitions)
            material_bom_multi_level_batch_df.write.mode("overwrite").saveAsTable(f"{target_catalog}.{bronze_schema}.plasmid_{sap_source}_material_bom_batch_{batch}")
            logger.info(f"Completed batch {batch} table creation.")
        else:
            logger.warning(f"Batch {batch} table generation resulted in None. Exiting.")
            return True

        return False

    except Exception as e:
        logger.error(f"An error occurred in batch {batch} table generation: {e}")
        return None
  
def generate_batch_tables(spark, config):
    try:
        logger.info("Batch table generation process started")

        sap_source = "everest" 
        no_of_repartitions = config["NO_OF_REPARTITIONS"]
        target_catalog = config["TARGET_CATALOG"]
        max_level = config["MAX_LEVEL"]
        bronze_schema = config["BRONZE_SCHEMA"] 
        NO_OF_BATCHES = ((max_level + 1) // 2) + 1

        material_bom_base_df = spark.table(f"{target_catalog}.{bronze_schema}.plasmid_material_bom_base_{sap_source}")
        material_bom_base_df = material_bom_base_df.repartition(no_of_repartitions)

        # # To Perform Batch Wise Table Creations
        logger.info("Performing batch-wise table creation.")
        

        for batch in range(1, NO_OF_BATCHES):
            start_level = (2 * batch) - 1
            maximum_level = start_level + 2
            halt_execution_flag = generate_next_batch(spark, batch, start_level, maximum_level, material_bom_base_df, config)

            if halt_execution_flag == True:
                NO_OF_BATCHES = batch
                break
    except Exception as e:
        logger.error(f"An error occurred during generating batch tables: {e}")
        raise(f"Exception: {e}")

def generate_final_material_bom(spark, config):
    try:
        logger.info("Final flattened Material BOM table generation process started")
        sap_source = "everest" 
        no_of_repartitions = config["NO_OF_REPARTITIONS"]
        target_catalog = config["TARGET_CATALOG"]
        max_level = config["MAX_LEVEL"]
        bronze_schema = config["BRONZE_SCHEMA"]
        final_table_name = config['MATERIAL_FLATTENED_EVEREST'] 
        NO_OF_BATCHES = ((max_level + 1) // 2) + 1
        material_bom_multi_level_final_df = None
        for batch in range(1, NO_OF_BATCHES):
            if batch == 1:
                material_bom_multi_level_final_df = spark.table(f"{target_catalog}.{bronze_schema}.plasmid_{sap_source}_material_bom_batch_1")
            else:
                material_bom_batch_df = spark.table(f"{target_catalog}.{bronze_schema}.plasmid_{sap_source}_material_bom_batch_{batch}")
                material_bom_multi_level_final_df = material_bom_multi_level_final_df.unionByName(material_bom_batch_df)

        # material_bom_multi_level_batch_count = material_bom_multi_level_batch_df.count()
        
        final_table = f"{target_catalog}.{bronze_schema}.{final_table_name}"
        material_bom_flattened_df = material_bom_multi_level_final_df
        material_bom_flattened_df = material_bom_flattened_df.repartition(no_of_repartitions)
        material_bom_flattened_df.write.mode("overwrite").saveAsTable(final_table)

        logger.info(f"Final ALL level {sap_source} fattened BOM Table Created with name {final_table}")
    except Exception as e:
        logger.error(f"An error occurred during generating final material BOM table: {e}")
        raise(f"Exception: {e}")

def drop_intermediate_tables(spark, config):
    try:
        sap_source = "everest" 
        target_catalog = config["TARGET_CATALOG"]
        bronze_schema = config["BRONZE_SCHEMA"]
        is_drop_enabled = config['IS_DROP_TABLE_ENABLED']

        if is_drop_enabled:
            logger.info("Dropping batch tables as per configuration.")
            spark.sql(f"DROP TABLE IF EXISTS {target_catalog}.{bronze_schema}.plasmid_material_bom_base_{sap_source}")
            for batch in range(1, 14):
                spark.sql(f"DROP TABLE IF EXISTS {target_catalog}.{bronze_schema}.plasmid_{sap_source}_material_bom_batch_{batch}")
                spark.sql(f"DROP TABLE IF EXISTS {target_catalog}.s_plasmid.plasmid_{sap_source}_material_bom_batch_{batch}")
                logger.info(f"Dropping Batch  {target_catalog}.{bronze_schema}.plasmid_{sap_source}_material_bom_batch_{batch} Table")
    except Exception as e:
        logger.error(f"An error occurred during droping intermediate tables: {e}")
        raise(f"Exception: {e}")

def generate_base_material_bom(spark, config):
    try:
        logger.info("Base Material BOM generation process started")
        source_catalog = config["SOURCE_CATALOG"] 
        source_schema = config["SOURCE_SCHEMA_EVEREST"]
        sap_source = "everest" 
        target_catalog = config["TARGET_CATALOG"]
        bronze_schema = config["BRONZE_SCHEMA"]
        # Load tables with logging
        logger.info("Loading source tables from Databricks.")
        mast_df = spark.table(f"{source_catalog}.{source_schema}.MAST")
        stko_df = spark.table(f"{source_catalog}.{source_schema}.STKO")
        stas_df = spark.table(f"{source_catalog}.{source_schema}.STAS")
        stpo_df = spark.table(f"{source_catalog}.{source_schema}.STPO")
        makt_df = spark.table(f"{source_catalog}.{source_schema}.MAKT")

        # Processing tables
        logger.info("Processing STKO table.")
        stko_max_df = stko_df.filter((col("STLTY") == 'M') & (col("DATA_OPERATION") != 'D')) \
            .groupBy("STLTY", "STLNR", "STLAL") \
            .agg(max("STKOZ").alias("STKOZ"))

        stko_lkenz_df = stko_df.filter((col("STLTY") == 'M') & (col("DATA_OPERATION") != 'D') &
                                    ((col("LKENZ") != 'X') | col("LKENZ").isNull()) &
                                    ((col("LOEKZ") != 'X') | col("LOEKZ").isNull()) &
                                    (col("STLST").isin('1', '01', '2', '02'))) \
            .join(stko_max_df, on=["STLTY", "STLNR", "STLAL", "STKOZ"], how="inner")

        # Processing STAS
        logger.info("Processing STAS table.")
        stas_max_df = stas_df.filter((col("STLTY") == 'M') & (col("DATA_OPERATION") != 'D')) \
            .groupBy("STLTY", "STLNR", "STLAL", "STLKN") \
            .agg(max("STASZ").alias("STASZ"))

        stas_lkenz_df = stas_df.filter((col("STLTY") == 'M') & (col("DATA_OPERATION") != 'D') &
                                    ((col("LKENZ") != 'X') | col("LKENZ").isNull())) \
            .join(stas_max_df, on=["STLTY", "STLNR", "STLAL", "STLKN", "STASZ"], how="inner")

        # Processing STPO
        logger.info("Processing STPO table.")
        stpo_max_df = stpo_df.filter((col("STLTY") == 'M') & (col("DATA_OPERATION") != 'D')) \
            .groupBy("STLTY", "STLNR", "STLKN") \
            .agg(max("STPOZ").alias("STPOZ"))

        stpo_lkenz_df = stpo_df.filter((col("STLTY") == 'M') & (col("POSTP") == 'L') & (col("DATA_OPERATION") != 'D') &
                                    ((col("LKENZ") != 'X') | col("LKENZ").isNull())) \
            .join(stpo_max_df, on=["STLTY", "STLNR", "STLKN", "STPOZ"], how="inner")

        logger.info("Joining tables for material BOM multi-level data.")
        material_bom_multi_level_df = mast_df.join(stko_lkenz_df, (mast_df["STLNR"] == stko_lkenz_df["STLNR"]) & (mast_df["STLAL"] == stko_lkenz_df["STLAL"]), "inner") \
            .join(stas_lkenz_df, (stko_lkenz_df["STLTY"] == stas_lkenz_df["STLTY"]) & 
                            (stko_lkenz_df["STLNR"] == stas_lkenz_df["STLNR"]) & 
                            (stko_lkenz_df["STLAL"] == stas_lkenz_df["STLAL"]), "inner") \
            .join(stpo_lkenz_df, (stas_lkenz_df["STLTY"] == stpo_lkenz_df["STLTY"]) & 
                            (stas_lkenz_df["STLNR"] == stpo_lkenz_df["STLNR"]) & 
                            (stas_lkenz_df["STLKN"] == stpo_lkenz_df["STLKN"]), "inner") \
            .filter((mast_df["STLAN"] == '1') & (mast_df["DATA_OPERATION"] != 'D')) \
            .select(
                mast_df["MANDT"].alias("Client"), 
                mast_df["MATNR"].alias("ParentMaterialNumber"), 
                mast_df["WERKS"].alias("PrtChdWerks"), 
                mast_df["STLAN"].alias("PrtChdStlan"), 
                mast_df["STLAL"].alias("PrtChdStlal"),
                stko_lkenz_df["STKOZ"].alias("BomHeaderInternalCounter"), 
                stko_lkenz_df["LKENZ"].alias("BomHeaderDeletionIndicator"), 
                stko_lkenz_df["LOEKZ"].alias("BomHeaderDeletionFlag"), 
                stko_lkenz_df["DATUV"].alias("ChildDatuv"), 
                stko_lkenz_df["STLST"].alias("PrtChdStlst"), 
                stko_lkenz_df["BMEIN"].alias("ParentBmein"), 
                stko_lkenz_df["BMENG"].alias("ParentBmeng"),
                stpo_lkenz_df["STLTY"].alias("BomItemBomCategory"), 
                stpo_lkenz_df["STLNR"].alias("BillOfMaterialNumber"), 
                stpo_lkenz_df["STLKN"].alias("BomItemNodeNumber"), 
                stpo_lkenz_df["STPOZ"].alias("BomItemInternalCounter"), 
                stpo_lkenz_df["LKENZ"].alias("BOMItemDeletionIndicator"), 
                stpo_lkenz_df["IDNRK"].alias("ChildMaterialNumber"), 
                stpo_lkenz_df["POSTP"].alias("BomItemCategory"),
                stpo_lkenz_df["AEDAT"].alias("LastChangeDate"), 
                stpo_lkenz_df["POSNR"].alias("PrtChdPosnr"), 
                stpo_lkenz_df["MEINS"].alias("ChildMeins"), 
                stpo_lkenz_df["MENGE"].alias("ChildMenge"), 
                stas_lkenz_df["STASZ"].alias("BomItemSelectionInternalCounter"), 
                stas_lkenz_df["LKENZ"].alias("BomItemSelectionDeletionFlag")
            )
        
        # Get English descriptions
        logger.info("Fetching English descriptions.")
        makt_df_desc = makt_df.filter(col("SPRAS") == 'E').select("MATNR", "MAKTX").distinct()
        material_bom_multi_level_df_pdesc = material_bom_multi_level_df.alias("A").join(makt_df_desc.alias("B"), col("A.ParentMaterialNumber") == col("B.MATNR"), "left").drop("MATNR")
        material_bom_multi_level_df_pdesc = material_bom_multi_level_df_pdesc.withColumnRenamed("MAKTX", "ParentMaterialDescription")
        material_bom_multi_level_df_desc = material_bom_multi_level_df_pdesc.alias("A").join(makt_df_desc.alias("B"), col("A.ChildMaterialNumber") == col("B.MATNR"), "left").drop("MATNR")
        material_bom_multi_level_df_desc = material_bom_multi_level_df_desc.withColumnRenamed("MAKTX", "ChildMaterialDescription")
        #TODO: change PrtChdStlan filter values according to bu requirement 
        material_bom_multi_level_formatted_df = material_bom_multi_level_df_desc.filter(
        (col("PrtChdStlan") == '1') & (col("BomItemCategory") == 'L'))

        # Remove cyclic BOM occurrences
        logger.info("Filtering cyclic BOM occurrences.")
        material_bom_multi_level_formatted_df = material_bom_multi_level_formatted_df.filter(col("ChildMaterialNumber")!=col("ParentMaterialNumber"))
        #TODO: check 'MTART' column to fetch finished, raw materials in next iteration
        logger.info("Processing multi-level BOM and saving results.")
        material_bom_base_df = generate_is_sub_component_column(material_bom_multi_level_formatted_df)
        material_bom_base_df = generate_is_finished_product_column(material_bom_base_df)

        material_bom_base_df.write.mode("overwrite").saveAsTable(f"{target_catalog}.{bronze_schema}.plasmid_material_bom_base_{sap_source}")

        logger.info("Material BOM base got created successfully.")
    
    except Exception as e:
        logger.error(f"An error occurred during generating material BOM processing: {e}")
        raise(f"Exception: {e}")
