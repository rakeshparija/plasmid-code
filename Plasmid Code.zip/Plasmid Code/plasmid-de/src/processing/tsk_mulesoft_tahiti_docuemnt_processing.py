import requests
import json
import base64
import datetime
from pyspark.sql import SparkSession
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import zipfile
from azure.storage.blob import BlobServiceClient
from pyspark.dbutils import DBUtils
import io
from logs.logger import get_logger
# Configure logging
logger = get_logger()

def get_documents_from_databricks(spark: SparkSession, config: dict):
    """
    Fetches a list of documents from Databricks based on a timestamp filter.

    Args:
        spark (SparkSession): The active Spark session.
        config (dict): Configuration dictionary containing source catalog, schema, and table details.

    Returns:
        DataFrame: A Spark DataFrame containing the filtered documents.
    """
    source_catalog = config.get('TARGET_CATALOG')
    source_schema = config.get('SILVER_SCHEMA')
    source_table = config.get('TARGET_TABLE_NAME_DIR_SAP_METADATA')
    log_table = f"{target_catalog}.{target_schema}.{target_log_table}"

    # Calculate the start date (1 day ago)
    try:
        last_processed_date = spark.sql(f"select max(DirUpdatedAt) from {log_table} where ErpSystemId='tahiti' ").collect()[0][0]
        if last_processed_date is not None:
            start_date = last_processed_date
            logger.info(f"Fetched documents which are updated after last processing date: {start_date}")
        else:
            logger.info(f"Last processed date is empty. Fetching documents which are updated in last 7 days")
            start_date = (datetime.datetime.now() - datetime.timedelta(days=8)).strftime('%Y%m%d')
    except Exception as e:
        start_date = (datetime.datetime.now() - datetime.timedelta(days=8)).strftime('%Y%m%d')
        logger.info(f"Error in getting last processed date, Using start_date: {start_date}")
    
    end_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y%m%d')
    
    logger.info(f"Start Date: {start_date}")
    logger.info(f"End Date: {end_date}")

    query = f"""
        SELECT DocArea,
               DocNumber, 
               DocVersion,
               DocPart,
               Source,
               Status,
               BusinessUnit,
               LastUpdatedAt
        FROM {source_catalog}.{source_schema}.{source_table} 
        WHERE LastUpdatedAt > '{start_date}' AND LastUpdatedAt <= '{end_date}' AND Source = 'tahiti'
    """

    logger.info(f"Executing query: {query}")


    # Fetch the required data
    df = spark.sql(query)

    # Mapping column names to expected format
    results = [
        {
            "documentNumber": row["DocNumber"],  # Mapping doc_no to documentNumber
            "documentType": "DMS",  # Static value as required
            "dmsDocType": row["DocArea"],  # Mapping doc_type to dmsDocType
            "dmsDocPart": row["DocPart"],  # Mapping doc_part to dmsDocPart
            "dmsDocVersion": row["DocVersion"],  # Mapping doc_version to dmsDocVersion
            "erpSystemID": row["Source"],
            "docStatus": row["Status"],
            "business_unit": row["BusinessUnit"],
            "dirUpdatedAt": row["LastUpdatedAt"]
        }
        for row in df.collect()
    ]
    
    return results


def update_metadata_table(spark, document, file_name, document_blob_link, file_type):
    """Insert a metadata entry into the api_log_table in Databricks."""
    try:
        metadata_entry = [{
            "DirNumber": document["documentNumber"],
            "DirDocType": document["dmsDocType"],
            "DirDocVersion": document["dmsDocVersion"],
            "DirDocPart": document["dmsDocPart"],
            "DirDocStatus": document["docStatus"],
            "DirUpdatedAt": document["dirUpdatedAt"],
            "FileName": file_name,
            "FileType": file_type,
            "FileBlobLink": document_blob_link,
            "LastUpdatedAt": datetime.datetime.now().isoformat(),
            "Username": "Sigmoid",
            "Source": document["erpSystemID"],
            "BusinessUnit": document["business_unit"]
        }]

        metadata_schema = "DirNumber STRING, DirDocType STRING, DirDocVersion STRING, DirDocPart STRING, DirDocStatus STRING, DirUpdatedAt STRING, FileName STRING, FileType STRING, FileBlobLink STRING, LastUpdatedAt STRING, Username STRING, Source STRING, BusinessUnit STRING"

        metadata_df = spark.createDataFrame(metadata_entry, schema=metadata_schema)
        metadata_table = f"{target_catalog}.{target_schema}.{target_metadata_table}"

        metadata_df.write.format("delta").mode("append").saveAsTable(metadata_table)

        logger.info(f"metadata entry inserted for document: {document['documentNumber']}")
    except Exception as e:
        logger.error(f"Error inserting metadata entry: {e}")
        raise(f"Error inserting metadata entry: {e}")


def update_log_table_document_status(spark, document, status_code, response_text):
    """Insert a log entry into the api_log_table in Databricks with exception handling and logging."""
    try:
        log_entry = [{
            "ErpSystemId": "tahiti",
            "Username": "Sigmoid",
            "DirNumber": document["documentNumber"],
            "DirDocType": document["dmsDocType"],
            "DirDocPart": document["dmsDocPart"],
            "DirDocVersion": document["dmsDocVersion"],
            "DirDocStatus": document["docStatus"],
            "DirUpdatedAt": document["dirUpdatedAt"],
            "Status": "Success" if status_code == 200 else "Error",
            "ErrorMessage": "None" if status_code == 200 else response_text,
            "StatusCode": status_code,
            "LastUpdatedAt": datetime.datetime.now().isoformat(),
            "BusinessUnit": document["business_unit"]
        }]

        schema = "ErpSystemId STRING, Username STRING, DirNumber STRING, DirDocType STRING, DirDocPart STRING, DirDocVersion STRING, DirDocStatus STRING, DirUpdatedAt STRING, Status STRING, ErrorMessage STRING, StatusCode INT, LastUpdatedAt STRING, BusinessUnit STRING"
        log_table = f"{target_catalog}.{target_schema}.{target_log_table}"
        log_df = spark.createDataFrame(log_entry, schema=schema)
        
        # Attempt to write log entry to Databricks table
        log_df.write.format("delta").mode("append").saveAsTable(log_table)
        logger.info(f"Log entry inserted for document: {document['documentNumber']} with status: {status_code}")

    except Exception as e:
        logger.error(f"Error inserting log entry for document {document['documentNumber']}: {str(e)}")
        raise(f"Error inserting log entry for document {document['documentNumber']}: {str(e)}")


@retry(
    retry=retry_if_exception_type(requests.exceptions.RequestException),
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=2, min=1, max=10)
)
def make_request(headers, payload, document, spark):
    try:
        logger.info(f"Fetching documents for this payload: {payload}")
        response = requests.post(mulesoft_url, headers=headers, data=payload, verify=False, timeout=300)
        response.raise_for_status()
        return response
    except requests.exceptions.Timeout as e:
        logger.error(f"Timeout error for document {document['documentNumber']}: {e}")
        update_log_table_document_status(spark, document, 408, "Request Timeout")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error for document {document['documentNumber']}: {e}")
        update_log_table_document_status(spark, document, 500, str(e))
        return None



def mulesoft_document_api_processing(spark, config):
    
    global mulesoft_url, target_catalog, target_schema, target_log_table, target_metadata_table
    keyvault_scope = config['KEYVAULT_SCOPE']
    dbutils = DBUtils(spark)
    mulesoft_url = dbutils.secrets.get(scope=keyvault_scope, key='MULESOFT-API-ENDPOINT')
    mulesoft_username = dbutils.secrets.get(scope=keyvault_scope, key='MULESOFT-API-USERNAME')
    mulesoft_password = dbutils.secrets.get(scope=keyvault_scope, key='MULESOFT-API-PASSWORD')
    target_catalog = config['TARGET_CATALOG']
    target_schema = config['SILVER_SCHEMA']
    bronze_schema = config['BRONZE_SCHEMA']
    target_log_table = config['TARGET_TABLE_NAME_MULESOFT_API_LOGS']
    target_metadata_table = config['TARGET_TABLE_NAME_FILE_METADATA']
    unstructured_schema = config['UNSTRUCTURED_SCHEMA_tahiti']
    source = 'tahiti'
    env = config['ENV']
    documents_metadata_details = get_documents_from_databricks(spark, config)
    import os

    logger.info(f"Found {len(documents_metadata_details)} documents to process.")
    for document in documents_metadata_details:
        doc_number = document["documentNumber"]
        logger.info(f"Processing document: {doc_number}")

        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + base64.b64encode(f"{mulesoft_username}:{mulesoft_password}".encode()).decode()
        }

        payload = json.dumps({
            "erpDocumentRequest": {
                "erpSystemID": document["erpSystemID"],
                "requestingSystemName": "Sigmoid",
                "documentNumber": document["documentNumber"],
                "documentType": document["documentType"],
                "dmsDocType": document["dmsDocType"],
                "dmsDocPart": document["dmsDocPart"],
                "dmsDocVersion": document["dmsDocVersion"]
            }
        })

        # Initialize Blob Service Client
        if env == 'sbx':
            keyvault_scope  = config['KEYVAULT_SCOPE']
            storage_name = dbutils.secrets.get(scope=keyvault_scope, key ='BLOB-STORAGE-ACCOUNT-NAME')
            account_key = dbutils.secrets.get(scope=keyvault_scope, key='BLOB-STORAGE-ACCESS-KEY')
            BLOB_CONNECTION_STRING = f"DefaultEndpointsProtocol=https;AccountName={storage_name};AccountKey={account_key};EndpointSuffix=core.windows.net"
            blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
            blob_container = config['UNSTRUCTURED_CONTAINER']
        try:
            response = make_request(headers, payload, document, spark)
            if response is None:
                logger.warning(f"Skipping document {document['documentNumber']} due to failed API call.")
                continue

            if response.status_code == 200:
                logger.info(f"Successfully fetched document {document['documentNumber']}.")
                
                content_type = response.headers.get("Content-Type")
                logger.info(f"Content-Type: {content_type}")

                update_log_table_document_status(spark, document, response.status_code, None)
                logger.info(f"Updated document status in log table")

                if "application/pdf" in content_type:
                    dn = document['documentNumber'].lstrip("0")
                    filename = f"{document['dmsDocType']}_{dn}_{document['dmsDocPart']}_{document['dmsDocVersion']}_{document['docStatus']}.pdf"

                    if env == 'sbx':
                        blob_file_path = f"{source}/sap_files/raw/{filename}"
                        blob_client = blob_service_client.get_blob_client(container=blob_container, blob=blob_file_path)

                        # Upload PDF file directly to Azure Blob Storage
                        blob_client.upload_blob(response.content, overwrite=True)
                    else:
                        # Save PDF directly
                        
                        blob_file_path = f"/Volumes/{target_catalog}/{unstructured_schema}/{source}/sap_files/raw/{filename}"
                        os.makedirs(
                            os.path.dirname(blob_file_path),
                            exist_ok=True
                        )
                        with open(blob_file_path, 'wb') as f:
                            f.write(response.content)

                    logger.info(f"Uploaded PDF: {blob_file_path} to Azure Blob Storage")
                    
                    update_metadata_table(spark, document, filename, blob_file_path, "pdf")
                    logger.info(f"Updated metadata table for PDF file")

                elif "application/octet-stream" in content_type:
                    try:
                        # Read ZIP file from response
                        zip_file = zipfile.ZipFile(io.BytesIO(response.content))

                        # Extract and upload each file inside the ZIP
                        for file_name in zip_file.namelist():
                            dn = document['documentNumber'].lstrip("0")
                            if env == 'sbx':
                                blob_file_path = f"{source}/sap_files/raw/{document['dmsDocType']}_{dn}_{document['dmsDocPart']}_{document['dmsDocVersion']}_{document['docStatus']}_{filename}"
                                
                                blob_client = blob_service_client.get_blob_client(container=blob_container, blob=blob_file_path)

                                # Read file and upload directly
                                with zip_file.open(file_name) as file_ref:
                                    blob_client.upload_blob(file_ref.read(), overwrite=True)
                                # Upload PDF file directly to Azure Blob Storage
                                # blob_client.upload_blob(response.content, overwrite=True)
                            else:
                                # Save PDF directly
                                
                                blob_file_path = f"/Volumes/{target_catalog}/{unstructured_schema}/{source}/sap_files/raw/{dn}_{document['dmsDocType']}_{document['dmsDocPart']}_{document['dmsDocVersion']}_{document['docStatus']}_{filename}"
                                os.makedirs(
                                    os.path.dirname(blob_file_path),
                                    exist_ok=True
                                )
                                
                                with zip_file.open(file_name) as file_ref:
                                    # blob_client.upload_blob(file_ref.read(), overwrite=True)
                                    with open(blob_file_path, 'wb') as f:
                                        f.write(file_ref.read())
                            

                            logger.info(f"Uploaded: {blob_file_path} to Azure Blob Storage")
                            update_metadata_table(spark, document, file_name, blob_file_path, file_name.split(".")[-1])
                            logger.info(f"Updated metadata table")
                    except zipfile.BadZipFile:
                        logger.warning("The content appears to be binary but not a valid ZIP file. Consider inspecting its format.")

                else:
                    logger.warning("Unknown content type received. Manual inspection required.")
            else:
                update_log_table_document_status(spark, document, response.status_code, response.text)
                logger.error(f"Failed to fetch document {document['documentNumber']}. Error: {response.text}")
            logger.info(f"Successfully fetched and stored document {document['documentNumber']}.")
        except requests.exceptions.RequestException as e:
            update_log_table_document_status(spark, document, response.status_code, response.text)
            logger.error(f"Failed to fetch document {document['documentNumber']}. Error: {response.text}")

