from pyspark.sql.functions import regexp_replace, col, lit
from logs.logger import get_logger

# Configure logging
logger = get_logger()

def get_level_1_components(spark, config):
    """ Fetches and processes level 1 BOM components. """

    try:
        logger.info("Initializing level 1 components extraction.")
        # Extract relevant values from config
        source_catalog = config['TARGET_CATALOG']
        source_schema = config['SILVER_SCHEMA']
        source_table = config['TARGET_TABLE_NAME_COMPONENT_BU_DETAILS']

        target_catalog = config['TARGET_CATALOG']
        target_schema = config['GOLD_SCHEMA']
        target_table = config['TARGET_TABLE_COMPONENTS_FIRST_LEVEL']
        final_table = f"{target_catalog}.{target_schema}.{target_table}"

        logger.info("Executing SQL query to fetch level 1 components.")
        df_level_1_components = spark.sql(f"""
            SELECT DISTINCT
                ParentMaterialNumber as parent_id,
                ChildMaterialNumber as child_id,
                PrdctMtrlst as alternative_bom,
                PrtchPlants as plant_id,
                ParentMaterialDescription as parent_description,
                ChildMaterialDescription as child_description,
                ChildBOMas component_valid_from_date,
                ChildBOMto as component_valid_to_date,
                BusinessUnit as business_unit,
                Source as source
            FROM {source_catalog}.{source_schema}.{source_table}
            WHERE level = 1 and (PrdctMtrlst in ('1', '01'))
        """)

        logger.info(f"Number of records in level 1 components: {df_level_1_components.count()}")

        # Save result to Delta table
        logger.info(f"Saving level 1 components table: {final_table}")
        df_level_1_components.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(final_table)

        # Add indexes on parent_id and child_id
        logger.info(f"Optimizing table {final_table} with ZORDER indexing.")
        spark.sql(f"OPTIMIZE {final_table} ZORDER BY (parent_id, child_id);")

        logger.info("Level 1 components processing completed successfully.")

    except Exception as e:
        logger.error(f"An error occurred while processing level 1 components: {e}")
        raise(f"Exception: {e}")
