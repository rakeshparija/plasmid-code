1  from pyspark.sql.functions import col, regexp_replace
2  from logs.logger import get_logger
3
4  # Configure logging
5  logger = get_logger()
6
7  def process_bom_component_merge(spark, config):
8      """ Function to process and merge BOM data for MZLE and Plasticpack components. """
9
10     logger.info("Initializing BOM component merge process.")
11
12     # Extract relevant values from config
13     target_catalog = config["TARGET_CATALOG"]
14     silver_schema = config["SILVER_SCHEMA"]
15     bronze_schema = config["BRONZE_SCHEMA"]
16     flatten_table_name_tahiti = config["MATERIAL_FLATTENED_TAHITI"]
17     flatten_table_name_everest = config["MATERIAL_FLATTENED_EVEREST"]
18     material_table_name_mzle = config["MATERIAL_TABLE_NAME_MZLE"]
19     material_table_name_plasticpack = config["MATERIAL_TABLE_NAME_PLASTIPAK"]
20     target_component_table_name = config["TARGET_TABLE_NAME_COMPONENT_BU_DETAILS"]
21
22     # Query MZLE-related BOM data
23     logger.info("Fetching MZLE BOM data.")
24     mz_bom_df = spark.sql(
25         f"""
26         SELECT ParentMaterialNumber, ParentMaterialDescription,
27                ChildMaterialNumber, ChildMaterialDescription,
28                PrtChdStal, PrtChdStal,
29                ChildDataV, '31-Dec-1999' AS ComponentValidTillDate,
30                PrtChdWerks, Level, PrtChdPosnr,
31                IsRawMaterial, IsSubComponent,
32                IsFinishedProduct, 'mzle' AS BusinessUnit, PrtChdStlst, 'tahiti' AS Source
33         FROM {target_catalog}.{bronze_schema}.{flatten_table_name_tahiti}
34         WHERE ParentMaterialNumber IN (
35             SELECT Material FROM {target_catalog}.{silver_schema}.{material_table_name_mzle}
36         )
37         """
38     )
39     logger.info(f"Number of records in MZLE BOM data: {mz_bom_df.count()}")
40
41     # Query Plasticpack-related BOM data
42     logger.info("Fetching Plasticpack BOM data.")
43     para_bom_df = spark.sql(
44         f"""
45         SELECT ParentMaterialNumber, ParentMaterialDescription,
46                ChildMaterialNumber, ChildMaterialDescription,
47                PrtChdStal, PrtChdStal,
48                ChildDataV, '31-Dec-1999' AS ComponentValidTillDate,
49                PrtChdWerks, Level, PrtChdPosnr,
50                IsRawMaterial, IsSubComponent,
51                IsFinishedProduct, 'plastipak' AS BusinessUnit, PrtChdStlst, 'everest' AS Source
52         FROM {target_catalog}.{bronze_schema}.{flatten_table_name_everest}
53         WHERE ParentMaterialNumber IN (
54             SELECT Material FROM {target_catalog}.{silver_schema}.{material_table_name_plasticpack}
55         )
56         """
57     )
58     logger.info(f"Number of records in Plasticpack BOM data: {para_bom_df.count()}")
59
60     # Merge both dataframes
61     logger.info("Merging BOM data for MZLE and Plasticpack.")
62     final_df = mz_bom_df.union(para_bom_df)
63
64     # Clean leading zeros from key columns
65     logger.info("Cleaning leading zeros from key columns.")
66     final_df = final_df.withColumn("ParentMaterialNumber", regexp_replace(col("ParentMaterialNumber"), '^0+', ''))
67     final_df = final_df.withColumn("ChildMaterialNumber", regexp_replace(col("ChildMaterialNumber"), '^0+', ''))
68     final_df = final_df.withColumn("PrtChdWerks", regexp_replace(col("PrtChdWerks"), '^0+', ''))
69
70     logger.info(f"Number of records in final BOM data: {final_df.count()}")
71
72     # Save to Delta Table
73     logger.info(f"Saving final BOM data to {target_catalog}.{silver_schema}.{target_component_table_name}.")
74     final_df.write.mode("overwrite").format("delta").option("overwriteSchema", "true") \
75         .saveAsTable(f"{target_catalog}.{silver_schema}.{target_component_table_name}")
76
77     logger.info(f"Table saved successfully: {target_catalog}.{silver_schema}.{target_component_table_name}")
78
79 except Exception as e:
80     logger.error(f"An error occurred during BOM component merge process: {e}")
81     raise(f"Exception: {e}")
