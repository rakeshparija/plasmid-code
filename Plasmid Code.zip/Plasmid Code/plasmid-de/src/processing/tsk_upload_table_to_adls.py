from pyspark.dbutils import DBUtils
from logs.logger import get_logger
logger = get_logger()


def upload_table_to_blob(spark, config):

    dbutils = DBUtils(spark)
    catalog = config['TARGET_CATALOG']
    keyvault_scope = config['KEYVAULT_SCOPE']
    storage_name = dbutils.secrets.get(scope=keyvault_scope, key='ADLS-ACCOUNT-NAME')
    account_key = dbutils.secrets.get(scope=keyvault_scope, key='ADLS-CONNECTION-STRING')
    spark.conf.set(
        f"fs.azure.account.key.{storage_name}.blob.core.windows.net",
        account_key
    )

    # Define schemas and selected tables
    selected_tables = {
        "s_plasmid": ["plasmid_document_details", "plasmid_data_transformation", ""],
        "g_plasmid": ["plasmid_summary", "plasmid_linkages"]
    }

    # Iterate through each schema and table
    for schema, tables in selected_tables.items():
        for table_name in tables:
            source_table = f"{catalog}.{schema}.{table_name}"
            destination_path = f"wasbs://ocr-container@{storage_name}.blob.core.windows.net/{schema}/{table_name}/"

            try:
                (
                    spark.table(source_table)
                         .write
                         .format("delta")
                         .mode("overwrite")
                         .save(destination_path)
                )
                logger.info(f"✅ Uploaded {source_table} to {destination_path}")
            except Exception as e:
                logger.error(f"⚠️ Failed to upload {source_table}: {str(e)}")
