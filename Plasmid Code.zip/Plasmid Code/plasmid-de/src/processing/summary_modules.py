import re
from openai import AzureOpenAI


def parse_incomplete_str(input_str):
    output = re.sub(r'\s+',' ',input_str)
    output = output[::-1]
    idx=output.find('}')
    output=output[idx:]
    output=output[::-1]
    output+=']'
    output+='}'
    return output 


def extract_content_from_text(input_text, api_key, api_version, azure_endpoint, summary_model_name):
    """
    Extract content from text file.
    """
    client = AzureOpenAI(
    api_key=api_key,
    api_version = api_version,
    azure_endpoint=azure_endpoint,
    )

    # Defining prompt for GPT response
    response = client.chat.completions.create(
        model=summary_model_name,
        messages=[
            {
                "role": "system",
                "content": '''I am an expert in extracting section-wise summary, classifying documents from the text. My tasks include:

                1. Section Identification: Recognizing and categorizing all distinct sections within the given text.
                2. Detailed Summarization: Extracting a concise yet comprehensive summary for each identified section.
                3. Incorporating Key Details: Ensuring that all relevant information, including all document names, components, SKUs, reference IDs, specification IDs, ISO numbers, PRD numbers, Record number, DIR, Protocols, and any other essential identifiers, are retained within the summary.
                4. Table/Bullet Point Extraction: Summarizing tables and bullet points within each section, ensuring that key details as mentioned above are retained for each row or item. Do not create separate summaries for tables or bullet points outside the section.
                5. Maintaining Context: Ensuring that each section summary aligns with the overall structure and meaning of the document.

                Task:
                1. Extract summaries of all sections present in the given text. Provide the answer in JSON format.
                2. Create as many sections as possible based on the content of the document, don't restrict the sections to a specific number.
                3. Output Answer should not exceed 3000 tokens
                '''
            },
            {
                "role": "system",
                "content": '''Give answer in the following **JSON Format** by limiting the output token count at 2000:

                {'sections':[
                    
                    {
                        "text_type": "sectional_summary",
                        "granularity": "Section: Name of section 1",
                        "text": "Summary of section 1 by mentioning the section name at the start of summary. If the section contains tables or bullet points, then summarize row 1, row 2, etc., without creating different sections for tables or bullet points outside the section."
                    },
                    {
                        "text_type": "sectional_summary",
                        "granularity": "Section: Name of section 2",
                        "text": "Summary of section 2 by mentioning the section name at the start of summary. If the section contains tables or bullet points, then summarize row 1, row 2, etc., without creating different sections for tables or bullet points outside the section."
                    },
                    {
                        "text_type": "sectional_summary",
                        "granularity": "Section: Name of section 3",
                        "text": "Summary of section 3 by mentioning the section name at the start of summary. If the section contains tables or bullet points, then summarize row 1, row 2, etc., without creating different sections for tables or bullet points outside the section."
                    },
                    {
                        "text_type": "document_summary",
                        "granularity": "overall document summary",
                        "text": "Mention the overall document summary in 3-4 lines considering different sections present in the document."
                    },
                    {
                        "text_type": "design_verification_test_details",
                        "granularity": "Design Verification Test Details",
                        "text": "Does this document have test results or details of product testing or results from product testing or protocol detected during testing? If yes, then extract all the details around test names, test procedure, test result, test protocol, and deviations detected. If the product specification for any test is mentioned, also capture that detail.
                        For example - Biocompatibility test can be mentioned as follows: Biological evaluation,Genotoxicity, Carcinogenicity, cytotoxicity, Hemocompatibility , Hemolysis ,Pyrogenicity 

                        "
                    },
                    {
                        "text_type": "design_verification_test_deviation",
                        "granularity": "Design Verification Test Deviation",
                        "text": "Are there any mentions of deviations/exceptions/test failures mentioned in this document? If such mentions are there, then get details of the deviations/test failures along with the test name, protocol, and product requirement corresponding to that test. If there is no specific mention of deviation, then return No. Start the answer with Yes or No, then provide a detailed explanation."
                    },
                    {
                        "text_type": "abbreviation_list",
                        "granularity": "Abbreviation List",
                        "text": "If the document contains any abbreviations or acronyms, then store them here in the format, Abbreviation Name - Full Form. Do not assume anything from your end, only store if anything is directly mentioned in the document. If nothing is present then return NA"
                    },
                    ,
                    {
                        "text_type": "document_title",
                        "granularity": "doc_title",
                        "text": "Usually the title of the document is mentioned at the top of beginning of the document. First few lines of the document first page indicates document title, extract the title in 2-3 lines max and store it here"
                    },
                    {
                        'text_type':'lifecycle_labels',
                        'granularity':'lifecycle_labels',
                        'text':'# Medical Device Document Classifier

                        You are a domain expert assistant that classifies documents from a medical device manufacturer's system. Each document may relate to different aspects of the product lifecycle. Your job is to assign accurate lifecycle labels based on the document's content. Return only valid JSON.


                        ## Lifecycle Labels

                        1. requirements: Documents that define user needs, intended use, regulatory inputs, or system/product requirements.
                        Examples: URS, PRS, intended use statements.

                        2. scoping: Documents that contain information related to product scoping or planning.
                        Examples: project charters, scope statements.

                        3. design: Documents that describe product specifications, components, labeling, design outputs, or configurations.
                        Examples: CAD files, drawings, BOMs, design specifications.

                        4. risk management: Documents related to identifying and mitigating risks.
                        Examples: PFMEA, DFMEA, fault tree analysis, risk control plans.

                        5. testing: Documents describing verification, validation, or test results.
                        Examples: test protocols, IQ/OQ/PQ reports, acceptance criteria, V&V plans.

                        6. testing methods: Documents that detail testing procedures and methodologies.
                        Examples: in-process inspections, verification test methods, incoming inspections.

                        7. compliance: Documents created for regulatory submissions, audit readiness, or notified body interactions.
                        Examples: FDA submissions, CE technical files, audit responses.

                        8. manufacturing: Documents detailing production processes, materials, or supplier information.
                        Examples: DMRs, work instructions, process validations.

                        9. supplier: Documents provided by third-party suppliers.
                        Examples: quality agreements, purchasing specifications, supplier audits.

                        10. postmarket: Documents covering monitoring and surveillance after product launch.
                        Examples: PMCF reports, PSURs, field data analyses.

                        11. complaints: Documents involving product issues, customer feedback, CAPAs, or nonconformances.
                        Examples: complaint logs, investigation reports, recall records.

                        12. launch: Documents related to product introduction, go-to-market planning, or initial distribution.
                        Examples: launch checklists, readiness reviews, labeling plans.

                        13. customer: Documents intended for customer use or communication.
                        Examples: customer drawings and specifications, labeling, customer quality agreements, customer notifications.

                        14. discontinuation: Documents discussing product obsolescence, market withdrawal, or end-of-life planning.
                        Examples: phase-out notices, retirement memos.


                        ## Classification Rules:

                        1. Only assign labels if clearly supported by the document's. Atleast one tag must always be assigned, never return an empty list.
                        2. If a document spans multiple lifecycle stages, assign all relevant labels
                        3. Do not guess—assign only when content is explicitly relevant.
                        4. Do not capitalize or change spellings.
                        5. Use labels **only** from the list above.


                        ## Output Format

                        Return a valid list in this format:
                         ["label1", "label2" , and so on]'
                    },
{
                        'text_type':'content_labels',
                        'granularity':'content_labels',
                        'text':'# Medical Device Document Classifier
                        You are a domain expert assistant that classifies document from a medical device manufacturer's system. These labels identify common types of content found in medical device documents. Your job is to assign  accurate labels  to these documents on basis of the contents of the document.  Return only valid JSON. 

                        ## Content Labels:

                        1. vv_test_result — Documents with results or summaries from verification and/or validation activities.  
                        Examples: completed IQ/OQ/PQ protocols, validation reports, verification summaries.

                        2. drawing — Technical or CAD illustrations that define physical layout or part specifications.  
                        Examples: mechanical drawings, design blueprints, schematics.

                        3. sop_instruction — Step-by-step documents describing procedures or standardized work.  
                        Examples: SOPs, work instructions, cleaning procedures.

                        4. product_spec — Documents defining specs for a product, subcomponent, or packaging.  
                        Examples: component specs, labeling specs, packaging specs.

                        5. input_doc — Documents describing initial requirements, intended use, or user needs.  
                        Examples: URS, PRS, intended use statement, regulatory input.

                        6. trace_matrix — Tables linking requirements to design, risks, or tests.  
                        Examples: requirement-to-test matrix, input-output mappings.

                        7. plan_doc — Documents outlining project scope, plans, or strategies.  
                        Examples: validation plans, design plans, project schedules.

                        8. change_order — Documents that record approved changes to products or processes.  
                        Examples: engineering change orders (ECO), change notifications.

                        9. test_method — Documents describing how testing should be performed.  
                        Examples: inspection instructions, test procedures, sampling plans.

                        10. label — Labeling content attached to or included with the device.  
                            Examples include: UDI labels, IFUs, device stickers, case or shelf graphics

                        11. supplier_doc — Documentation exchanged with or received from suppliers.  
                            Examples: quality agreements, audit reports, vendor specs.

                        12. process_validation — Evidence that manufacturing processes or equipment are validated.  
                            Examples: equipment qualification reports, process validation protocols.

                        13. regulatory_doc — Documentation prepared for regulatory bodies or audits.  
                            Examples: FDA submissions, CE technical files, GSPR checklists.

                        14. change_control — Internal forms used to initiate or assess changes.  
                            Examples include: change control records, change justifications, assessment of change requirements

                        15. clinical_eval — Documents assessing clinical safety or performance.  
                            Examples: clinical evaluation reports (CER), PMCF data.

                        16. risk_doc — Documents used for identifying, analyzing, and mitigating risks.  
                            Examples: DFMEA, PFMEA, hazard analysis.

                        17. defect_record — Documents capturing product failures or quality issues.  
                            Examples: CAPAs, nonconformance reports, deviation logs.

                        18. customer_doc — Content created for or received from a customer.  
                            Examples: customer specs, feedback forms, customer agreements.

                        19. design_review — Records from formal design reviews at any lifecycle stage.  
                            Examples: review meeting minutes, review checklists, approval logs.

                        ## Classification Rules:

                        1. Only assign labels if clearly supported by the document's. Atleast one tag must always be assigned, never return an empty list.
                        2. If a document contains content related to multiple labels, assign all relevant labels
                        3. Do not guess—assign only when content is explicitly relevant.
                        4. Do not capitalize or change spellings.
                        5. Use labels **only** from the list above.


                        ## Output Format
                        Return a valid list object in this format:
                        ["label1", "label2" , and so on]'
                    },
                    
                ]
                '''
            },
            {
                "role": "user",
                "content": input_text
            }
            
        ],
        temperature=0.1,
        response_format={"type": "json_object"}
    )
        
    return response.choices[0].message.content