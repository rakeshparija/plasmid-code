from pyspark.sql.functions import col, udf, explode, lit
from pyspark.sql.types import (
    ArrayType,
    StructType,
    StructField,
    StringType,
    IntegerType,
    FloatType,
)
from pyspark.sql.functions import col, collect_list, explode, struct, regexp_replace, when
from pyspark.dbutils import DBUtils
from datetime import import datetime
from logs.logger import get_logger
logger = get_logger()


def process_ocr_metadata(item):
    page_token_counts = []
    for page_text in item:
        word_count = len(page_text.split())
        token_count = round(word_count * 4 / 3)
        page_token_counts.append(token_count)
    total_token_count = sum(page_token_counts)
    num_pages = len(item)
    num_chunks = int(total_token_count/20000 + 1)
    chunk_size = int(num_pages // num_chunks)
    overlap_size = 2

    indices = [(max(0, j * chunk_size - overlap_size), min(num_pages, (j + 1) * chunk_size + overlap_size)) for j in range(num_chunks)]
    unique_indices = set(indices)

    indices = list(unique_indices)


    return {
        "num_pages": num_pages,
        "chunk_size": chunk_size,
        "total_token_count": total_token_count,
        "num_chunks": num_chunks,
        "indices": indices,
        "chunk_indices": [(0, num_pages)]
    }


def create_data_transformation(spark, config):
    try:
        catalog = config['TARGET_CATALOG']
        schema = config['SILVER_SCHEMA']
        input_table = config['TARGET_TABLE_NAME_OCR_RESULTS']
        output_table = config['TARGET_TABLE_NAME_DATA_TRANSFORMATION']
        keyvault_scope = config['KEYVAULT_SCOPE']
        dbutils = DBUtils(spark)
        storage_name = dbutils.secrets.get(scope=keyvault_scope, key='ADLS-ACCOUNT-NAME')
        account_key = dbutils.secrets.get(scope=keyvault_scope, key='ADLS-CONNECTION-STRING')
        spark.conf.set(
        f"fs.azure.account.key.{storage_name}.blob.core.windows.net",
        account_key
        )
        # spark.sql(f"update {catalog}.{schema}.{input_table} set is_post_ocr='no' ")
        # spark.sql(f"DROP TABLE IF EXISTS {catalog}.{schema}.{output_table}")

        process_ocr_metadata_udf = udf(
        process_ocr_metadata,
        StructType([
            StructField("num_pages", IntegerType(), False),
            StructField("chunk_size", IntegerType(), False),
            StructField("total_token_count", IntegerType(), False),
            StructField("num_chunks", IntegerType(), False),
            StructField("indices", ArrayType(StructType([
                StructField("_1", IntegerType(), False),
                StructField("_2", IntegerType(), False)
            ])), False),
            StructField("chunk_indices", ArrayType(StructType([
                StructField("_1", IntegerType(), False),
                StructField("_2", IntegerType(), False)
            ])), False)
        ])
        )

        spark_df = spark.read.table(f"{catalog}.{schema}.{input_table}").filter((col("Status") == "OK") & (col("IsPostOcr")=='no')).select("DocName", "BlobPath", "DirNumber", "Status", "Ocr", "Source", "BusinessUnit")

        if spark_df.count() == 0:
            logger.info("No new records to process")
            return

        modified_df = spark_df.withColumn("pdf_metadata", process_ocr_metadata_udf(col("Ocr")))

        # Extracting values of pdf_metadata as separate columns
        modified_df = modified_df.select(
        "*",
        col("pdf_metadata.num_pages").alias("NumPages"),
        col("pdf_metadata.chunk_size").alias("ChunkSize"),
        col("pdf_metadata.total_token_count").alias("TotalTokenCount"),
        col("pdf_metadata.num_chunks").alias("NumChunks"),
        col("pdf_metadata.indices").alias("Indices"),
        col("pdf_metadata.chunk_indices").alias("ChunkIndices")
        )
        modified_df = modified_df.drop("pdf_metadata")
        # modified_df = modified_df.drop("parsing_method")
        modified_df = modified_df.withColumn("IsSummary",lit("no"))
        modified_df = modified_df.withColumn("IsChunking",lit("no"))
        modified_df = modified_df.withColumn("IsLinkages",lit("no"))
        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        modified_df = modified_df.withColumn("LastUpdatedAt",lit(current_timestamp))
        # modified_df = modified_df.withColumn("original_doc_name", regexp_replace("doc_name", r"_plasmid_subpart_\d+\.pdf$", ".pdf"))
        # modified_df = modified_df.withColumn("business_unit", when( col("source") == "Everest",
        #                                                        lit('plastipak'))
        #          ).otherwise(lit('mzle')))

        from delta.tables import DeltaTable

        # Example: Composite key on id and date
        merge_condition = """
        target.DocName = source.DocName
        """

        try:

            # Load Delta table
            delta_table = DeltaTable.forName(spark, f"{catalog}.{schema}.{output_table}")
            logger.info("Delta Table Found")

            # Perform merge with multiple match conditions
            delta_table.alias("target").merge(
                source=modified_df.alias("source"),
                condition=merge_condition
            ).whenNotMatchedInsertAll().execute()

        except Exception as e:
            logger.info(f"Delta Table not Found: {e}")
            modified_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{catalog}.{schema}.{output_table}")

            modified_df.createOrReplaceTempView("modified_df")

            spark.sql(f"""
            MERGE INTO {catalog}.{schema}.{input_table} AS target
            USING modified_df AS source
            ON target.DocName = source.DocName
            WHEN MATCHED THEN
            UPDATE SET target.IsPostOcr = 'yes'
            """)

        logger.info("Data transformation completed")
    except Exception as e:
        logger.error(f"Error in data transformation: {e}")
        raise e