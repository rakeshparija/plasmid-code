import json
import requests
from pyspark.dbutils import DBUtils
from logs.logger import get_logger
logger = get_logger()


def create_index(spark, config):
    index_name = "plasmid_aisearch"
    dbutils = DBUtils(spark)
    keyvault_scope = config['KEYVAULT_SCOPE']
    payload = {
        "name": index_name,
        "fields": [
            {
                "name": "id",
                "type": "Edm.String",
                "key": True,
                "searchable": False,
                "filterable": False,
                "retrievable": True,
                "facetable": False,
            },
            {
                "name": "dir_number",
                "type": "Edm.String",
                "filterable": True,
                "searchable": False,
                "facetable": False,
                "retrievable": True,
                "sortable": False
            },
            {
                "name": "doc_name",
                "type": "Edm.String",
                "filterable": True,
                "searchable": False,
                "facetable": False,
                "retrievable": True,
                "sortable": False
            },
            {
                "name": "text_type",
                "type": "Edm.String",
                "filterable": True,
                "searchable": False,
                "facetable": False,
                "retrievable": True,
                "sortable": False
            },
            {
                "name": "source",
                "type": "Edm.String",
                "filterable": True,
                "searchable": False,
                "facetable": False,
                "retrievable": False,
                "sortable": False
            },
            {
                "name": "business_unit",
                "type": "Edm.String",
                "filterable": True,
                "searchable": False,
                "facetable": False,
                "retrievable": False,
                "sortable": False
            },
            {
                "name": "page_number",
                "type": "Edm.Int32",
                "filterable": False,
                "searchable": False,
                "facetable": False,
                "retrievable": True,
                "sortable": False
            },
            {
                "name": "text",
                "type": "Edm.String",
                "searchable": True,
                "filterable": False,
                "facetable": False,
                "retrievable": True,
                "sortable": False,
                "analyzer": "en.microsoft"
            },
            {
                "name": "vector",
                "type": "Collection(Edm.Single)",
                "retrievable": False,
                "filterable": False,
                "facetable": False,
                "sortable": False,
                "dimensions": 3072,
                "vectorSearchProfile": "my-vector-config"
            }
        ],
        
        "vectorSearch": {
            "profiles": [
                {
                    "name": "my-vector-config",
                    "algorithm": "my-algorithms-config"
                }
            ],
            "algorithms": [
                {
                    "name": "my-algorithms-config",
                    "kind": "hnsw",
                    "hnswParameters": {
                        "m": 10,
                        "efConstruction": 1000,
                        "efSearch": 1000,
                        "metric": "cosine"
                    }
                }
            ]
        }
    }
    
    ais_api_key = dbutils.secrets.get(scope=keyvault_scope, key='AZURE-SEARCH-KEY')
    
    service_endpoint = dbutils.secrets.get(scope=keyvault_scope, key='AZURE-SEARCH-ENDPOINT')
    search_service = service_endpoint.replace("https://", "").replace(".search.windows.net", "")
    api_version = "2024-07-01"
    url = f"https://{service_name}.search.windows.net/indexes/{index_name}?api-version={api_version}"
    
    
    headers = {
        "Content-Type": "application/json",
        "api-key": ais_api_key
    }
    
    # Create the index
    response = requests.put(url, headers=headers, data=json.dumps(payload))
    
    
    if response.status_code in [200, 201]:
        logger.info("Index created successfully.")
    else:
        logger.info(f"Error {response.status_code}: {response.text}")
        # Print detailed error info
        try:
            error_details = response.json()
            logger.warning(f"Error details: {json.dumps(error_details, indent=2)}")
        except:
            logger.error("Could not parse error response as JSON")
    
    catalog = config['TARGET_CATALOG']
    schema = config['SILVER_SCHEMA']
    embedding_table = config['TARGET_TABLE_NAME_EMBEDDING_DETAILS']
    logger.info("Updating is_ais_upload to no in embedding table")
    spark.sql(f"UPDATE {catalog}.{schema}.{embedding_table} set is_ais_upload = 'no'")
    logger.info("Completed Updating is_ais_upload to no in embedding table")