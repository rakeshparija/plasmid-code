from pyspark.sql.functions import col, lit, expr, size, split, when
from pyspark.sql.types import (
    ArrayType,
    StructType,
    StructField,
    StringType,
    IntegerType,
    FloatType,
)
from langchain_experimental.text_splitter import SemanticChunker
from langchain_openai.embeddings import AzureOpenAIEmbeddings
from pyspark.dbutils import DBUtils
import datetime
import time
import random
import openai 
import re
import uuid
import traceback

from logs.logger import get_logger
logger = get_logger()

# Retry decorator
def retry_with_exponential_backoff(
    initial_delay=1,
    exponential_base=2,
    jitter=True,
    max_retries=3,
    errors=(openai.RateLimitError,),
):
    def decorator(func):
        def wrapper(*args, **kwargs):
            num_retries = 0
            delay = initial_delay

            while True:
                try:
                    return func(*args, **kwargs)

                except errors as e:
                    num_retries += 1
                    if num_retries > max_retries:
                        raise Exception(
                            f"Maximum number of retries ({max_retries}) exceeded. Last error: {e}"
                        )
                    delay *= exponential_base * (1 + jitter * random.random())
                    logger.info(f"[Retry {num_retries}] Rate limited. Retrying in {delay:.2f}s...")
                    time.sleep(delay)

                except Exception as e:
                    raise e

        return wrapper
    return decorator

# Function to wrap the call to OpenAI API
@retry_with_exponential_backoff()
def create_docs_with_retry(text_splitter, text):
    try:
        return text_splitter.create_documents(text),""
    except Exception as e:
        logger.error(f"Error: {e}")
        return {},str(e)

# Main chunking function with retry applied
def process_chunking(item, api_key_v, api_version_v, azure_endpoint_v, embedding_model_v):
    from src.processing.semantic_modules import CustomSemanticChunker
    from langchain_openai.embeddings import AzureOpenAIEmbeddings
    
    text_splitter = CustomSemanticChunker(
        embeddings=AzureOpenAIEmbeddings(
        api_key = api_key_v,
        api_version=api_version_v,
        azure_endpoint = azure_endpoint_v,
        model=embedding_model_v
            ),
        breakpoint_threshold_type="percentile",
        breakpoint_threshold_amount=95,
        max_tokens=500
        )
    ocr = item['Ocr']
    indices = item['ChunkIndices']
    path = item['BlobPath']
    extracted_dir = item['DirNumber']
    chunk_size = item['ChunkSize']
    doc_name = item['DocName']
    source = item['Source']
    business_unit = item['BusinessUnit']
    # original_doc_name = item['original_doc_name']
    logger.info(item)
    # Apply retry-enabled call for each text chunk
    partition_docs = [
        create_docs_with_retry(text_splitter, ocr[start:end]) for start, end in indices
    ]
    logger.info(partition_docs)
    docs_dict_list = []
    for j, (docs, err) in enumerate(partition_docs):
        error_str = str(err) if err else ""
        docs_dict_list.extend(
            {
                'DocName': doc_name,
                'DirNumber': extracted_dir,
                'TextType': 'chunk',
                'Text': re.sub(r' {2,}|[_]{2,}|[-]{2,}', '', doc.page_content),
                'Granularity': idx + 1 + j * chunk_size,
                'BlobPath': path,
                'Source': source,
                'Error': error_str,
                'BusinessUnit': business_unit
            }
            for idx, doc in enumerate(docs)
        )

        # Handle case where doc creation failed entirely (empty docs but has error)
        if not docs and err:
            docs_dict_list.append({
                'DocName': doc_name,
                'DirNumber': extracted_dir,
                'TextType': 'chunk',
                'Text': '',
                'Granularity': j * chunk_size,
                'BlobPath': path,
                'Source': source,
                'Error': error_str,
                'BusinessUnit': business_unit
            })


    return docs_dict_list if docs_dict_list else []


# Convert spark_df to RDD and map the chunking function
def safe_process_chunking(row_list, api_key_v, api_version_v, azure_endpoint_v, embedding_model_v):
    try:
        response_list = []
        for item in row_list:
            logger.info(item)
            chunked_docs = process_chunking(item, api_key_v, api_version_v, azure_endpoint_v, embedding_model_v)
            if chunked_docs:
                response_list.extend(chunked_docs)
                logger.info(response_list)
        return iter(response_list)
    except Exception as e:
        # Optionally log the error
        logger.error(f"Error processing row: {e}")
        logger.error(traceback.format_exc())
        raise e

def process_chunking_batchwise(spark, api_key_bc, api_version_bc, azure_endpoint_bc, embedding_model_bc):
    i = 0
    # spark.sql(f"DROP TABLE IF EXISTS {catalog}.{schema}.{output_table}")
    while True:
        try:
            logger.info(f"Starting Iteration: {i}")
            spark.sql(f"""
                SELECT *, 
                    SUM(TotalTokenCount) OVER (ORDER BY TotalTokenCount ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_token_count
                FROM {catalog}.{schema}.{input_table}
                WHERE IsChunking = 'no' and Source = 'Everest'
            """).createOrReplaceTempView("filtered_ack_df")
            # Step 2: Select only rows where cumulative word_count ≤ 300000
            ack_spark_df = spark.sql(f"""
                SELECT * 
                FROM filtered_ack_df 
                WHERE running_token_count <= {embedding_token_count}
            """).dropDuplicates()

            # current_token_count = ack_spark_df.agg(sum(col("total_token_count"))).collect()
            
            logger.info(f"Total number of documents processing in this iteration-{i}: {ack_spark_df.count()}")
            # logger.info(f"Total token count of documents processing in this iteration-{iter}: {current_token_count}")

            s=str(datetime.datetime.now())
            logger.info(f"current timestamp: {s}")

            max_retries = 3
            retry_delay = 10
            for attempt in range(max_retries):
                try:
                    ack_spark_df.createOrReplaceTempView("ack_spark_df_view")
                    spark.sql(f"""
                    update {catalog}.{schema}.{input_table} 
                    set IsChunking = '{s}'
                    where DocName in (SELECT distinct DocName FROM ack_spark_df_view) and IsChunking = 'no'
                    """)
                    
                    break
                except Exception as e:
                    logger.error(f"Error in updating: {e}")
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay)
                        logger.info("Retrying Again")


            spark_df = spark.sql(f"""
            SELECT Ocr, ChunkIndices,  ChunkSize, DocName, BlobPath, DirNumber, Source, TotalTokenCount, BusinessUnit FROM {catalog}.{schema}.{input_table}
            WHERE IsChunking = '{s}'""")
            # spark_df.display()

            # current_token_count_iter = spark_df.agg(sum(col("total_token_count"))).collect()
            # logger.info(f"Total token count of documents processing in this iteration-{iter}: {current_token_count_iter}")
            logger.info(f"Total number of documents processing in this iteration-{i}: {spark_df.count()}")

            if spark_df.count() == 0:
                logger.info("No data to process")
                return

            NUM_PARTITIONS = spark.sparkContext.defaultParallelism  # Use more partitions for higher parallelism

            rdd = spark_df.rdd.map(lambda row: row.asDict()).repartition(NUM_PARTITIONS)

            # Apply chunking in parallel
            processed_rdd = rdd.mapPartitions(lambda rows: safe_process_chunking(
                rows,
                api_key_bc,
                api_version_bc,
                azure_endpoint_bc,
                embedding_model_bc
            ))
            # Convert DataFrame rows to list of dictionaries


            # Define schema
            output_schema = StructType([
                StructField("DocName", StringType(), True),
                StructField("DirNumber", StringType(), True),
                StructField("TextType", StringType(), True),
                StructField("Text", StringType(), True),
                StructField("Granularity", StringType(), True),
                StructField("BlobPath", StringType(), True),
                StructField("Source", StringType(), True),
                StructField("Error", StringType(), True),
                StructField("BusinessUnit", StringType(), True)
            ])

            # Convert to final DataFrame
            df_final = spark.createDataFrame(processed_rdd, schema=output_schema)
            df_final = df_final.withColumn("IsEmbed", lit("no"))
            df_final = df_final.withColumn("Id", expr("uuid()"))
            df_final = df_final.withColumn("LastUpdatedAt", expr("current_timestamp()"))
            df_final = df_final.withColumn("WordCount", size(split("Text", r"\s+")))
            # df_final = df_final.withColumn("business_unit", when( col("source") == "Everest",
            #         lit('plastipak')
            #     ).otherwise(lit('mzle')))
            # df_final.display()

            for attempt in range(max_retries):
                try:
                    logger.info("Writing results to table")
                    df_final.write.format("delta").mode("append").saveAsTable(f"{catalog}.{schema}.{output_table}")
                    logger.info(f"Completed storing results to table for iteraion-{i}")
                    break
                except Exception as e:
                    logger.error(f"Error in updating: {e}")
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay)
                        logger.info("Retrying Again to insert data")
            

            for attempt in range(max_retries):
                try:
                    spark.sql(f"""
                    update {catalog}.{schema}.{input_table}
                    set IsChunking = 'yes'
                    where DocName in (select distinct DocName from {catalog}.{schema}.{output_table}  where TextType='chunk' and Error='') and IsChunking='{s}'  """)
                    
                    break
                except Exception as e:
                    logger.error(f"Error in updating: {e}")
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay)
                        logger.info("Retrying Again")

            
            i += 1

        except Exception as e:
            logger.info(f"Error: {e}")
            logger.error(traceback.format_exc())
        
            raise e


def generate_chunking_details(spark, config):

    try:
        global catalog, schema, input_table, output_table, embedding_token_count
        catalog = config['TARGET_CATALOG']
        schema = config['SILVER_SCHEMA']
        input_table =config['TARGET_TABLE_NAME_DATA_TRANSFORMATION']
        output_table = config['TARGET_TABLE_NAME_CHUNKING_SUMMARY_DETAILS']
        keyvault_scope = config['KEYVAULT_SCOPE']
        dbutils = DBUtils(spark)
        api_key = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-API-KEY")
        azure_endpoint = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-ENDPOINT")
        embedding_model = config['EMBEDDING_MODEL']
        api_version = str(config['EMBEDDING_VERSION'])
        embedding_token_count = int(config['EMBEDDING_TOKEN_COUNT'])
        process_chunking_batchwise(
            spark,
            api_key,
            api_version,
            azure_endpoint,
            embedding_model
        )

        # process_chunking_batchwise(spark, api_key, api_version, azure_endpoint, embedding_model)
    except Exception as e:
        logger.error(f"Error in generating chunking details: {e}")
        raise e
    