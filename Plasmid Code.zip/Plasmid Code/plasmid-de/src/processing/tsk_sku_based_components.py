from logs.logger import get_logger
from pyspark.sql.functions import lit

# Configure logger
logger = get_logger()

def read_sku_list(file_path):
    """ Read SKU list from a text file. """
    try:
        with open(file_path, "r") as file:
            sku_list = [line.strip() for line in file.readlines()]
            logger.info(f"Successfully read {len(sku_list)} SKUs from {file_path}.")
            return sku_list
    except Exception as e:
        logger.error(f"Error reading SKU list from {file_path}: {e}")
        raise(f"Exception: {e}")

def process_materials_skus_tahiti(spark, config):
    """ Function to process mzle and Plastipack materials. """
    try:
        logger.info("Initializing processing of mzle materials.")

        mzle_sku_list = read_sku_list("data/mzle_sku_list.txt")
        if not mzle_sku_list:
            logger.warning("No mzle SKUs found in the file. Exiting process.")
            return None

        logger.info(f"The number of mzle SKUs from file: {len(mzle_sku_list)}")

        # Extract relevant values from config
        target_catalog = config["TARGET_CATALOG"]
        silver_schema = config["SILVER_SCHEMA"]
        bronze_schema = config["BRONZE_SCHEMA"]
        flatten_table_name_tahiti = config["MATERIAL_FLATTENED_TAHITI"]
        material_table_name_mzle = config["MATERIAL_TABLE_NAME_MZLE"]

        # Create SQL query for mzle materials
        multiple_like_statement = " OR ".join([f"ParentMaterialNumber LIKE '%{sku}%'" for sku in mzle_sku_list])

        sub_query_1 = f"""SELECT DISTINCT ParentMaterialNumber AS Material, 'mzle' AS BusinessUnit, 'Tahiti' AS Source
                          FROM {target_catalog}.{bronze_schema}.{flatten_table_name_tahiti}
                          WHERE {multiple_like_statement}"""

        sub_query_2 = f"""SELECT DISTINCT ChildMaterialNumber AS Material,'mzle' AS BusinessUnit, 'Tahiti' AS Source
                          FROM {target_catalog}.{bronze_schema}.{flatten_table_name_tahiti}
                          WHERE {multiple_like_statement}"""

        query = sub_query_1 + " UNION " + sub_query_2

        logger.info("Executing SQL query to fetch mzle materials.")

        tahiti_materials_new = spark.sql(query).select("Material","BusinessUnit","Source").distinct()

        material_count = tahiti_materials_new.count()
        logger.info(f"The total number of mzle materials: {material_count}")

        if material_count == 0:
            logger.warning("No matching materials found. Exiting process.")
            return None

        # Save mzle materials
        logger.info(f"Saving mzle materials to {target_catalog}.{silver_schema}.{material_table_name_mzle}.")
        tahiti_materials_new.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{target_catalog}.{silver_schema}.{material_table_name_mzle}")
        logger.info(f"mzle materials saved successfully in {target_catalog}.{silver_schema}.{material_table_name_mzle}.")

    except Exception as e:
        logger.error(f"An error occurred while processing mzle materials: {e}")
        raise(f"Exception: {e}")

def process_materials_skus_everest(spark, config):
    """ Function to process Plastipack materials. """
    try:
        logger.info("Initializing processing of Plastipack materials.")

        plastickap_sku_list = read_sku_list("data/plastipak_sku_list.txt")
        if not plastickap_sku_list:
            logger.warning("No Plastickap SKUs found in the file. Exiting process.")
            return None

        logger.info(f"The number of Plastickap SKUs from file: {len(plastickap_sku_list)}")

        # Extract relevant values from config
        target_catalog = config["TARGET_CATALOG"]
        silver_schema = config["SILVER_SCHEMA"]
        bronze_schema = config["BRONZE_SCHEMA"]
        flatten_table_name_everest = config["MATERIAL_FLATTENED_EVEREST"]
        material_table_name_plastipak = config["MATERIAL_TABLE_NAME_PLASTIPAK"]

        logger.info("Processing Plastipack materials.")

        multiple_like_statement = " OR ".join([f"ParentMaterialNumber LIKE '%{sku}%'" for sku in plastickap_sku_list])

        query = f"""
            SELECT DISTINCT ParentMaterialNumber AS Material, 'plastipak' AS BusinessUnit, 'Everest' AS Source
            FROM {target_catalog}.{bronze_schema}.{flatten_table_name_everest}
            WHERE {multiple_like_statement}
            UNION
            SELECT DISTINCT ChildMaterialNumber AS Material, 'plastipak' AS BusinessUnit, 'Everest' AS Source
            FROM {target_catalog}.{bronze_schema}.{flatten_table_name_everest}
            WHERE {multiple_like_statement}
        """

logger.info("Executing SQL query to fetch Plasticpak materials.")
plasticpak_material_new = spark.sql(query).select("Material", "BusinessUnit", "Source").distinct()

material_count = plasticpak_material_new.count()
logger.info(f"The total number of Plasticpak Materials: {material_count}")

if material_count == 0:
    logger.warning("No matching materials found. Exiting process.")
    return

# Save Plasticpak materials
logger.info(f"Saving Plasticpak materials to {target_catalog}.{silver_schema}.{material_table_name_plastipak}.")
plasticpak_material_new.write.format("delta").mode("overwrite").option("overwriteSchema", "true") \
    .saveAsTable(f"{target_catalog}.{silver_schema}.{material_table_name_plastipak}")
logger.info(f"Plasticpak materials saved successfully in {target_catalog}.{silver_schema}.{material_table_name_plastipak}.")

except Exception as e:
    logger.error(f"An error occurred while processing Plasticpak materials: {e}")
    raise(f"Exception: {e}")
