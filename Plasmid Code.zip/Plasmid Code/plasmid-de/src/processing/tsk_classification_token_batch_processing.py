
# DBTITLE 1,libraries
import pandas as pd
from PIL import Image
import json
from pathlib import Path
from azure.storage.blob import BlobServiceClient
import pdfplumber
import io
from datetime import datetime
import torch
from pdf2image import convert_from_path
from torchvision import transforms
import timm
import torch.nn.functional as Fun
import random
import fitz
import pytesseract
from pytesseract import Output
from pyspark.sql import Row
import pdfplumber, fitz
from pdf2image import convert_from_path
import pandas as pd
from azure.storage.blob import BlobServiceClient
import tempfile, json
from pyspark.sql.functions import lit, row_number, col, size, collect_list, expr,current_timestamp
from pyspark.sql.functions import col, lit, collect_list, array, expr, size,when, array_distinct, array_join, count,countDistinct,regexp_replace
import pyspark.sql.functions as F
from pyspark.sql.types import StructType, StringType, ArrayType, StructField, IntegerType
from pyspark.sql.window import Window
from pyspark.sql import Window
from pyspark.sql.functions import *
from datetime import datetime
import mlflow
from pyspark.dbutils import DBUtils
from logs.logger import get_logger
logger = get_logger()

def token_count_gen(pdf_plumber):
    results=[]
    for i, page in enumerate(pdf_plumber.pages, start=1):
        text = page.extract_text() or ""
        tokens = text.split()  # Simple word-based token count
        token_count = len(tokens)
        results.append({
            "PageNum": i,
            "TokenCount": token_count
        })
    return results

def angles(fitz_doc):
    results=[]
    for i in range(len(fitz_doc)):
        page_fitz = fitz_doc[i]
        rotation_fitz = page_fitz.rotation
        pix = page_fitz.get_pixmap(dpi=200)  # increase DPI for better OCR
        image_tess = Image.open(io.BytesIO(pix.tobytes("png")))  # convert to PIL Image
        try:
            osd = pytesseract.image_to_osd(image_tess, output_type=Output.DICT)
            rotation_tess = osd.get('orientation', 0)
        except Exception:
            rotation_tess = 0
        results.append({            
            "PageNum": i+1,
            "RotationTess": rotation_tess,
            "RotationFitz": rotation_fitz
        })
    return results

#function to perform prediction
def get_scanned_vs_non_scanned(pages, model, preprocess, device, LABEL_MAPPING):
    scanned_non_scanned=[]
    with torch.no_grad():
        for page_num, page in enumerate(pages, start=1):
                # Prepare the image
                img = page.convert('RGB')
                img_t = preprocess(img).unsqueeze(0).to(device)
                
                # Predict
                outputs = model(img_t)
                probs = Fun.softmax(outputs, dim=1).cpu().numpy()[0]
                pred_idx = outputs.argmax(dim=1).item()
                pred_label = LABEL_MAPPING[pred_idx]
                one_result = {
                    'PageNum': page_num,
                    'PredLabel': pred_label,
                    'TimeStamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    'ScanProb': float(probs[0]),
                    'DigitalProb': float(probs[1])
                    }
                # Append to results
                scanned_non_scanned.append(one_result)
                scanned_non_scanned_df=pd.DataFrame(scanned_non_scanned)

    return scanned_non_scanned_df



# Broadcast configuration

def process_pdf_file_distributed(pdf_file, model, preprocess, device, LABEL_MAPPING, pdf_container, env, source):
    try:
        import os

        if env == 'sbx':
            blob_path = f"{source}/pdf_files/raw/{pdf_file}"
            blob_client = pdf_container.get_blob_client(blob_path)
            file_bytes = blob_client.download_blob().readall()

            # Save PDF temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
                tmp_file.write(file_bytes)
                tmp_path = tmp_file.name

            # Process the PDF
            pdf_plumber = pdfplumber.open(tmp_path)
            fitz_doc = fitz.open(tmp_path)
        else:
            file_path = f"{pdf_container}/raw/{pdf_file}"
            # Process the PDF
            pdf_plumber = pdfplumber.open(file_path)
            fitz_doc = fitz.open(file_path)
            

        # pages_pdf2image = convert_from_path(tmp_path, dpi=150)
        pil_images = [Image.open(io.BytesIO(page.get_pixmap(dpi=200).tobytes("png"))) for page in fitz_doc]

        token_count_df = pd.DataFrame(token_count_gen(pdf_plumber))
        angles_df = pd.DataFrame(angles(fitz_doc))
        scanned_non_scanned_df = get_scanned_vs_non_scanned(pil_images, model, preprocess,  device, LABEL_MAPPING)

        classified_df = scanned_non_scanned_df.merge(token_count_df, on='PageNum', how='left')
        classified_df = classified_df.merge(angles_df, on='PageNum', how='left')
        classified_df['PdfFile'] = pdf_file
        classified_df['Error'] = ''

        # Convert to JSON string
        return classified_df.to_json(orient='records')
    
    except Exception as e:
        
        if env == 'sbx':
            blob_name = f"{source}/pdf_files/failed/classification/{pdf_file}"
            pdf_container.upload_blob(name=blob_name, data=file_bytes, overwrite=True)
            blob_client.delete_blob()
        else:
            with open(file_path, "rb") as f:
                file_bytes = f.read()
            destination_path = f"{pdf_container}/failed/classification/{pdf_file}"
            os.makedirs(
                os.path.dirname(destination_path),
                exist_ok=True
            )
            with open(destination_path, 'wb') as fw:
                fw.write(bytes)
        
            os.remove(file_path)


        logger.error(f"Moved failed blob due to failure in classification run: ")

def process_classification_tokens(spark, config):

    catalog = config['TARGET_CATALOG']
    schema = config['SILVER_SCHEMA']
    unstructured_schema = config['UNSTRUCTURED_SCHEMA_EVEREST']
    output_table = config['TARGET_TABLE_CLASSIFICATION']
    input_table = config['TARGET_TABLE_NAME_PAGE_COUNT_DETAILS']
    source = "everest"
    env = config['ENV']
    sc= spark.sparkContext
    dbutils = DBUtils(spark)
    global preprocess, model, LABEL_MAPPING, device
    page_count_table = f"{catalog}.{schema}.{input_table}"
    classification_table = f"{catalog}.{schema}.{output_table}"
    if env == 'sbx':
        keyvault_scope  = config['KEYVAULT_SCOPE']
        storage_name = dbutils.secrets.get(scope=keyvault_scope, key ='BLOB-STORAGE-ACCOUNT-NAME')
        account_key = dbutils.secrets.get(scope=keyvault_scope, key='BLOB-STORAGE-ACCESS-KEY')
        BLOB_CONNECTION_STRING = f"DefaultEndpointsProtocol=https;AccountName={storage_name};AccountKey={account_key};EndpointSuffix=core.windows.net"
        blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
        pdf_container = blob_service_client.get_container_client(config['UNSTRUCTURED_CONTAINER'])
    else:
        pdf_container = f"/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files"

    while True:
        final_list_df = spark.sql(f"""
            select PdfFile,PageCount
            from {page_count_table}
            where IsClassification = 'no' and Source = 'Everest' order by PageCount asc
        """)

        # final_list_df.select(_sum("page_count").alias("total_page_count")).display()
        final_list_df = final_list_df.select("PdfFile", "PageCount")

        final_list = [row.PdfFile for row in final_list_df.collect()]

        if len(final_list) ==0:
                break


        final_list_df_new = spark.createDataFrame([Row(PdfFile=pdf) for pdf in final_list])

        final_list_df_new.createOrReplaceTempView("final_list_df_temp")

        # Merge statement to update specific rows
        spark.sql(f"""
        MERGE INTO {page_count_table} AS target
        USING final_list_df_temp AS source
        ON target.PdfFile = source.PdfFile
        WHEN MATCHED THEN
        UPDATE SET target.IsClassification = "in progress"
        """)
        # Set random seed for reproducibility
        torch.manual_seed(42)
        random.seed(42)

        # Device configuration (GPU if available)
        device = torch.device('cpu')#torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        logger.info(f"Using device: {device}")

        # MODEL_PATH = 'best_model.pth'            # Path to your saved model weights
        LABEL_MAPPING = {0: 'scan', 1: 'digital'}
        IMAGE_SIZE = 224

        # device =torch.device('cpu') #torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # 2. Define transforms (must match training 'val' transforms)
        preprocess = transforms.Compose([
            transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                std=[0.229, 0.224, 0.225])
        ])
        mlflow.set_registry_uri("databricks")  
        model_name = "vit-classifier"  
        model_stage = "Production"
        model_uri = f"models:/{model_name}/{model_stage}"
        model = mlflow.pytorch.load_model(model_uri= model_uri, map_location=torch.device('cpu'))
        model.to(device)
        model.eval() 

        try:
            files = 160
            pdf_rdd = sc.parallelize(final_list, files)
            results = pdf_rdd.map(lambda row: process_pdf_file_distributed(row, model, preprocess, device, LABEL_MAPPING, pdf_container, env, source)).collect()
        except Exception as e:
            logger.error(f"Error: {e}")
            raise

        #Convert back to DataFrame
        all_pages = []
        for result_json in results:
            try:
                all_pages.extend(json.loads(result_json))
            except:
                pass
        classified_df = pd.DataFrame(all_pages)
        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Convert Pandas DataFrame to Spark DataFrame
        classified_df_spark = spark.createDataFrame(classified_df)
        classified_df_spark = classified_df_spark.withColumn("Source", lit('Everest')).withColumn("IsBatch", lit("no")).withColumn("LastUpdatedAt", lit(current_timestamp))
        classified_df_spark = classified_df_spark.withColumn("BusinessUnit", when( col("Source") == "Everest",
                    lit('plastipak')
                ).otherwise(lit('mzle')))

        classified_df_spark = classified_df_spark.filter(col("Error")=='')
        # Write the DataFrame to a Delta table
        classified_df_spark.write.format("delta") \
            .mode("append") \
            .option("mergeSchema", "true") \
            .saveAsTable(f"{classification_table}")
        spark.sql(f"""
                update {page_count_table} set IsClassification = "yes" where PdfFile in (select distinct PdfFile from {classification_table})
                """)
        # print(f"Table {database_name}.{table_name} created and data uploaded successfully.")
    # create_batching(spark, config)

def create_batching(spark, config):
    catalog = config['TARGET_CATALOG']
    schema = config['SILVER_SCHEMA']
    output_table = config['TARGET_TABLE_BATCHING_DETAILS']
    ocr_table = config['TARGET_TABLE_NAME_OCR_RESULTS']
    page_table = config['TARGET_TABLE_NAME_PAGE_COUNT_DETAILS']
    ocr_details_table = f"{catalog}.{schema}.{ocr_table}"
    page_count_details_table = f"{catalog}.{schema}.{page_table}"
    batch_table = f"{catalog}.{schema}.{output_table}"
    source = 'Everest'
    dbutils = DBUtils(spark)
    keyvault_scope = config['KEYVAULT_SCOPE']
    # storage_name = dbutils.secrets.get(scope=keyvault_scope, key='ADLS-ACCOUNT-NAME')
    # account_key = dbutils.secrets.get(scope=keyvault_scope, key='ADLS-CONNECTION-STRING')
    # spark.conf.set(
    # f"fs.azure.account.key.{storage_name}.blob.core.windows.net",
    # account_key
    # )

    

    # # same file in pdf and excel check
    # same_file_check = f"""
    # with filtered_pdf as (
    # select distinct regexp_replace(pdf_file, '\\.[^.]+$', '') as doc_name_no_ext
    # from {page_count_details_table} 
    # where pdf_file not in (
    #     select distinct doc_name 
    #     from {ocr_details_table}
    #     where source = "{source}"
    #     and status = "OK"
    # )
    # and is_classification = 'yes'
    # and source = "{source}"
    # )
    # select distinct doc_name
    # from {ocr_details_table}
    # where regexp_replace(doc_name, '\\.[^.]+$', '') in (select doc_name_no_ext from filtered_pdf)"""

    # same_file_check_df = spark.sql(same_file_check)

    # same_file_check_df = same_file_check_df.withColumn(
    #     "doc_name_pdf",
    #     when(
    #         regexp_replace("doc_name", r"(?i)\.(xlx|xlsm|xlsx)$", ".pdf") != same_file_check_df["doc_name"],
    #         regexp_replace("doc_name", r"(?i)\.(xlx|xlsm|xlsx)$", ".pdf")
    #     ).otherwise(same_file_check_df["doc_name"])
    # )



    # base batching code from page_count_Details and plasmid_ocr_details
    try:
        batch_df_query = f"""
        select distinct PdfFile, PageCount 
        from {page_count_details_table}
        where PdfFile not in (
            select distinct regexp_replace(DocName, '_plasmid_subpart_[0-9]+\\.pdf', '.pdf') AS DocName
            from {ocr_details_table}
            where Source="{source}"
        ) 
        and IsClassification = 'yes' 
        and Source = "{source}"
        """
        all_df = spark.sql(batch_df_query)
        logger.info("Using Incremental query for batching")
    except Exception as e:
        batch_df_query = f"""
        select distinct PdfFile, PageCount 
        from {page_count_details_table}
        where IsClassification = 'yes' 
        and Source = "{source}"
        """
        all_df = spark.sql(batch_df_query)
        logger.info(f"not Using Incremental query for batching: {e}")



    # Remove rows from all_df where pdf_file is in same_file_check_df.doc_name
    final_df = all_df
    # .join(
    #     same_file_check_df.withColumnRenamed("doc_name_pdf", "pdf_file"),
    #     on="pdf_file",
    #     how="left_anti"
    # )


    # =====================================================================
    # === Step 2: Process PDFs with page_count > 50 using Sequential Batching
    # =====================================================================

    # 1. Extract big PDFs to Pandas for sequential batching
    big_pdfs_pd = final_df.filter(col("PageCount") > 50) \
        .withColumn("SplitCount", F.ceil(col("PageCount") / 10)) \
        .orderBy(F.desc("SplitCount")) \
        .toPandas()

    # 2. Sequential batching logic to cap ~160 splits per batch
    batch_id = 0
    current_total = 0
    batch_groups = []

    for _, row in big_pdfs_pd.iterrows():
        if current_total + row["SplitCount"] > 160:  # start a new batch
            batch_id += 1
            current_total = 0
        batch_groups.append(batch_id)
        current_total += row["SplitCount"]

    big_pdfs_pd["BatchGroup"] = batch_groups

    big_pdf_schema = StructType([StructField("PdfFile", StringType(), True),
                                 StructField("PageCount", IntegerType(), True),
                                 StructField("SplitCount", IntegerType(), True),
                                 StructField("BatchGroup", IntegerType(), True)])

    # 3. Convert back to Spark
    if not big_pdfs_pd.empty:
        big_pdfs_spark = spark.createDataFrame(big_pdfs_pd, schema=big_pdf_schema)
    else:
        big_pdfs_spark = spark.createDataFrame([], schema=big_pdf_schema)
    # logger.info(f"{big_pdfs_spark.columns}")

    # 4. Prepare page_count as [{pages, count}]
    page_count_summary = big_pdfs_spark.groupBy("BatchGroup", "PageCount") \
        .agg(F.count("*").alias("Count")) \
        .withColumn("PageInfo", F.struct(F.col("PageCount").alias("Pages"), F.col("Count")))

    page_count_summary = page_count_summary.groupBy("BatchGroup") \
        .agg(F.collect_list("PageInfo").alias("PageCount"))

    # 5. Collect batch_list per batch_group
    batch_list_df = big_pdfs_spark.groupBy("BatchGroup") \
        .agg(F.collect_list("PdfFile").alias("BatchList"))

    # 6. Merge summaries into df_ge_50
    df_ge_50 = batch_list_df.join(page_count_summary, "BatchGroup") \
        .select("BatchList", "PageCount") \
        .withColumn("UseSplit", lit("yes"))

    # =====================================================================
    # === Step 3: Process PDFs with page_count < 50 (Small PDFs) ==========
    # =====================================================================

    df_lt_50 = final_df.filter(col("PageCount") < 50) \
        .groupBy("PageCount") \
        .agg(F.collect_list("PdfFile").alias("BatchList"),
            F.count("*").alias("PdfCount")) \
        .withColumn("PageInfo", F.array(F.struct(F.col("PageCount").alias("Pages"),
                                                F.col("PdfCount").alias("Count")))) \
        .select("BatchList", F.col("PageInfo").alias("PageCount")) \
        .withColumn("UseSplit", lit("no"))

    # =====================================================================
    # === Step 4: Union Both DataFrames ===================================
    # =====================================================================

    final_df = df_ge_50.unionByName(df_lt_50) \
        .withColumn("BatchSize", size(col("BatchList"))) \
        .withColumn("Id", expr("uuid()")) \
        .withColumn("IsOcr", lit("no")) \
        .withColumn("IsError", lit("no")) \
        .withColumn("Source", lit(source)) \
        .withColumn("TimeLog", lit("")) \
        .withColumn("BusinessUnit", lit("plastipak"))

    # =====================================================================
    # === Step 5: Add Ordered Unique Timestamp ============================
    # =====================================================================

    w = Window.orderBy("BatchSize")
    final_df = final_df.withColumn("RowNum", F.row_number().over(w))

    batch_df = final_df.withColumn(
        "LastUpdatedAt",
        F.expr("current_timestamp() + make_interval(0,0,0,0,0,0,RowNum)")
    ).drop("RowNum")

    # =====================================================================
    # === Step 6: Display Final Result ====================================
    # =====================================================================

    # batch_df.display()
    batch_df.write.format("delta").mode("append").saveAsTable(batch_table)