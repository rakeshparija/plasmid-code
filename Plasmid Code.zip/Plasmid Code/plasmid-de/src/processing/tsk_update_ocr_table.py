from pyspark.dbutils import DBUtils
from delta.tables import DeltaTable
from logs.logger import get_logger
logger = get_logger()


def update_ocr_table(spark, config):
    catalog = config['TARGET_CATALOG']
    schema = config['SILVER_SCHEMA']
    env = config['ENV']
    ocr_table = config['TARGET_TABLE_NAME_OCR_RESULTS']
    keyvault_scope = config['KEYVAULT_SCOPE']
    dbutils = DBUtils(spark)
    source = "everest"

    if env == 'sbx':
        unstructured_container = config['UNSTRUCTURED_CONTAINER']
        storage_name = dbutils.secrets.get(scope=keyvault_scope, key='BLOB-STORAGE-ACCOUNT-NAME')
        account_key = dbutils.secrets.get(scope=keyvault_scope, key='BLOB-STORAGE-ACCESS-KEY')
        spark.conf.set(
            f"fs.azure.account.key.{storage_name}.blob.core.windows.net",
            account_key
        )
        ocr_delta_source_path = f"abfss://{unstructured_container}@{storage_name}.dfs.core.windows.net/{source}/ocr_files/plasmid_ocr_details_etl_delta/"
    else:
        unstructured_schema = config['UNSTRUCTURED_SCHEMA_EVERST']
        ocr_delta_source_path = f"/Volumes/{catalog}/{unstructured_schema}/{source}/ocr_files/plasmid_ocr_details_etl_delta/"

    new_ocr_df = spark.read.format("delta").load(ocr_delta_source_path)
    from delta.tables import DeltaTable

    # Example: Composite key on id and date
    merge_condition = """
    target.DocName = source.DocName
    """

    try:
        # Load Delta table
        delta_table = DeltaTable.forName(spark, f"{catalog}.{schema}.{ocr_table}")
        logger.info("Delta Table found, Starting Refreshing OCR table")

        # Perform merge with multiple match conditions
        delta_table.alias("target") \
            .merge(
                source=new_ocr_df.alias("source"),
                condition=merge_condition
            ) \
            .whenMatchedUpdate(
                condition="target.Status != 'OK'",
                set={col: f"source.{col}" for col in new_ocr_df.columns}
            ) \
            .whenNotMatchedInsertAll() \
            .execute()

        logger.info("Completed refreshing OCR table")

    except Exception as e:
        logger.error(f"Exception: {e}")
