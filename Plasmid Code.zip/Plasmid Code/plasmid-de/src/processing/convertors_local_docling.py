from functools import lru_cache
import os
import time
import time

@lru_cache(maxsize=1)
def get_converters(catalog, env):
    """Initialize converters once per worker process - eliminates 12x model loading overhead"""
    from docling.datamodel.pipeline_options import (
        PdfPipelineOptions,
        TesseractCliOcrOptions,
        EasyOcrOptions,
        TableStructureOptions,
        RapidOcrOptions,
        TableFormerMode
    )
    from docling.datamodel.base_models import InputFormat
    from docling.document_converter import DocumentConverter, PdfFormatOption
    from docling.backend.docling_parse_v2_backend import DoclingParseV2DocumentBackend

    os.environ["DOCLING_ARTIFACTS_PATH"] = "/tmp/docling_models"
    worker_id = f"worker_{os.getpid()}"

    converter_start = time.time()

    def _build(ocr_opts):
        opts = PdfPipelineOptions(do_ocr=True, do_table_structure=True)
        opts.table_structure_options.do_cell_matching = True
        opts.ocr_options = ocr_opts

        return DocumentConverter(
            format_options={
                InputFormat.PDF: PdfFormatOption(
                    pipeline_options=opts,
                    backend=DoclingParseV2DocumentBackend,
                    from_pretrained_kwargs={"device_map": "cpu"}
                )
            }
        )

    # Determine artifacts path
    # print(f"[{worker_id}] Building digital converter...")
    if env == "sbx":
        artifacts_path = "/dbfs/FileStore/docling_models"
        model_storage_path = "/dbfs/FileStore/easyocr_models"
    else:
        artifacts_path = f"/Volumes/{catalog}/b_plasmid/b_plasmid_volume/model_files/docling_models"
        model_storage_path = f"/Volumes/{catalog}/b_plasmid/b_plasmid_volume/model_files/easyocr_models"

    pipeline_options = PdfPipelineOptions(artifacts_path=artifacts_path)
    pipeline_options.do_ocr = True
    pipeline_options.do_table_structure = True
    pipeline_options.table_structure_options.do_cell_matching = True

    ocr_options = TesseractCliOcrOptions(force_full_page_ocr=True)
    pipeline_options.ocr_options = ocr_options

    digital_converter = DocumentConverter(
        format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
        }
    )

    # print(f"[{worker_id}] Building scan converter...")
    scan_converter = _build(
        EasyOcrOptions(
            force_full_page_ocr=True,
            model_storage_directory=model_storage_path,
            download_enabled=False
        )
    )

    converter_time = time.time() - converter_start
    # print(f"[{worker_id}] OPTIMIZATION: Converters loaded and cached in {converter_time:.2f}s")
    # print(f"[{worker_id}] Subsequent calls will be instant (0.001s)")

    return digital_converter, scan_converter


@lru_cache(maxsize=1)
def get_clients(CONNECTION_STRING, CONTAINER_NAME):
    """Initialize Azure clients once per worker process"""
    from azure.storage.blob import BlobServiceClient
    # from openai import AzureOpenAI

    worker_id = f"worker_{os.getpid()}"
    # print(f"[{worker_id}] OPTIMIZATION: Loading Azure clients (will be cached)...")

    client_start = time.time()

    blob_container = BlobServiceClient.from_connection_string(CONNECTION_STRING).get_container_client(CONTAINER_NAME)

    # Example placeholder for LLM client (disabled in your screenshot)
    # llm_client = AzureOpenAI(
    #     api_key=api_key,
    #     api_version=api_version,
    #     azure_endpoint=azure_endpoint
    # )

    client_time = time.time() - client_start
    # print(f"[{worker_id}] OPTIMIZATION: Azure clients loaded in {client_time:.2f}s")

    return blob_container
