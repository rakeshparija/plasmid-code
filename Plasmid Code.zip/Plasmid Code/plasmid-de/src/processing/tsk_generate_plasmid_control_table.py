from logs.logger import get_logger
logger = get_logger()

def generate_control_table(spark, config):
    try:
        target_catalog = config['TARGET_CATALOG']
        target_schema = config['GOLD_SCHEMA']
        target_table = config['CONTROL_TABLE']
        
        control_table = f"{target_catalog}.{target_schema}.{target_table}"
        
        
        csv_path = f"/Volumes/{target_catalog}/b_plasmid/b_plasmid_volume/control_table/control_table.csv"
        
        
        # Read CSV into DataFrame
        df = spark.read.csv(csv_path, header=True, inferSchema=True, sep=",", multiLine=True)
        # Cast all columns to String Type
        for col_name in df.columns:
            df = df.withColumn(col_name, df[col_name].cast("string"))
        
        df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(control_table)
        
        
        logger.info("Values got inserted into Control table successfully")
        
        
    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        raise(f"File not found: {e}")
    except KeyError as e:
        logger.error(f"Missing configuration key: {e}")
        raise(f"Missing configuration key: {e}")
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise(f"An error occurred: {e}")