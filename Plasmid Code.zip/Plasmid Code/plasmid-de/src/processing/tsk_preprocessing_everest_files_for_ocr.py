import os
import zipfile
import time
import subprocess
import shutil
import uuid
from pyspark.dbutils import DBUtils
from azure.storage.blob import BlobServiceClient
from logs.logger import get_logger
logger = get_logger()

# ==== Spark cache flush ====
def force_blob_refresh(spark):
    try:
        sc = spark.SparkContext.getOrCreate()
        hadoop_conf = sc._jsc.hadoopConfiguration()
        for entry in list(hadoop_conf.iterator()):
            hadoop_conf.unset(entry.getKey())
        logger.info("Successfully cleared Spark Hadoop cache.")
    except Exception as e:
        logger.error(f"Error while clearing Spark Hadoop cache: {e}")
        raise(f"Exception: {e}")

# ==== List eligible blobs ====
def get_blob_list():
    try: 
        blob_tuples = []

        if env == 'sbx':
            prefix_path = f"{source}/sap_files/raw/"
            blobs = container_client.list_blobs(name_starts_with=prefix_path)
            files = [blob.name for blob in blobs]
        else:
            files_path = f'/Volumes/{catalog}/{unstructured_schema}/{source}/sap_files'
            list_of_files = dbutils.fs.ls(f"{files_path}/raw/")
            files = [f.path.replace("dbfs:","") for f in list_of_files]

        for file in files:
            if not file.endswith("/"):
                ext = os.path.splitext(file)[1].lower().strip()
                blob_tuples.append((file, ext))

        logger.info(f"Total blobs found: {len(blob_tuples)}")
        return blob_tuples
    except Exception as e:
        logger.error(f"Error while listing blobs: {e}")
        raise(f"Exception: {e}")

# ==== Upload to blob ====
def upload_to_blob(file_path, dest_file_path):
    try:
        if env == 'sbx':
            with open(file_path, "rb") as data:
                container_client.get_blob_client(dest_file_path).upload_blob(data, overwrite=True)
        else:
            dbutils.fs.cp(file_path, dest_file_path)
        logger.info(f"Successfully uploaded {file_path} to {dest_file_path}.")
    except Exception as e:
        logger.error(f"Error while uploading blob {dest_file_path}: {e}")
        raise(f"Exception: {e}")

# ==== Archive original ====
def archive_blob(file_name):
    try:
        if env == 'sbx':
            file_path = f'{source}/sap_files/raw/{file_name}'
            archive_path = f'{source}/sap_files/processed/{file_name}'
            src_blob_client = container_client.get_blob_client(file_path)
            archive_blob_client = container_client.get_blob_client(archive_path)
            archive_blob_client.start_copy_from_url(src_blob_client.url)
            src_blob_client.delete_blob()
        else:
            file_path  = f'/Volumes/{catalog}/{unstructured_schema}/{source}/sap_files/raw/{file_name}'
            archive_path = f'/Volumes/{catalog}/{unstructured_schema}/{source}/sap_files/processed/{file_name}'
            dbutils.fs.mv(file_path, archive_path)
        logger.info(f"Successfully archived blob to {archive_path}.")
    except Exception as e:
        logger.error(f"Error while archiving blob {file_path}: {e}")
        raise(f"Exception: {e}")


# ==== Convert using LibreOffice ====
def convert_to_pdf_file(input_path, ext):
    ext = ext.lower()
    
    try:
        if env == 'sbx':
            TEMP_DIR = '/tmp/blob_processing'
            temp_name = str(uuid.uuid4()) + ext
            temp_path = os.path.join(TEMP_DIR, temp_name)
            shutil.copy(input_path, temp_path)
        else:
            TEMP_DIR = f'/Volumes/{catalog}/{unstructured_schema}/{source}/sap_files/processing'
            temp_name = str(uuid.uuid4()) + ext
            temp_path = os.path.join(TEMP_DIR, temp_name)
            dbutils.fs.cp(input_path, temp_path)

        logger.info(f"Copied file to temp path: {temp_path}")
        
        pdf_path = os.path.join(TEMP_DIR, os.path.splitext(temp_name)[0] + ".pdf")
        timeout_sec = 300 if os.path.getsize(temp_path) > 3 * 1024 * 1024 else 180

        for attempt in range(2):
            try:
                subprocess.run([
                    "libreoffice", "--headless", "--convert-to", "pdf",
                    "--outdir", TEMP_DIR, temp_path
                ], check=True, timeout=timeout_sec, capture_output=True)
                logger.info(f"Conversion attempt {attempt + 1} successful.")
                break
            except subprocess.CalledProcessError as e:
                logger.warning(f"Conversion attempt {attempt + 1} failed: {e}")
                time.sleep(2)

        if not os.path.exists(pdf_path) and ext in [".ppt", ".pptx"]:
            alt_path = os.path.join(TEMP_DIR, f"copy_{temp_name}")
            shutil.copy(temp_path, alt_path)
            logger.info(f"Trying alternate conversion method for {ext}")

            try:
                subprocess.run([
                    "libreoffice", "--headless", "--convert-to", "pdf",
                    "--outdir", TEMP_DIR, alt_path
                ], check=True, timeout=timeout_sec, capture_output=True)
                logger.info("Alternative conversion successful.")
            except subprocess.CalledProcessError as e:
                logger.error(f"Alternative conversion failed: {e}")

            if os.path.exists(alt_path):
                os.remove(alt_path)
                logger.info(f"Cleaned up alt file: {alt_path}")

        return pdf_path if os.path.exists(pdf_path) else None
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)
            logger.info(f"Cleaned up temp file: {temp_path}")

# for handling nested zips
def _handle_local_file(local_path: str,
                    #    blob_stem: str,
                       converted_counter: list,          # list for mutability
                       nested_key: str = ""):            
    """
    Recursively processes a local file. Converts supported types to PDF,
    drills into nested ZIPs, uploads everything *except* inner ZIP files.


    Args:
        local_path (str): path of the file already on disk
        blob_stem  (str): original blob name *without* RAW/PROC prefix
        nested_key (str): breadcrumb to keep names unique per nesting depth
    """
    _, ext = os.path.splitext(local_path)
    ext = ext.lower()
    nested_key = nested_key.replace(".zip", "")


    if ext in SUPPORTED_FILE_TYPES:
        pdf_path = convert_to_pdf_file(local_path, ext)
        if pdf_path:
            pdf_blob = (f"{nested_key}".replace(ext,
                        f"-{ext[1:]}.pdf"))
            if env == 'sbx':
                upload_to_blob(pdf_path, f'{source}/pdf_files/raw/{pdf_blob}')
            else:
                upload_to_blob(pdf_path, f'/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files/raw/{pdf_blob}')                       
            converted_counter[0] += 1
            os.remove(pdf_path)
    elif ext == ".zip":
        # -------- recurse ----------
        if env == 'sbx':
            TEMP_DIR = '/tmp/blob_processing'
            unzip_dir = os.path.join(TEMP_DIR, f"unzipped_{uuid.uuid4().hex}")  # ← NEW
            os.makedirs(unzip_dir, exist_ok=True)
        else:
            extract_dir = f'/Volumes/{catalog}/{unstructured_schema}/{source}/sap_files/processing/'
            unzip_dir = os.path.join(extract_dir, f"unzipped_{uuid.uuid4().hex}")  # ← NEW
        # os.makedirs(unzip_dir, exist_ok=True) 
        try:
            with zipfile.ZipFile(local_path, "r") as z:
                z.extractall(unzip_dir)
            # do NOT upload this inner zip 
            for root, _, files in os.walk(unzip_dir):
                for f in files:
                    child_path = os.path.join(root, f)
                    rel = os.path.relpath(child_path, unzip_dir).replace("\\", "/")
                    rel = rel.replace("../","")
                    _handle_local_file(child_path,
                                    #    blob_stem,
                                       converted_counter,
                                       nested_key + f"_zip_{rel.replace('/', '_')}")
        finally:
            shutil.rmtree(unzip_dir)   # always clean extracted folder
    else:
        # other non-zip, non-supported files – keep old behaviour
        child_blob = f"{nested_key}"
        if env == 'sbx':
            upload_to_blob(local_path, f'{source}/pdf_files/raw/{child_blob}')
        else:
            upload_to_blob(local_path, f'/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files/raw/{child_blob}')



# ==== Main processor ====
def process_partition(blob_tuples):
    # os.makedirs(TEMP_DIR, exist_ok=True)
    

    converted_count = 0

    for blob_name, ext in blob_tuples:
        ext = ext.lower()
        # source_blob = source_client.get_blob_client(blob_name)
        file_name = os.path.basename(blob_name)
        # local_input = os.path.join(TEMP_DIR, file_name)
        base_name = os.path.splitext(file_name)[0]
        
        try:

            if ext in SUPPORTED_FILE_TYPES:

                # dbutils.fs.cp(blob_name, local_input)
                # logger.info(f"Downloaded blob: {blob_name}")
                # if os.path.getsize(local_input) < 100:
                #     logger.info(f"Skipping small file: {blob_name}")
                #     dest_path = blob_name.replace(RAW_PREFIX, RAW_PREFIX)
                #     upload_to_blob(local_input, dest_path, dest_client)
                #     archive_path = blob_name.replace(RAW_PREFIX, PROCESSED_PREFIX)
                #     archive_blob(source_blob, archive_path)
                if True:
                    if env == 'sbx':
                        TEMP_DIR = '/tmp/blob_processing'
                        source_blob = container_client.get_blob_client(blob_name)
                        os.makedirs(TEMP_DIR, exist_ok=True)
                        local_input = os.path.join(TEMP_DIR, os.path.basename(blob_name))
                        with open(local_input, "wb") as f:
                            f.write(source_blob.download_blob().readall())
                        logger.info(f"Downloaded blob: {blob_name}")
                        pdf_path = convert_to_pdf_file(local_input, ext)
                        if pdf_path:
                            pdf_blob_name = file_name.replace(ext, f"-{ext[1:]}.pdf")
                            upload_to_blob(pdf_path, f'{source}/pdf_files/raw/{pdf_blob_name}')
                            # archive_path = blob_name.replace(RAW_PREFIX, PROCESSED_PREFIX)
                            archive_blob(file_name)
                            os.remove(pdf_path)
                            logger.info(f"Successfully converted {blob_name} to PDF")
                            converted_count += 1

                    else:
                        pdf_path = convert_to_pdf_file(blob_name, ext)
                        if pdf_path:
                            pdf_blob_name = file_name.replace(ext, f"-{ext[1:]}.pdf")
                            upload_to_blob(pdf_path, f'/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files/raw/{pdf_blob_name}')
                            # archive_path = blob_name.replace(RAW_PREFIX, PROCESSED_PREFIX)
                            archive_blob(file_name)
                            os.remove(pdf_path)
                            logger.info(f"Successfully converted {blob_name} to PDF")
                            converted_count += 1
                    # else:
                    #     upload_to_blob(local_input, blob_name.replace(RAW_PREFIX, RAW_PREFIX), dest_client)
                    #     archive_path = blob_name.replace(RAW_PREFIX, PROCESSED_PREFIX)
                    #     archive_blob(source_blob, archive_path)

            elif ext == ".zip":

                logger.info(f"Processing ZIP file: {blob_name}")
                if env == 'sbx':
                    TEMP_DIR = '/tmp/blob_processing'
                    source_blob = container_client.get_blob_client(blob_name)
                    os.makedirs(TEMP_DIR, exist_ok=True)
                    local_input = os.path.join(TEMP_DIR, os.path.basename(blob_name))
                    with open(local_input, "wb") as f:
                        f.write(source_blob.download_blob().readall())
                    extract_dir = os.path.join(TEMP_DIR, base_name + "_unzipped")
                    os.makedirs(extract_dir, exist_ok=True)
                    with zipfile.ZipFile(local_input, 'r') as zip_ref:
                        zip_ref.extractall(extract_dir)
                    # ---------- for nested zip ----------
                    for root, _, files in os.walk(extract_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            rel = os.path.relpath(file_path, f"{extract_dir}").replace("\\", "/")
                            rel = rel.replace("../","")
                            # pass mutable counter so helper can increment
                            _handle_local_file(file_path,
                                            # file_name.replace(".zip", ""),
                                            [converted_count],      # ← NEW
                                            base_name + f"_zip_{rel.replace('/', '_')}")


                else:
                    extract_dir = f'/Volumes/{catalog}/{unstructured_schema}/{source}/sap_files/processing/'
                    with zipfile.ZipFile(blob_name, 'r') as zip_ref:
                        zip_ref.extractall(extract_dir)

                    # ---------- for nested zip ----------
                    for root, _, files in os.walk(extract_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            rel = os.path.relpath(file_path, f"{extract_dir}{base_name}").replace("\\", "/")
                            rel = rel.replace("../","")
                            # pass mutable counter so helper can increment
                            _handle_local_file(file_path,
                                            # file_name.replace(".zip", ""),
                                            [converted_count],      # ← NEW
                                            base_name + f"_zip_{rel.replace('/', '_')}")

                shutil.rmtree(extract_dir)
                # archive only the *outer* zip not thenested zips inside
                archive_blob(file_name)             

            else:
                if env == 'sbx':
                    source_blob = container_client.get_blob_client(blob_name)
                    dest_blob_name = f'{source}/pdf_files/raw/{file_name}'
                    dest_blob = container_client.get_blob_client(dest_blob_name)
                    dest_blob.start_copy_from_url(source_blob.url)
                else:
                    dbutils.fs.cp(blob_name, f'/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files/raw/{file_name}')

                archive_blob(file_name)

        except Exception as e:
            logger.error(f"Error processing {blob_name}: {e}", exc_info=True)
            try:
                if env == 'sbx':
                    source_blob = container_client.get_blob_client(blob_name)
                    dest_blob_name = f'{source}/sap_files/failed/{file_name}'
                    dest_blob = container_client.get_blob_client(dest_blob_name)
                    dest_blob.start_copy_from_url(source_blob.url)
                    source_blob.delete_blob()
                else:
                    dbutils.fs.mv(blob_name, f'/Volumes/{catalog}/{unstructured_schema}/{source}/sap_files/failed/{file_name}')

                logger.info(f"Moved failed blob to: ")
            except Exception as move_err:
                logger.error(f"Failed to move blob {blob_name} to fail folder: {move_err}", exc_info=True)


    return converted_count

# ==== Batch runner ====
def batch_process(blob_list):
    total = len(blob_list)
    logger.info(f"Starting batch processing of {total} files")
    
    for i in range(0, total, BATCH_SIZE):
        batch = blob_list[i:i + BATCH_SIZE]
        logger.info(f"Processing batch {i // BATCH_SIZE + 1} ({len(batch)} files)")
        
        try:
            converted = process_partition(batch)
            logger.info(f"Completed batch {i // BATCH_SIZE + 1} | Converted: {converted}")
        except Exception as e:
            logger.error(f"Batch {i // BATCH_SIZE + 1} failed: {e}", exc_info=True)

# ==== Temp cleaner ====
def clear_temp_folder(path):
    if not os.path.exists(path):
        logger.warning(f"Temp folder does not exist: {path}")
        return
    
    logger.info(f"Cleaning up temp folder: {path}")
    try:
        dbutils.fs.rm(path, True)
    except Exception as e:
        logger.error(f"Failed to clean up temp folder: {e}", exc_info=True)


# ==== Main ====
def process_files(spark, config):
    try:
        # List Configurable variables
        global dbutils, source, BATCH_SIZE, SUPPORTED_FILE_TYPES, catalog, silver_schema, bronze_schema, env, unstructured_schema
        source = "everest"
        catalog=config['TARGET_CATALOG']
        silver_schema = config['SILVER_SCHEMA']
        bronze_schema = config['BRONZE_SCHEMA']
        unstructured_schema = config['UNSTRUCTURED_SCHEMA_EVEREST']
        BATCH_SIZE = 200
        env = config['ENV']
        container = config['UNSTRUCTURED_CONTAINER']
        dbutils = DBUtils(spark)
        if env == 'sbx':
            global container_client
            keyvault_scope  = config['KEYVAULT_SCOPE']
            storage_name = dbutils.secrets.get(scope=keyvault_scope, key ='BLOB-STORAGE-ACCOUNT-NAME')
            account_key = dbutils.secrets.get(scope=keyvault_scope, key='BLOB-STORAGE-ACCESS-KEY')
            BLOB_CONNECTION_STRING = f"DefaultEndpointsProtocol=https;AccountName={storage_name};AccountKey={account_key};EndpointSuffix=core.windows.net"
            blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
            container_client = blob_service_client.get_container_client(container)
        # TEMP_DIR = config['TEMP_DIR']
        # blob_connection_string = config['BLOB_CONNECTION_STRING']
        SUPPORTED_FILE_TYPES = config['FILE_TYPES_TO_CONVERT']

        logger.info("Initialized configuration variables.")

        # force_blob_refresh(spark)
        logger.info("Spark cache refreshed.")

        blobs = get_blob_list()
        if not blobs:
            logger.warning("No blobs found for processing.")
        else:
            logger.info(f"Total blobs retrieved: {len(blobs)}")
            batch_process(blobs)

        if env == 'sbx':
            clear_temp_folder(f'/tmp/blob_processing')
        else:
            clear_temp_folder(f'/Volumes/{catalog}/{unstructured_schema}/{source}/sap_files/processing')
        logger.info("Temporary folder cleaned.")

    except Exception as e:
        logger.error(f"Error occurred in file processing: {e}", exc_info=True)
''