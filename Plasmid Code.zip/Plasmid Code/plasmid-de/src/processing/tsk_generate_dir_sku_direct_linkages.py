from logs.logger import get_logger
logger = get_logger()

def generate_dir_sku_direct_linkages_table(spark, config):
    try:
        source_catalog = config['SOURCE_CATALOG']
        source_tahiti_schema = config['SOURCE_SCHEMA_TAHITI']
        source_everest_schema = config['SOURCE_SCHEMA_EVEREST']
        target_catalog = config['TARGET_CATALOG']
        target_schema = config['SILVER_SCHEMA']
        target_table = config['TARGET_TABLE_NAME_DIR_SKU_DIRECT_LINKAGES']
        tahiti_material_table = config['MATERIAL_TABLE_NAME_MELE']
        everest_material_table = config['MATERIAL_TABLE_NAME_PLASTIPAK']
        dir_sku_linkages_table = f"{target_catalog}.{target_schema}.{target_table}"
        
        table_list = ['drad', 'aeoi', 'aenr', 'mast', 'makt', 'stko', 'stpo', 'stas']
        
        dir_metadata_file_path = 'src/processing/sql/get_dir_sku_direct_linkages_details.sql'
        
        
        logger.info(f"Generating dir  sku direct linkages metadata table: {dir_sku_linkages_table}")
        
        
        logger.info(f"Reading dir metadata table ddl query")
        with open(dir_metadata_file_path, 'r') as file:
            sql_query = file.read()
        logger.info(f"Completed Readingdir  sku direct linkages table ddl query")
        # Replace the placeholder with the actual table name
        for table in table_list:
            tahiti_table = '{'+'{' + f"+tahiti_{table}_table" + '}' + '}' 
            everest_table = '{'+'{' + f"+everest_{table}_table" + '}' + '}'
            tahiti_orig_table = f"{source_catalog}.{source_tahiti_schema}.{table}"
            everest_orig_table = f"{source_catalog}.{source_everest_schema}.{table}"
            sql_query = sql_query.replace(tahiti_table, tahiti_orig_table)
            sql_query = sql_query.replace(everest_table, everest_orig_table)
        
        
        sql_query = sql_query.replace('{{tahiti_material_table}}', f'{target_catalog}.{target_schema}.{tahiti_material_table}')
        sql_query = sql_query.replace('{{everest_material_table}}', f'{target_catalog}.{target_schema}.{everest_material_table}')
        
        
        # Run the query
        logger.info("Executing DDL query")
        df = spark.sql(sql_query)
        df = df.dropDuplicates()
        
        
        df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(dir_sku_linkages_table)
        logger.info("dir  sku direct linkages metadata table created successfully")
        
        
        
    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        raise(f"File not found: {e}")
    except KeyError as e:
        logger.error(f"Missing configuration key: {e}")
        raise(f"Missing configuration key: {e}")
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise(f"An error occurred: {e}")