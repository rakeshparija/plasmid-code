from pyspark.sql.functions import when, lit, col
from logs.logger import get_logger
logger = get_logger()

def generate_dir_metadata_table(spark, config):
    
    try:
        source_catalog = config['SOURCE_CATALOG']
        source_tahiti_schema = config['SOURCE_SCHEMA_TAHITI']
        source_everest_schema = config['SOURCE_SCHEMA_EVEREST']
        target_catalog = config['TARGET_CATALOG']
        target_schema = config['SILVER_SCHEMA']
        target_table = config['TARGET_TABLE_NAME_DIR_SAP_METADATA']
        tahiti_material_table = config['MATERIAL_TABLE_NAME_MZLE']
        everest_material_table = config['MATERIAL_TABLE_NAME_PLASTIPAK']
        dir_table = f"{target_catalog}.{target_schema}.{target_table}"
        
        #Everest
        table_list = ['dred', 'meol', 'draw', 'mast', 'stko', 'stpo', 'mara', 'drat']
        
        everest_sql_file_path = "src/processing/sql/get_everest_dir_metadata_detail.sql"
        
        logger.info(f"Reading eVerest dir metadata table ddl query")
        with open(everest_sql_file_path, 'r') as file:
            everest_sql_query = file.read()
        logger.info(f"Completed Reading Everest dir metadata table ddl query")
        
        #Tahiti
        tahiti_sql_file_path = 'src/processing/sql/get_tahiti_dir_metadata_detail.sql'
        
        logger.info(f"Reading Tahiti dir metadata table ddl query")
        with open(tahiti_sql_file_path, 'r') as file:
            tahiti_sql_query = file.read()
        logger.info(f"Completed Reading Tahiti dir metadata table ddl query")
        
        
        # Replace the placeholder with the actual table name
        for table in table_list:
            
            everest_table = '{'+' ' + f"everest_{{table}}_table" + ' }' + '}'
            everest_orig_table = f"{source_catalog}.{source_everest_schema}.{table}"
            everest_sql_query = everest_sql_query.replace(everest_table, everest_orig_table)
            
            tahiti_table = '{'+'{' + f"tahiti_{{table}}_table" + ' }' + '}' 
            tahiti_orig_table = f"{source_catalog}.{source_tahiti_schema}.{table}"
            tahiti_sql_query = tahiti_sql_query.replace(tahiti_table, tahiti_orig_table)
            
        
        everest_sql_query = everest_sql_query.replace('{{everest_material_table}}', f'{target_catalog}.{target_schema}.{everest_material_table}')
        
        tahiti_sql_query = tahiti_sql_query.replace('{{tahiti_material_table}}', f'{target_catalog}.{target_schema}.{tahiti_material_table}')
        
        # Run the query
        logger.info("Executing Everest DDL query")
        # print(everest_sql_query)
        everest_df = spark.sql(everest_sql_query)
        logger.info("Completed Everest DDL query")
        
        logger.info("Executing Tahiti DDL query")
        tahiti_df = spark.sql(tahiti_sql_query)
        logger.info("Completed Tahiti DDL query")
        
        # Ensure both DataFrames have same schema
        common_cols = list(set(everest_df.columns) & set(tahiti_df.columns))
        everest_df = everest_df.select(common_cols)
        tahiti_df = tahiti_df.select(common_cols)
        
        # Handle empty DataFrame union safely
        if everest_df.rdd.isEmpty() and tahiti_df.rdd.isEmpty():
            logger.warning("Both Everest and Tahiti dataframes are empty. Skipping write.")
        else:
            df = everest_df.unionByName(tahiti_df)
            df = df.withColumn("BusinessUnit", when( col("Source") == "Everest",
                    lit('plastipak'))
                ).otherwise(lit('mzle')))
            logger.info("Creating dir metadata table")
            df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(dir_table)
            logger.info("DIR metadata table created successfully")
            logger.info("Deleting records which have same DocArea and DocNumber")
            spark.sql(f"DELETE FROM {dir_table} WHERE DocNumber=DocArea")
            
    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        raise(f"File not found: {e}")
    except KeyError as e:
        logger.error(f"Missing configuration key: {e}")
        raise(f"Missing configuration key: {e}")
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise(f"An error occurred: {e}")