logger = get_logger()

def process_mara_details(spark, config):
    """ Function to process MARA table details for MZLE and Plastipack. """

    try:
        logger.info("Initializing MARA table processing.")

        # Extract relevant values from config
        source_catalog = config["SOURCE_CATALOG"]
        source_schema_tahiti = config["SOURCE_SCHEMA_TAHITI"]
        source_schema_everest = config["SOURCE_SCHEMA_EVEREST"]
        source_table_name_mara = config["SOURCE_TABLE_NAME_MARA"]
        target_catalog = config["TARGET_CATALOG"]
        silver_schema = config["SILVER_SCHEMA"]
        material_table_name_mzle = config["MATERIAL_TABLE_NAME_MZLE"]
        material_table_name_plastipak = config["MATERIAL_TABLE_NAME_PLASTIPAK"]
        target_table_name_mara = config["TARGET_TABLE_NAME_PRODUCT_HIERARCHY"]

        # Query MZLE dataset
        logger.info("Fetching MZLE dataset.")
        mzle_mara_df = spark.sql(
            f"""SELECT MATNR, PRODHA, 'mzle' AS ProductLine, 'Tahiti' AS Source
                FROM {source_catalog}.{source_schema_tahiti}.{source_table_name_mara}
                WHERE MATNR IN (
                    SELECT Material FROM {target_catalog}.{silver_schema}.{material_table_name_mzle}
                );"""
        )

        # Query Plastipack dataset
        logger.info("Fetching Plastipack dataset.")
        plastipak_mara_df = spark.sql(
            f"""SELECT MATNR, PRODHA, 'plastipak' AS ProductLine, 'Everest' AS Source
                FROM {source_catalog}.{source_schema_everest}.{source_table_name_mara}
                WHERE MATNR IN (
                    SELECT Material FROM {target_catalog}.{silver_schema}.{material_table_name_plastipak}
                );"""
        )

        # Merge both datasets
        logger.info("Merging MARA datasets.")
        final_df = mzle_mara_df.union(plastipak_mara_df)

        # Save the merged dataset to final table
        logger.info(f"Saving final dataset to {target_catalog}.{silver_schema}.{target_table_name_mara}.")
        final_df.write.mode("overwrite").format("delta").option("overwriteSchema", "true") \
            .saveAsTable(f"{target_catalog}.{silver_schema}.{target_table_name_mara}")

        logger.info(f"Table saved successfully: {target_catalog}.{silver_schema}.{target_table_name_mara}")

    except Exception as e:
        logger.error(f"An error occurred during MARA table processing: {e}")
        raise(f"Exception: {e}")
