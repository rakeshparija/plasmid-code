from azure.storage.blob import BlobServiceClient
import io
import os
from logs import logger
from pyspark.sql.functions import lit, current_timestamp, col
import pandas as pd
from openpyxl import load_workbook
import subprocess
import re
import tempfile
from datetime import datetime
from delta.tables import DeltaTable
from pyspark.dbutils import DBUtils
from logs.logger import get_logger
logger = get_logger()

def convert_xls_to_xlsx(input_file, output_file):
    command = ['libreoffice', '--headless', '--convert-to', 'xlsx', input_file, '--outdir', output_file]
    subprocess.run(command, check=True)

def is_empty_cell(value):
    return value is None or str(value).strip() == ''

def load_sheet_values(sheet):
    """Load all values as a 2D list"""
    max_row = sheet.max_row
    max_col = sheet.max_column
    values = []
    for r in range(1, max_row + 1):
        row = []
        for c in range(1, max_col + 1):
            row.append(sheet.cell(row=r, column=c).value)
        values.append(row)
    return values

def detect_table_boundary(data, start_row, start_col, visited):
    max_rows = len(data)
    max_cols = len(data[0])

    # Step 1: Determine row boundary (end_row is exclusive)
    row = start_row
    empty_row_streak = 0
    while row < max_rows:
        if all((is_empty_cell(data[row][c]) or visited[row][c]) for c in range(start_col, max_cols)):
            empty_row_streak += 1
            if empty_row_streak >= 2:
                break
        else:
            empty_row_streak = 0
        row += 1
    end_row = row if empty_row_streak >= 2 else max_rows

    # Step 2: Determine column boundary (end_col is exclusive)
    col = start_col
    empty_col_streak = 0
    while col < max_cols:
        if all((is_empty_cell(data[r][col]) or visited[r][col]) for r in range(start_row, end_row)):
            empty_col_streak += 1
            if empty_col_streak >= 2:
                break
        else:
            empty_col_streak = 0
        col += 1
    end_col = col if empty_col_streak >= 2 else max_cols

    return end_row, end_col

def extract_table(data, start_row, end_row, start_col, end_col):
    table_data = []
    for r in range(start_row, end_row):
        row_data = []
        for c in range(start_col, end_col):
            row_data.append(data[r][c])
        table_data.append(row_data)
    df = pd.DataFrame(table_data)
    df.dropna(how='all', inplace=True)
    df.dropna(axis=1, how='all', inplace=True)
    return df if not df.empty else None

def extract_tables_from_sheet(sheet):
    data = load_sheet_values(sheet)
    visited = [[False for _ in range(len(data[0]))] for _ in range(len(data))]
    tables = []

    for r in range(len(data)):
        for c in range(len(data[0])):
            if not is_empty_cell(data[r][c]) and not visited[r][c]:
                end_r, end_c = detect_table_boundary(data, r, c, visited)
                # Mark visited
                for i in range(r, end_r):
                    for j in range(c, end_c):
                        visited[i][j] = True
                df = extract_table(data, r, end_r, c, end_c)
                if df is not None:
                    tables.append(df)
    return tables

def extract_tables_from_file(filepath):
    wb = load_workbook(filepath, data_only=True)
    file_tables = []
    for sheetname in wb.sheetnames:
        sheet = wb[sheetname]
        tables = extract_tables_from_sheet(sheet)
        # Join all elements of tables by '| table no.' and give table no. to each element
        joined_tables = []
        for idx, table in enumerate(tables, 1):
            table_str = table.to_dict()
            joined_tables.append(f"\n ##Table {idx} \n \n {table_str} ")
        file_tables.append("\n".join(joined_tables))
    return file_tables

def get_dir_num(file_path):
    parts = file_path.split('_')
    search_parts = parts[:-1] if len(parts) > 1 else parts
    joined_search_part = "_".join(search_parts)
    dir_num = file_path
    for d in dir_set:
        if d in joined_search_part:
            dir_num = d
            return dir_num
    return file_path
        
def process_excel_ocr(spark, config):
    source = "everest"
    catalog = config['TARGET_CATALOG']
    schema = config['SILVER_SCHEMA']
    unstructured_schema = config['UNSTRUCTURED_SCHEMA_EVEREST']
    dir_table = config["TARGET_TABLE_NAME_DIR_SAP_METADATA"]
    dbutils = DBUtils(spark)
    keyvault_scope  = config['KEYVAULT_SCOPE']
    env = config['ENV']
    if env == 'sbx':
        storage_name = dbutils.secrets.get(scope=keyvault_scope, key ='BLOB-STORAGE-ACCOUNT-NAME')
        account_key = dbutils.secrets.get(scope=keyvault_scope, key='BLOB-STORAGE-ACCESS-KEY')
    else:
        storage_name = dbutils.secrets.get(scope=keyvault_scope, key ='ADLS-ACCOUNT-NAME')
        account_key = dbutils.secrets.get(scope=keyvault_scope, key='ADLS-CONNECTION-STRING')

    spark.conf.set(
    f"fs.azure.account.key.{storage_name}.blob.core.windows.net",
    account_key
    )
    BLOB_CONNECTION_STRING = f"DefaultEndpointsProtocol=https;AccountName={storage_name};AccountKey={account_key};EndpointSuffix=core.windows.net"
    blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)

    if env == 'sbx':
        pdf_container = blob_service_client.get_container_client(config['UNSTRUCTURED_CONTAINER'])
        blob_list = pdf_container.list_blobs(name_starts_with=f"{source}/pdf_files/raw/")
        list_of_files_blob_everest = [blob.name for blob in blob_list]
        excel_files = [blob for blob in list_of_files_blob_everest if blob.lower().endswith(('.xls', '.xlsx', '.xlsm'))]
    else:
        files_path = f"/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files"
        list_of_files = dbutils.fs.ls(f"{files_path}/raw/")
        excel_files = [f.path for f in list_of_files if f.path.lower().endswith(('.xls', '.xlsx', '.xlsm'))]

    logger.info(f"list_of_files_present: {excel_files}")


    # dir logic
    df = spark.sql(f"select DocNumber from {catalog}.{schema}.{dir_table} where Source = 'Everest' ").toPandas()
    if "DocNumber" not in df.columns:
        raise ValueError(f"'DocNumber' column not found,")

    cleaned_docs = (
        df["DocNumber"]
        .dropna()
        .astype(str)
        .str.lstrip("0")
        .str.strip()
    )
    global dir_set
    dir_set = sorted(set(cleaned_docs), key=len, reverse=True)
    logger.info(f"[INFO] Total unique DirNumbers : {len(dir_set)}")

    # excel processing started
    final_df_list = []
    required_columns = [
        "DocName",
        "BlobPath",
        "DirNumber",
        "Status",
        "Error",
        "Ocr",
        "ParsingMethod",
        "LastUpdatedAt",
        "ProcessingTimeSec",
        "TimeLogs",
        "IsPostOcr",
        "IsLinkage",
        "Source",
        "BusinessUnit"
    ]
    # Define paths
    if env == 'sbx':
        unstructured_container = config['UNSTRUCTURED_CONTAINER']
        source_parquet = f"abfss://{unstructured_container}@{storage_name}.dfs.core.windows.net/{source}/ocr_files/plasmid_ocr_details_etl/"
        delta_target   = f"abfss://{unstructured_container}@{storage_name}.dfs.core.windows.net/{source}/ocr_files/plasmid_ocr_details_etl_delta/"
    else:
        source_parquet = f"/Volumes/{catalog}/{unstructured_schema}/{source}/ocr_files/plasmid_ocr_details_etl/"
        delta_target = f"/Volumes/{catalog}/{unstructured_schema}/{source}/ocr_files/plasmid_ocr_details_etl_delta/"

    for file_path in excel_files:
        try:
            final_dict = {}
            start_time = datetime.now()
            file_path = file_path.replace("dbfs:","")
            full_path = file_path #f"Everest/raw/{file_path}"
            file_name = os.path.basename(file_path)
            logger.info(f"Processing : {full_path}")
            # blob_client = client.get_blob_client(full_path)

            if full_path.endswith('.xlsx'):
                suffix = '.xlsx'
            elif full_path.endswith('.xlsm'):
                suffix = '.xlsm'
            elif full_path.endswith('.XLS'):
                suffix = '.XLS'
            elif full_path.endswith('.xls'):
                suffix = '.xls'



            if env == "sbx":
                # Read from Azure Blob Storage
                blob_client = pdf_container.get_blob_client(file_path)
                download_stream = blob_client.download_blob()
                file_bytes = download_stream.readall()
            else:
                # Read from Databricks volume
                with open(file_path, "rb") as f:
                    file_bytes = f.read()

            # Save to temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
                tmp_file.write(file_bytes)
                tmp_file_path = tmp_file.name

            if full_path.endswith('.xls'):
                convert_xls_to_xlsx(tmp_file_path, '/tmp/')
                tmp_file_path = tmp_file_path.replace('.xls', '.xlsx')
            if full_path.endswith('.XLS'):
                convert_xls_to_xlsx(tmp_file_path, '/tmp/')
                tmp_file_path = tmp_file_path.replace('.XLS', '.xlsx')

            tables = extract_tables_from_file(tmp_file_path)
            tables = [t for t in tables if t is not None and not (isinstance(t, str) and t == '')]
            ocr_parse_list = []
            for i in range(len(tables)):
                ocr_parse_dict = {}
                ocr_parse_dict['page_num'] = i + 1
                ocr_parse_dict['method'] = 'excel_parsed'
                ocr_parse_dict['reason'] = 'excel_parsed'
                ocr_parse_dict['angle_tess'] = 1000
                ocr_parse_dict['angle_fitz'] = 1000
                ocr_parse_dict['conf_score'] = 1.5
                ocr_parse_list.append(ocr_parse_dict)

            end_time = datetime.now()
            processing_time_sec = (end_time - start_time).total_seconds()

            final_dict['DocName'] = str(file_name)
            final_dict['Ocr'] = tables
            final_dict['ParsingMethod'] = str(ocr_parse_list)
            final_dict['BlobPath'] = file_path #str(blob_client.url)
            final_dict['LastUpdatedAt'] = str(end_time)
            final_dict['Status'] = 'OK'
            final_dict['Error'] = ''
            final_dict['ProcessingTimeSec'] = processing_time_sec
            final_dict['TimeLogs'] = str(processing_time_sec)
            final_dict['IsPostOcr'] = 'no'
            final_dict['IsLinkage'] = 'no'
            final_dict['Source'] = 'Everest'
            final_dict['BusinessUnit'] = 'plastipak'
            final_dict['DirNumber'] = str(get_dir_num(file_name))
            # Ensure all required columns are present, add with default value '' if missing
            for column in required_columns:
                if column not in final_dict:
                    final_dict[column] = ''

            logger.info(f"OCR done for {file_path}")
            # logger.info(f"{final_dict}")
            
            # final_df_list.append(final_dict)
        except Exception as e: 
            logger.error(f"Error in {file_path} : {e}")
            final_dict['DocName'] = str(file_name)
            final_dict['Ocr'] = [""]
            final_dict['ParsingMethod'] = ""
            final_dict['BlobPath'] = file_path #str(blob_client.url)
            final_dict['LastUpdatedAt'] = ""
            final_dict['Status'] = 'Error'
            final_dict['Error'] = str(e)
            final_dict['ProcessingTimeSec'] = 0.0
            final_dict['TimeLogs'] = '0.0'
            final_dict['IsPostOcr'] = 'no'
            final_dict['IsLinkage'] = 'no'
            final_dict['Source'] = 'Everest'
            final_dict['BusinessUnit'] = 'plastipak'
            final_dict['DirNumber'] = str(get_dir_num(file_name))
            # final_df_list.append(final_dict)
            continue
        finally:
            
            df_pd=pd.DataFrame([final_dict])
            # logger.info(f"Columns: {df_pd.dtypes}")
            parquet_bytes = io.BytesIO()
            df_pd.to_parquet(parquet_bytes, index=False, engine='pyarrow')
            parquet_bytes.seek(0)
            base_file_name = file_name.replace(suffix, "")
            blob_name = f"plasmid_ocr_details_etl/{base_file_name}.parquet"
            if env == 'sbx':
                parquet_file_path = f"{source}/ocr_files/{blob_name}"
                pdf_container.upload_blob(name=parquet_file_path, data=parquet_bytes, overwrite=True)
            else:
                output_file_path = f"/Volumes/{catalog}/{unstructured_schema}/{source}/ocr_files/{blob_name}"
                with open(output_file_path, "wb") as f:
                    f.write(parquet_bytes.getvalue())
            
            logger.info("Writing to parquet file completed")

            if env == 'sbx':
                if final_dict['Error'] == '':
                    archive_path = file_path.replace('/raw/', '/processed/')
                else:
                    archive_path = file_path.replace('/raw/', '/failed/excel_ocr/')
                pdf_container.upload_blob(name=archive_path, data=file_bytes, overwrite=True)
                blob_client.delete_blob()
            else:
                if final_dict['Error'] == '':
                    dbutils.fs.mv(file_path, f'/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files/processed/{file_name}')
                else:
                    dbutils.fs.mv(file_path, f'/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files/failed/excel_ocr/{file_name}')
            
            logger.info("Archiving process completed")


    from delta.tables import DeltaTable

    # Read new Parquet files
    df_new = spark.read.parquet(source_parquet)

    try:
        # Load Delta table
        delta_table = DeltaTable.forPath(spark, delta_target)

        logger.info("Delta path Found, Merging process begins")

        # Perform merge to avoid duplicates
        delta_table.alias("target").merge(
            df_new.alias("source"),
            "target.DocName = source.DocName"
        ).whenMatchedUpdate(
            condition="target.Status != 'OK'",
            set={col: f"source.{col}" for col in df_new.columns}
        ).whenNotMatchedInsertAll().execute()
        
        logger.info("Merging Completed")
    except Exception as e:
        logger.error(f"{e}")
        logger.info("Delta table not found, Dir")
        df_new.write.format("delta").mode("append").option("mergeSchema", "true").save(delta_target)

    