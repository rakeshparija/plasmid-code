from pyspark.dbutils import DBUtils
from logs.logger import get_logger
logger = get_logger()

def create_table(spark, config):
    
    keyvault_scope = config['KEYVAULT_SCOPE']
    dbutils = DBUtils(spark)
    storage_name = dbutils.secrets.get(scope=keyvault_scope, key='ADLS-ACCOUNT-NAME')
    catalog = config['TARGET_CATALOG']
    silver_schema = config['SILVER_SCHEMA']
    ocr_table = config['TARGET_TABLE_NAME_OCR_RESULTS']
    try:
        
        logger.info("Creating External table for ocr Details")
        spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog}.{silver_schema}.{ocr_table}
            USING DELTA
            LOCATION 'abfss://ocr-container@{storage_name}.dfs.core.windows.net/{ocr_table}_etl_delta/' """)
    
    except Exception as e:
        logger.info(f"Error: {e}")
        spark.sql(f"""CREATE TABLE IF NOT EXISTS hub_mlops_dev.s_plasmid.plasmid_document_details_test USING DELTA LOCATION 'abfss://ocr-container@adlsudwmlthelapluspde01.dfs.core.windows.net/s_plasmid_tables/plasmid_document_details/'""")
        # spark.sql(f"""CREATE TABLE IF NOT EXISTS hub_mlops_dev.s_plasmid.plasmid_ocr_details
        # USING DELTA
        # LOCATION 'abfss://ocr-container@{storage_name}.blob.core.windows.net/plasmid_ocr_details_etl_delta/' """)
        # spark.sql(f"""CREATE EXTERNAL VOLUME hub_mlops_dev.b_plasmid.ocr_container
        # LOCATION 'abfss://ocr-container@{storage_name}.blob.core.windows.net/' """)
    
    try:
        # Define base paths for both folders
        base_paths = {
            "s_plasmid": f"abfss://ocr-container@{storage_name}.dfs.core.windows.net/s_plasmid",
            "g_plasmid": f"abfss://ocr-container@{storage_name}.dfs.core.windows.net/g_plasmid"
        }
        
        # Unity Catalog target catalog
        catalog = config['TARGET_CATALOG']
        
        # Loop through each schema and its base path
        for schema, base_path in base_paths.items():
            # List all folders inside the current base path
            folders = [f.name.rstrip('/') for f in dbutils.fs.ls(base_path) if f.isDir()]
            
            for folder in folders:
                full_path = f"{base_path}/{folder}/"
                table_name = f"{catalog}.{schema}.{folder}"  # Add _test suffix or customize as needed
                
                try:
                    df = spark.read.format("delta").load(full_path)
                    df.write.mode("overwrite").saveAsTable(table_name)
                    logger.info(f"Created table: {table_name}")
                except Exception as e:
                    logger.info(f"Skipped {folder} in {schema}: {str(e)}")
    except Exception as e:
        logger.error(f"Error: {e}")

def clean_table(spark, config):
    catalog = config['TARGET_CATALOG']
    gold_schema = config['GOLD_SCHEMA']
    child_description_table = config['TARGET_TABLE_COMPONENTS_FIRST_LEVEL_CHILD_DESC']
    spark.sql(f"DROP TABLE IF EXISTS {catalog}.{gold_schema}.{child_description_table}")