with materials_for_dir_script as (
    select distinct Material from {{tahiti_material_table}}
),
one_sku_materials_dir_list as (
  select distinct DOKAR, DOKNR,DOKVR,DOKTL from (
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from (
                select distinct DOKAR, DOKNR,DOKVR,DOKTL from(
                select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
                    select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                        select distinct material from materials_for_dir_script
                    )
                    )
                    union
                    select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                        select distinct material from materials_for_dir_script
                    )
                    )
                    union
                    select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                    )
                )and len(OBJKY) > 1
                union
                select distinct DOKAR,DOKNR,DOKVR,DOKTL from {{tahiti_draw_table}} where AENNR in (
                select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                    )
                )and len(AENNR) > 1
            ) 
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
            select distinct OBJKY from {{tahiti_drad_table}} where DOKNR in (
                select distinct DOKNR from (
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
                    select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                        select distinct material from materials_for_dir_script
                    )
                    )
                    union
                    select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                        select distinct material from materials_for_dir_script
                    )
                    )
                    union
                    select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                    )
                )and len(OBJKY) > 1
                union
                select distinct DOKAR,DOKNR,DOKVR,DOKTL from {{tahiti_draw_table}} where AENNR in (
                select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                    )
                )and len(AENNR) > 1
            ) 
            )and DOKOB='VCM_PFOLD'
            ) and len(OBJKY) > 1
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from (
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_draw_table}} where AENNR in (
            select distinct AENNR from {{tahiti_draw_table}} where DOKNR in (
            select distinct DOKNR from {{tahiti_draw_table}} where AENNR in (
                select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                    )
                )and len(AENNR) > 1
            )) and len(AENNR) > 1 
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
            select distinct AENNR from {{tahiti_draw_table}} where DOKNR in (
            select distinct DOKNR from {{tahiti_draw_table}} where AENNR in (
                select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                    )
                )and len(AENNR) > 1
            )
            )and DOKOB='AENR' and len(OBJKY) > 1
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
            select distinct OBJKY from {{tahiti_drad_table}} where DOKNR in (
                select distinct DOKNR from {{tahiti_drad_table}} where OBJKY in (
                select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                )
                ) and len(OBJKY) > 1
            )and DOKOB='AENR'
            ) and len(OBJKY) > 1 
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_draw_table}} where AENNR in (
            select distinct OBJKY from {{tahiti_drad_table}} where DOKNR in (
                select distinct DOKNR from {{tahiti_drad_table}} where OBJKY in ( 
                select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                )
                ) and len(OBJKY) > 1
            )
            ) and len(AENNR) > 1 
            )
            union
            select distinct DOKAR, DOKNR, DOKVR, DOKTL from (
            select concat(DOKAR, DOKNR, DOKVR, DOKTL) as keys, * from {{tahiti_drad_table}} where concat(DOKAR, DOKNR, DOKVR, DOKTL) in (
                select distinct OBJKY from {{tahiti_drad_table}} where DOKNR in (
                select distinct DOKNR from(
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
                    select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                        select distinct material from materials_for_dir_script
                    )
                    )
                    union
                    select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                        select distinct material from materials_for_dir_script
                    )
                    )
                    union
                    select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                    )
                )and len(OBJKY) > 1
                union
                select distinct DOKAR,DOKNR,DOKVR,DOKTL from {{tahiti_draw_table}} where AENNR in (
                select distinct AENNR from {{tahiti_stko_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_stpo_table}} where STLNR in (
                    select distinct STLNR from {{tahiti_mast_table}} where MATNR in(
                    select distinct material from materials_for_dir_script
                    )
                )
                union
                select distinct AENNR from {{tahiti_aeoi_table}} where objkt in (
                    select distinct material from materials_for_dir_script
                    )
                )and len(AENNR) > 1
            ) 
            ) and DOKOB = 'DRAW'
            )
            )
            )
            union ------------flow-1
                select distinct DOKAR, DOKNR,DOKVR,DOKTL from (
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from (
                select distinct DOKAR, DOKNR,DOKVR,DOKTL FROM {{tahiti_drad_table}} where OBJKY in (
                select distinct material from materials_for_dir_script
                )
            )
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
            select distinct OBJKY from {{tahiti_drad_table}} where DOKNR in (
            select distinct DOKNR FROM {{tahiti_drad_table}} where OBJKY in (
            select distinct material from materials_for_dir_script
            )) and DOKOB='VCM_PFOLD'
            )
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from (
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
            select distinct OBJKY from {{tahiti_drad_table}} where DOKNR in (
            select distinct DOKNR FROM {{tahiti_drad_table}} where OBJKY in (
            select distinct material from materials_for_dir_script
            )) and DOKOB='AENR' 
            )
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_draw_table}} where AENNR in (
            select distinct OBJKY from {{tahiti_drad_table}} where DOKNR in (
            select distinct DOKNR FROM {{tahiti_drad_table}} where OBJKY in (
            select distinct material from materials_for_dir_script
            )) and DOKOB='AENR' 
            )
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_draw_table}} where AENNR in (
            select distinct AENNR from {{tahiti_draw_table}} where DOKNR in (
            select distinct DOKNR FROM {{tahiti_drad_table}} where OBJKY in (
            select distinct material from materials_for_dir_script
            )) 
            ) and len(AENNR) > 1
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where OBJKY in (
            select distinct AENNR from {{tahiti_draw_table}} where DOKNR in (
            select distinct DOKNR FROM {{tahiti_drad_table}} where OBJKY in (
            select distinct material from materials_for_dir_script
            )) 
            ) and len(OBJKY) > 1
            )
            union
            select distinct DOKAR, DOKNR,DOKVR,DOKTL from 
            (select concat(DOKAR,DOKNR,DOKVR,DOKTL) as keys,* from {{tahiti_drad_table}}) where keys in (
            select distinct OBJKY from {{tahiti_drad_table}} where DOKNR in (
            select distinct DOKNR FROM {{tahiti_drad_table}} where OBJKY in (  
            select distinct material from materials_for_dir_script
            )) 
            and DOKOB='DRAW'
            )
            )
  )
),
project_code as (
    select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{tahiti_drad_table}} where DOKNR in( 
                SELECT DISTINCT DOKNR from (
            SELECT DISTINCT DOKNR, SUBSTRING(DKTXT, 1, 4) AS DKTX
            FROM {{tahiti_drat_table}}
            WHERE DKTXT REGEXP '^[0-9]{4} .' 
            AND DOKNR IN (
                SELECT DISTINCT DOKNR 
                FROM one_sku_materials_dir_list
            ))
)
),
final_dir_list as (
    select distinct DOKAR, DOKNR, DOKVR, DOKTL from (
        select * from one_sku_materials_dir_list
        union
        select * from project_code
    )
),
final_dir_list_with_date as (
    SELECT a.DOKAR, a.DOKNR, a.DOKVR, a.DOKTL, max(ADATUM) AS LastUpdatedAt
    FROM final_dir_list a
    LEFT JOIN {{tahiti_draw_table}} b
    ON  a.DOKAR = b.DOKAR
    AND a.DOKNR = b.DOKNR
    AND a.DOKVR = b.DOKVR
    AND a.DOKTL = b.DOKTL
    group by a.DOKAR, a.DOKNR, a.DOKVR, a.DOKTL
),
final_dir_list_with_status as (
  SELECT a.DOKAR, a.DOKNR, a.DOKVR, a.DOKTL, a.LastUpdatedAt, b.DOKST
    FROM final_dir_list_with_date a
    LEFT JOIN {{tahiti_draw_table}} b
    ON  a.DOKAR = b.DOKAR
    AND a.DOKNR = b.DOKNR
    AND a.DOKVR = b.DOKVR
    AND a.DOKTL = b.DOKTL
    AND a.LastUpdatedAt = b.ADATUM
),
final_dir_meta_desc as
(
SELECT a.DOKAR, a.DOKNR, a.DOKVR, a.DOKTL,a.LastUpdatedAt,a.DOKST, b.DKTXT
    FROM final_dir_list_with_status a
    LEFT JOIN {{tahiti_drat_table}} b
    ON  a.DOKAR = b.DOKAR
    AND a.DOKNR = b.DOKNR
    AND a.DOKVR = b.DOKVR
    AND a.DOKTL = b.DOKTL
    AND b.LANGU = 'E'
)
SELECT DOKAR as DocArea, DOKNR as DocNumber, DOKVR as DocVersion, DOKTL as DocPart, LastUpdatedAt, DOKST as Status, DKTXT as Description, 'Tahiti' as Source
FROM final_dir_meta_desc