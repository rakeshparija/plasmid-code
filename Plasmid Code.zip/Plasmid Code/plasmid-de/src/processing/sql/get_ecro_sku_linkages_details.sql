with ecro_sku__linkages as (
select a2.* , c1.MAKTX
from (
select a1.*,b1.BOM
from (
select * from
(
select xx.*,yy.DOKNR,yy.DOKVR,yy.DOKTL,yy.DOKOB from (
select distinct(*) from
(select a.AENNR,a.OBJKT as matnr,b.AENST,b.datuv,b.andat,b.aedat,b.aetxt,b.AEGRU,b.CCART from {{tahiti_aeoi_table}} as a
left join {{tahiti_aenr_table}} as b
on a.AENNR=b.AENNR
where a.objkt in (
select distinct material from {{tahiti_material_table}}
))
union
(
select a.AENNR,a.matnr as matnr,b.AENST,b.datuv,b.andat,b.aedat,b.aetxt,b.AEGRU,b.CCART from
(
select aa.AENNR,bb.matnr from {{tahiti_stas_table}} aa
inner join
{{tahiti_mast_table}} bb
on aa.stlnr=bb.stlnr
where bb.matnr in (
select distinct material from {{tahiti_material_table}}
)) as a
left join {{tahiti_aenr_table}} as b
on a.AENNR=b.AENNR
 
)) as xx
left join {{tahiti_drad_table}} as yy
on xx.AENNR=yy.OBJKY
)
union
 
(
 
select xx.*,yy.DOKNR,yy.DOKVR,yy.DOKTL,yy.DOKOB from (
select distinct(*) from
(select a.AENNR,a.OBJKT as matnr,b.AENST,b.datuv,b.andat,b.aedat,b.aetxt,b.AEGRU,b.CCART from {{everest_aeoi_table}} as a
left join {{everest_aenr_table}} as b
on a.AENNR=b.AENNR
where a.objkt in (
select distinct material from {{everest_material_table}}
))
union
(
select a.AENNR,a.matnr as matnr,b.AENST,b.datuv,b.andat,b.aedat,b.aetxt,b.AEGRU,b.CCART from
(
select aa.AENNR,bb.matnr from {{everest_stas_table}} aa
inner join
{{everest_mast_table}} bb
on aa.stlnr=bb.stlnr
where bb.matnr in (
select distinct material from {{everest_material_table}}
)) as a
left join {{everest_aenr_table}} as b
on a.AENNR=b.AENNR
 
)) as xx
left join {{everest_drad_table}} as yy
on xx.AENNR=yy.OBJKY
 
)
) a1
left join
(
 
select distinct '1' as BOM, AENNR from {{everest_stas_table}} where AENNR is not null and AENNR <> '' and len(AENNR)>3
union
select distinct '1' as BOM, AENNR from {{everest_stko_table}} where AENNR is not null and AENNR <> '' and len(AENNR)>3
union
select distinct '1' as BOM, AENNR from {{everest_stpo_table}} where AENNR is not null and AENNR <> '' and len(AENNR)>3
union
select distinct '1' as BOM, AENNR from {{tahiti_stas_table}} where AENNR is not null and AENNR <> '' and len(AENNR)>3
union
select distinct '1' as BOM, AENNR from {{tahiti_stko_table}} where AENNR is not null and AENNR <> '' and len(AENNR)>3
union
select distinct '1' as BOM, AENNR from {{tahiti_stpo_table}} where AENNR is not null and AENNR <> '' and len(AENNR)>3
) b1
on a1.AENNR=b1.AENNR
) as a2
left join
(select matnr,maktx from
{{everest_makt_table}}
union
select matnr,maktx from
{{tahiti_makt_table}}
)as c1
on a2.matnr=c1.matnr
where AENNR is not null and AENNR <> '' and len(AENNR)>3
),
material_table as (
select Material, BusinessUnit, Source from {{tahiti_material_table}}
union
select Material, BusinessUnit, Source from {{everest_material_table}}
)
select a.AENNR, a.matnr, a.AENST, a.datuv, a.andat, a.aedat, a.aetxt, a.AEGRU, a.CCART, a.DOKNR, a.DOKVR, a.DOKTL, a.DOKOB, a.BOM, a.MAKTX, b.BusinessUnit as business_unit, b.Source as source from ecro_sku__linkages a left join material_table b
on a.matnr = b.Material