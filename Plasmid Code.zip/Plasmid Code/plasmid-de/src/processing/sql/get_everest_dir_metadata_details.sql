with materials_for_dir_script as (
    select distinct Material from {{everest_material_table}}
),
sku_materials_dir_list as (
SELECT DISTINCT 
    DOKAR,
    DOKNR, 
    DOKVR,
    DOKTL from (
  select distinct DOKAR, DOKNR,DOKVR,DOKTL from (
  select distinct DOKAR, DOKNR,DOKVR,DOKTL from(
  select distinct DOKAR, DOKNR,DOKVR,DOKTL from {{everest_drad_table}} where OBJKY in (
        select distinct AENNR from {{everest_stko_table}} where STLNR in (
          select distinct STLNR from {{everest_mast_table}} where MATNR in(
            select distinct material from materials_for_dir_script
          )
        )
        union
        select distinct AENNR from {{everest_stpo_table}} where STLNR in (
          select distinct STLNR from {{everest_mast_table}} where MATNR in(
            select distinct material from materials_for_dir_script
          )
        )
        union
        select distinct AENNR from {{everest_aeoi_table}} where objkt in (
          select distinct material from materials_for_dir_script
          )
      )and len(OBJKY) > 1
    union
    select distinct DOKAR,DOKNR,DOKVR,DOKTL from {{everest_draw_table}} where AENNR in (
      select distinct AENNR from {{everest_stko_table}} where STLNR in (
        select distinct STLNR from {{everest_mast_table}} where MATNR in(
          select distinct material from materials_for_dir_script
        )
      )
      union
      select distinct AENNR from {{everest_stpo_table}} where STLNR in (
        select distinct STLNR from {{everest_mast_table}} where MATNR in(
          select distinct material from materials_for_dir_script
        )
      )
      union
      select distinct AENNR from {{everest_aeoi_table}} where objkt in (
        select distinct material from materials_for_dir_script
        )
    )and len(AENNR) > 1
)
union 
select distinct DOKAR, DOKNR,DOKVR,DOKTL from (
select distinct DOKAR, DOKNR,DOKVR,DOKTL FROM {{everest_drad_table}} where OBJKY in (
 select distinct material from materials_for_dir_script
)
)
)
)
),
dir_labor_list as (
  SELECT DISTINCT 
    DOKAR,
    DOKNR, 
    DOKVR,
    DOKTL from {{everest_draw_table}} 
where LABOR in (
    select LABOR 
    from {{everest_mara_table}} 
    where MATNR in (
        select distinct material from materials_for_dir_script
    ) 
    and LABOR in ('425')
)
),
final_dir_list as (
  select distinct DOKAR, DOKNR, DOKVR, DOKTL from (
  select * from sku_materials_dir_list 
  union all
  select * from dir_labor_list
)),
final_dir_list_with_date as (
    SELECT a.DOKAR, a.DOKNR, a.DOKVR, a.DOKTL, max(b.ADATUM) AS LastUpdatedAt
    FROM final_dir_list a
    LEFT JOIN {{everest_draw_table}} b
    ON  a.DOKAR = b.DOKAR
    AND a.DOKNR = b.DOKNR
    AND a.DOKVR = b.DOKVR
    AND a.DOKTL = b.DOKTL
    group by a.DOKAR, a.DOKNR, a.DOKVR, a.DOKTL
),
final_dir_list_with_status as (
  SELECT a.DOKAR, a.DOKNR, a.DOKVR, a.DOKTL, a.LastUpdatedAt, b.DOKST
    FROM final_dir_list_with_date a
    LEFT JOIN {{everest_draw_table}} b
    ON  a.DOKAR = b.DOKAR
    AND a.DOKNR = b.DOKNR
    AND a.DOKVR = b.DOKVR
    AND a.DOKTL = b.DOKTL
    AND a.LastUpdatedAt = b.ADATUM
),
final_dir_meta_desc as
(
SELECT a.DOKAR, a.DOKNR, a.DOKVR, a.DOKTL,a.LastUpdatedAt,a.DOKST, b.DKTXT
    FROM final_dir_list_with_status a
    LEFT JOIN {{everest_drat_table}} b
    ON  a.DOKAR = b.DOKAR
    AND a.DOKNR = b.DOKNR
    AND a.DOKVR = b.DOKVR
    AND a.DOKTL = b.DOKTL
    AND b.LANGU = 'E'
)
SELECT DOKAR as DocArea, DOKNR as DocNumber, DOKVR as DocVersion, DOKTL as DocPart, LastUpdatedAt, DOKST as Status, DKTXT as Description, 'Everest' as Source
FROM final_dir_meta_desc