from openai import AzureOpenAI
import re
import yaml
import mlflow

# import logging
from pyspark.sql import SparkSession
from pyspark.dbutils import DBUtils
from logs.logger import get_logger

logger = get_logger(__name__)
# Ensure spark object is available
spark = SparkSession.builder.getOrCreate()

# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)
### Query Standardization


def read_config(file_path="config.yml"):
    """Load configuration from a YAML file"""
    with open(file_path, "r") as file:
        config = yaml.safe_load(file)
    return config


config = read_config()
### Query Standardization
catalog = config["TARGET_CATALOG"]
schema = config["GOLD_SCHEMA"]
control_table_name = config["CONTROL_TABLE"]
components_table = config["TARGET_TABLE_COMPONENTS_FIRST_LEVEL"]
plants_table = config["TARGET_TABLE_NAME_PLANT"]
child_table = config["TARGET_TABLE_COMPONENTS_FIRST_LEVEL_CHILD_DESC"]
variations_table = config["TARGET_TABLE_NAME_VARIATIONS"]
dbutils = DBUtils(spark)
keyvault_scope = config["KEYVAULT_SCOPE"]
# open ai api details for embedding model
api_key = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-API-KEY")
azure_endpoint = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-ENDPOINT")
deployment_name_embedding = config["EMBEDDING_MODEL"]
api_version_embedding = str(config["EMBEDDING_VERSION"])
api_version = config["OPENAI_API_VERSION"]
deployment_name_llm = config["OPENAI_DEPLOYMENT_NAME"]

## initialize chat model
client_llm = AzureOpenAI(
    api_key=api_key, api_version=api_version, azure_endpoint=azure_endpoint
)

## initialize embedding model
client_embedding = AzureOpenAI(
    api_key=api_key, api_version=api_version_embedding, azure_endpoint=azure_endpoint
)


def create_embedding(input_text, client_embedding, deployment_name, dimensions=3072):
    response = client_embedding.embeddings.create(
        input=input_text, dimensions=dimensions, model=deployment_name
    )

    return response.data[0].embedding


def execute_query(sql_query):
    """Execute SQL query and return result as pandas DataFrame."""
    return spark.sql(sql_query).toPandas()  ## query and convert to pandas


def remove_leading_zeros(text):
    """Remove leading zeros from text."""
    return re.sub(r"\b00+(\d+)", r"\1", text)


def get_json_response(payload, client_llm, deployment_name):
    global total_input_tokens, total_output_tokens

    response = client_llm.chat.completions.create(
        messages=payload,
        temperature=0.1,
        top_p=0.1,
        response_format={"type": "json_object"},
        model=deployment_name,
    )
    response_content = response.choices[0].message.content

    return response_content


control_table = execute_query(f"SELECT * FROM {catalog}.{schema}.{control_table_name}")

logger.info("Loading model from mlflow")
model_name = "rfModel"
model_version = "latest"
mlflow.set_registry_uri("databricks")
model_uri = f"models:/{model_name}/{model_version}"
clf_saved = mlflow.sklearn.load_model(model_uri=model_uri)
logger.info("Model loaded successfully")


def predict_on_modified_query(query):
    # Step 1: Generate embeddings based on the modified query
    query_embed = create_embedding(
        input_text=query,
        client_embedding=client_embedding,
        deployment_name=deployment_name_embedding,
    )

    # Step 2: Perform classification
    y_pred = clf_saved.predict([query_embed])
    pred_prob_array = clf_saved.predict_proba([query_embed])
    y_pred_prob = pred_prob_array.max()
    y_pred_prob_index = pred_prob_array.argmax() + 1

    result = {
        "Key_Pred": int(y_pred[0]),
        "y_pred_prob": y_pred_prob,
        "y_pred_prob_index": y_pred_prob_index,
    }

    return result


def medium_confidence_prediction(question, predicted_query):
    """
    Handles medium‑confidence classifications by leveraging a conversational AI model.
    """
    unique_question_set = control_table[
        ["question", "question_description"]
    ].drop_duplicates()
    qs = list(unique_question_set["question"])
    qs_ds = list(unique_question_set["question_description"])

    question_type = ""
    for i in range(len(qs)):
        question_type += f"""

        Question type {i + 1}> {qs[i]}

        Question category explanation: {qs_ds[i]}

        """

    conversation = [
        {
            "role": "system",
            "content": f"""
            # Context:
            You are an expert in the field of medical devices. Your responses must be based purely on factual information and the details provided. Do not consider any external information.
 
            # Task:
            Another expert has suggested that the given question, '{question}', falls under the category '{predicted_query}'.
            Your task is to assess the accuracy of this classification.
 
            - If you **agree** with the classification, confirm it by assigning '{predicted_query}' as the **Question type**.
            - If you **disagree**, suggest a more appropriate category and repeat the evaluation process as instructed below.
 
            ## Classification Instructions:
            1. Classify the given question into one of the predefined categories or label it as 'Unknown'.
            2. A question should only be classified under a known category from one of the questions from {question_type} if **all** the steps required to answer it are fully covered by the category explanation.
            3. If answering the question requires any additional information or steps that are **not** included in the category explanation, classify it as 'Unknown'.
 
            ## Known Question Categories and Their Explanations:
            {question_type}
 
            # Output Format:
            Provide the output in the following JSON structure:
 
            {{
                "Raw_question": "<Question as provided by user without any change>",
                "Question type": "<Confirmed or revised question>"
            }}
            **Note** - Do not change the format of the output. In question type include only question and not the description of the question and question number.
            """,
        }
    ]
    conversation.append({"role": "user", "content": f"{question}"})
    response = get_json_response(
        payload=conversation, client_llm=client_llm, deployment_name=deployment_name_llm
    )
    return response


def low_confidence_prediction(query):
    """
    Handles low‑confidence classifications by leveraging a conversational AI model.
    """
    unique_question_set = control_table[
        ["question", "question_description"]
    ].drop_duplicates()
    qs = list(unique_question_set["question"])
    qs_ds = list(unique_question_set["question_description"])

    question_type = ""
    for i in range(len(qs)):
        question_type += f"""

        Question type {i + 1}> {qs[i]}

        Question category explanation: {qs_ds[i]}

        """

    conversation = [
        {
            "role": "system",
            "content": f"""
            # Context:
            You are an expert in the field of medical devices. You will always perform your tasks based on factual information and will only consider the details provided.
 
            # Task List:
            You are responsible for performing the following actions on any provided question:
 
            Task 1> Classify '{query}' into one of the known 'Question Types' or, label it as 'Unknown'.
 
            ## Classification Instructions:
            1. Classify the given question into one of the predefined categories or label it as 'Unknown'.
            2. A question should only be classified under a known category from one of the questions from {question_type} if **all** the steps required to answer it are fully covered by the category explanation.
            3. If answering the question requires any additional information or steps that are **not** included in the category explanation, classify it as 'Unknown'.
 
            ## Known Question Categories and Their Explanations:
            {question_type}
 
            # Output Format:
            Provide the output in the following JSON structure:
 
            {{
                "Raw_question": "<Question as provided by user without any change>",
                "Question type": "<Assign Predicted Question>"
            }}
            **Note** - Do not change the format of the output. In question type include only question and not the description of the question and question number.
            """,
        }
    ]
    conversation.append({"role": "user", "content": f"{query}"})

    response = get_json_response(
        payload=conversation, client_llm=client_llm, deployment_name=deployment_name_llm
    )
    return response


def query_matching(query):
    """Predict query type and determine the appropriate handling method."""
    try:
        logger.info("Starting query matching | Query: %s ", query)

        # Call predict_on_modified_query to get prediction results
        prediction_result = predict_on_modified_query(query)
        pred_prob = prediction_result["y_pred_prob"]
        pred_key = prediction_result["Key_Pred"]

        query_predicted = control_table.loc[
            control_table["number"].astype(int) == pred_key, "question"
        ].values[0]

        logger.info(
            "Query classified | Predicted Query: %s | Probability: %.2f",
            query_predicted,
            pred_prob,
        )

        if pred_prob > 0.8:
            logger.info("High confidence classification method selected")
            return {"Raw_question": query, "Question type": query_predicted}

        elif 0.5 < pred_prob <= 0.8:
            logger.info("Medium confidence detected, re-evaluating query")
            return medium_confidence_prediction(query, query_predicted)

        else:
            logger.info("Low confidence detected, switching to LLM‑based approach")
            return low_confidence_prediction(query)

    except Exception as e:
        logger.error(
            "Error in query_matching | Query: %s | Exception: %s",
            query,
            e,
            exc_info=True,
        )
        return {
            "Raw_question": query,
            "Question type": "Error",
            "error_message": str(e),
        }
