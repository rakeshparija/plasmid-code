import pandas as pd
from openai import AzureOpenAI
import re
import json
import yaml
from pyspark.sql import SparkSession
from collections import defaultdict, namedtuple
# import logging
from pyspark.dbutils import DBUtils
from logs.logger import get_logger
logger = get_logger(__name__)
spark = SparkSession.builder.getOrCreate()
# logger = logging.getLogger(__name__)

def read_config(file_path="config.yml"):
    """ Load configuration from a YAML file """
    with open(file_path, "r") as file:
        config = yaml.safe_load(file)
    return config

config = read_config()
### Query Standardization
catalog = config["TARGET_CATALOG"]
schema = config["GOLD_SCHEMA"]
control_table_name = config["CONTROL_TABLE"]
components_table = config["TARGET_TABLE_COMPONENTS_FIRST_LEVEL"]
plants_table = config["TARGET_TABLE_NAME_PLANT"]
child_table = config["TARGET_TABLE_COMPONENTS_FIRST_LEVEL_CHILD_DESC"]
variations_table = config["TARGET_TABLE_NAME_VARIATIONS"]
dbutils = DBUtils(spark)
keyvault_scope = config['KEYVAULT_SCOPE']
#open ai api details for embedding model
api_key = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-API-KEY")
azure_endpoint = dbutils.secrets.get(scope=keyvault_scope, key="OPENAI-ENDPOINT")
deployment_name_embedding = config['EMBEDDING_MODEL']
api_version_embedding = str(config['EMBEDDING_VERSION'])
api_version = config['OPENAI_API_VERSION']
deployment_name = config['OPENAI_DEPLOYMENT_NAME']

## initialize chat model
client = AzureOpenAI(
  api_key = api_key,  
  api_version = api_version,
  azure_endpoint = azure_endpoint
)

## initialize embedding model
client_embeddings = AzureOpenAI(
  api_key = api_key,  
  api_version = api_version_embedding,
  azure_endpoint = azure_endpoint
)

def create_embedding(child_description):
    response = client_embeddings.embeddings.create(
    input = child_description,
    model= deployment_name_embedding,
    dimensions=3072 ## mongo supports max 2000, remove this later
    )
    return response.data[0].embedding

def execute_query(sql_query):
    """Execute SQL query and return result as pandas DataFrame."""
    return spark.sql(sql_query).toPandas() ## query and convert to pandas

def remove_leading_zeros(text):
    """Remove leading zeros from text."""
    return re.sub(r'\b00+(\d+)', r'\1', text)

def get_json_response(payload, client_llm, deployment_name):
    global total_input_tokens, total_output_tokens

    response = client_llm.chat.completions.create(
        messages=payload,
        temperature=0.1,
        top_p=0.1,
        response_format={"type": "json_object"},
        model=deployment_name
    )
    response_content = response.choices[0].message.content

    return response_content

control_table = execute_query(f"SELECT * FROM {catalog}.{schema}.{control_table_name}")

class TrieNode:
  '''A class representing a node in a Trie data structure'''
  def __init__(self):
      self.children = {}
      self.is_end = False
      self.document_names = set()
      self.token_count = 0

class LinkageFinder:
  '''A class for finding linkages between tokens and queries using a Trie data structure'''

  def __init__(self, document_names, min_scoring_length=3, ignore_tokens=set(), filter_char_count=0):
      '''Initialize the LinkageFinder with the given parameters'''

      self.SearchResult = namedtuple('SearchResult', ['matched_substring', 'matched_item', 'score'])
      self.min_scoring_length = min_scoring_length
      self.ignore_tokens = ignore_tokens
      self.filter_char_count = filter_char_count
      self.root = TrieNode()
      self.document_tokens = {}  # Cache for document tokens
      self.document_scoring_tokens = {}  # Cache for document tokens used in scoring
      self.token_to_docs = defaultdict(set)  # Inverse index
      # Cache for variations to avoid redundant calculations
      self.variation_cache = {}
      self.initialize_trie(document_names)

  def tokenize(self, text):
      '''Tokenize the given text into a list of tokens'''
      return text.lower().split()

  def filter_tokens(self, tokens):
      '''Filter the given tokens based on length and ignore list'''
      return [t for t in tokens if
              (len(t) >= self.min_scoring_length) or (t.isnumeric()) and (t not in self.ignore_tokens)]

  def initialize_trie(self, document_names):
      """Initialize the Trie with the given document names"""

      logger.info("Initializing Trie with document names")

      try:
          for doc_name in document_names:

              all_tokens = self.tokenize(doc_name)

              # Store all tokens for reference
              self.document_tokens[doc_name] = all_tokens

              # Filter tokens for matching and scoring
              filtered_tokens = self.filter_tokens(all_tokens)
              self.document_scoring_tokens[doc_name] = filtered_tokens

              if not filtered_tokens:
                  logger.warning("No filtered tokens found for document: %s", doc_name)
                  continue

              # Build token-to-document inverse index
              for token in filtered_tokens:
                  self.token_to_docs[token].add(doc_name)

              # Insert all possible token subsequences into Trie
              for start_idx in range(len(filtered_tokens)):
                  current = self.root
                  for i, token in enumerate(filtered_tokens[start_idx:]):
                      if token not in current.children:
                          current.children[token] = TrieNode()

                      current = current.children[token]
                      current.document_names.add(doc_name)
                      current.token_count = i + 1

          logger.info("Trie initialization completed successfully")

      except Exception as e:
          logger.error("Error occurred while initializing Trie: %s", e, exc_info=True)

  def generate_variations(self, token, min_fuzzy_length=4, max_edits=1):
      """Generate variations of the given token for fuzzy matching."""

      cache_key = (token, min_fuzzy_length, max_edits)

      try:
          logger.info("Processing token variations")
          # Return cached variations if available
          if cache_key in self.variation_cache:
              # logger.info("Using cached variations for token: %s", token)
              return self.variation_cache[cache_key]

          if len(token) <= min_fuzzy_length or max_edits == 0:
              # logger.warning("Token %s does not meet fuzzy length criteria or max edits is 0", token)
              self.variation_cache[cache_key] = {token}
              return {token}

          variations = {token}

          # Single character substitutions
          for i in range(len(token)):
              for c in 'abcdefghijklmnopqrstuvwxyz0123456789':
                  if c != token[i]:
                      variations.add(token[:i] + c + token[i + 1:])

          # Single character deletions if resulting token still meets length requirement
          if len(token) > min_fuzzy_length:
              for i in range(len(token)):
                  new_token = token[:i] + token[i + 1:]
                  if len(new_token) >= min_fuzzy_length:
                      variations.add(new_token)

          # Store in cache
          self.variation_cache[cache_key] = variations
          logger.info("Successfully generated variations for token: %s | Total variations: %d", token,
                      len(variations))

          return variations

      except Exception as e:
          logger.error("Error generating variations for token: %s | Exception: %s", token, e, exc_info=True)
          return {token}  # Return the original token as a fallback

  def find_matches_in_window(self, tokens, start_idx,
                              min_fuzzy_length=4,
                              max_edits=1,
                              match_threshold=0.4):
      """Find matches in a window of tokens starting from the given index."""

      try:
          # logger.info("Starting match search | Start index: %d | Token count: %d", start_idx, len(tokens))

          all_matches = []
          current = self.root
          matched_tokens = []

          for i in range(start_idx, len(tokens)):
              token = tokens[i]
              found_match = False

              # Try exact match first (faster path)
              if token in current.children:
                  # logger.info("Exact match found | Token: %s", token)
                  current = current.children[token]
                  matched_tokens.append(token)
                  found_match = True

              # Only attempt fuzzy matching for tokens longer than min_fuzzy_length
              elif len(token) > min_fuzzy_length:
                  # logger.info("Attempting fuzzy match | Token: %s", token)
                  variations = self.generate_variations(token, min_fuzzy_length, max_edits)
                  for variant in variations:
                      if variant in current.children:
                          # logger.info("Fuzzy match found | Token: %s | Variant: %s", token, variant)
                          current = current.children[variant]
                          matched_tokens.append(token)
                          found_match = True
                          break

              if not found_match:
                  # logger.info("No match found | Token: %s | Breaking loop", token)
                  break

              if current.document_names:
                  matched_substring = ' '.join(matched_tokens)

                  for doc_name in current.document_names:
                      doc_scoring_tokens = self.document_scoring_tokens.get(doc_name, [])

                      # Calculate score based on matched tokens compared to document tokens
                      if doc_scoring_tokens:
                          score = len(matched_tokens) / len(doc_scoring_tokens)

                          # Only include if it meets threshold and filter_char_count condition
                          if score >= match_threshold and any(
                                  len(token) >= self.filter_char_count for token in matched_tokens):
                              logger.info("Match found | Document: %s | Substring: %s | Score: %.2f", doc_name,
                                          matched_substring, score)
                              all_matches.append((matched_substring, doc_name, score))
                      else:
                          logger.warning("Edge case match found | Document: %s | Substring: %s", doc_name,
                                          matched_substring)
                          all_matches.append((matched_substring, doc_name, 1.0))

          # logger.info("Completed match search | Total matches found: %d", len(all_matches))
          return all_matches

      except Exception as e:
          logger.error("Error in find_matches_in_window | Exception: %s", e, exc_info=True)
          return []

  def search_corpus(self, corpus,
                    min_fuzzy_length=4,
                    max_edits=1,
                    match_threshold=0.4):
      '''Search the given corpus for matches using the initialized Trie'''
      all_tokens = self.tokenize(corpus)

      # Filter tokens for matching and scoring
      tokens = self.filter_tokens(all_tokens)

      if not tokens:
          return []

      all_matches = []
      matched_docs = set()  # Track matches to avoid duplicates

      for i in range(len(tokens)):
          window_matches = self.find_matches_in_window(
              tokens, i,
              min_fuzzy_length,
              max_edits,
              match_threshold
          )

          for matched_substring, doc_name, score in window_matches:
              match_key = (doc_name, matched_substring)
              if match_key not in matched_docs:
                  all_matches.append(self.SearchResult(
                      matched_substring=matched_substring,
                      matched_item=doc_name,
                      score=score
                  ))
                  matched_docs.add(match_key)

      return sorted(all_matches, key=lambda x: x.score, reverse=True)

def replace_special_characters_with_nospace(id):
  """Replace special characters with no space."""
  return (' '.join(''.join(e if e.isalnum() or e.isspace() else '' for e in id).split())).lower().strip()

def replace_special_characters_with_space(id):
  """Replace special characters with space."""
  return (' '.join(''.join(e if e.isalnum() or e.isspace() else ' ' for e in id).split())).lower().strip()

def linkage_search(query):
    """Perform a linkage search on the given query."""

    try:
        logger.info("Starting linkage search | Query: %s", query)

        # Read variations from the variations table

        df = execute_query(f"""SELECT * FROM {catalog}.{schema}.{variations_table} LIMIT 1""")
        loaded_variations = df.iloc[0].to_dict()

        if not loaded_variations:
            logger.warning("No variations found in variations table")
            return {}

        all_variations_item_ids = loaded_variations['item_ids']
        all_variations_plant_ids = loaded_variations['plant_ids']
        all_variations_item_names = loaded_variations['item_names']
        all_variations_plant_names = loaded_variations['plant_names']
        all_variations_dir_ids  = loaded_variations['dir_ids']
        logger.info("Variations successfully loaded from variations table")

        # Create linkage finders
        linkage_finders = {
            'item_id': LinkageFinder(all_variations_item_ids, 2, set(), 3),
            'item_name': LinkageFinder(all_variations_item_names, 2, set(), 4),
            'plant_id': LinkageFinder(all_variations_plant_ids, 2, set(), 3),
            'plant_name': LinkageFinder(all_variations_plant_names, 2, set(), 4),
            'dir_id': LinkageFinder(all_variations_dir_ids, 2, set(), 3)
        }

        logger.info("Linkage finders initialized.")

        # Preprocess the query
        search_corpus = query.lower()
        search_corpus += ' ' + replace_special_characters_with_space(query)
        search_corpus += ' ' + replace_special_characters_with_nospace(query)

        logger.info("Query preprocessed successfully.")

        # Perform the linkage search
        search_results = {
            'item_id': linkage_finders['item_id'].search_corpus(search_corpus, max_edits=0, min_fuzzy_length=4,
                                                                match_threshold=1),
            'item_name': linkage_finders['item_name'].search_corpus(search_corpus, max_edits=0, min_fuzzy_length=4,
                                                                    match_threshold=0.8),
            'plant_id': linkage_finders['plant_id'].search_corpus(search_corpus, max_edits=0, min_fuzzy_length=4,
                                                                    match_threshold=1),
            'plant_name': linkage_finders['plant_name'].search_corpus(search_corpus, max_edits=0,
                                                                        min_fuzzy_length=4, match_threshold=0.8),
            'dir_id': linkage_finders['dir_id'].search_corpus(search_corpus, max_edits=0, min_fuzzy_length=4, 
                                                                match_threshold=1)
        }

        logger.info("Linkage search completed.")

        # Process matches
        matches = {
            'item_id': {x.matched_item for x in search_results['item_id']},
            'item_name_full': {x.matched_item for x in search_results['item_name'] if x.score > 0.8},
            'plant_id': {x.matched_item for x in search_results['plant_id']},
            'plant_name_full': {x.matched_item for x in search_results['plant_name'] if x.score > 0.9},
            'dir_id': {x.matched_item for x in search_results['dir_id']}
        }

        logger.info("Successfully processed matches | Total matches found: %s",
                    {k: len(v) for k, v in matches.items()})
        return matches

    except Exception as e:
        logger.error("Error occurred in linkage search | Query: %s | Exception: %s", query, e, exc_info=True)
        return {}

def sku_plant_dir_entity_extraction(query):
    """Function to extract entities related to SKU and Plant from the query using traditional methods."""

    try:
        logger.info("Starting SKU & Plant entity extraction | Query: %s", query)

        # Perform the linkage search
        matches = linkage_search(query)
        # Create verified material lists
        verified_material_list_item = list(matches['item_id'].union(matches['item_name_full']))
        verified_material_list_plant = list(matches['plant_id'].union(matches['plant_name_full']))
        verified_material_list_dir = list(matches['dir_id'])

        # Create output dictionary
        output_dict = {
            "SKU_component_list": verified_material_list_item,
            "manufacturing_site": verified_material_list_plant,
            "dir_list": verified_material_list_dir}

        logger.info("Entity extraction completed successfully | SKU Matches: %d | Plant Matches: %d | Dir Matches: %d",
                        len(verified_material_list_item), len(verified_material_list_plant), len(verified_material_list_dir))

        return output_dict

    except Exception as e:
        logger.error("Error occurred in SKU, Plant and Dir entity extraction | Query: %s | Exception: %s", query, e,
                         exc_info=True)
        return {"SKU_component_list": [], "manufacturing_site": [], "dir_list": []}

def entity_extraction_llm(question):
    """
    Extracts various entities from a given question using a language model.

    Args:
        question (str): The input question from which entities need to be extracted.

    Returns:
        dict: A dictionary containing the extracted entities in the following format:
            {
                'Raw_question': str,  # Original question as provided by the user
                'Modified_question': str,  # Modified question with specific terms replaced by generic placeholders
                'SKU_component_list': list,  # List of SKUs or components mentioned in the question
                'SKU_component_query': str,  # SQL query to extract SKU/product/component list if criteria is given, else "N/A"
                'Date_filter': str,  # Date filtration as mentioned in the user query or "N/A"
                'manufacturing_site': list,  # List of manufacturing sites/plants mentioned in the question or []
                'change_flag': str,  # "True" if the question is about changes/updates, else "False"
                'product_feature_list': list  # List of product features/component features mentioned in the question or []
            }
    """
    unique_question_set = control_table[['question', 'question_description']].drop_duplicates()
    qs = list(unique_question_set['question'])
    qs_ds = list(unique_question_set["question_description"])
    question_type = """"""
    for i in range(len(qs)):
        question_type = question_type + """

        Question type """ + str(i + 1) + """> """ + str(qs[i]) + """

        Question category explanation: """ + str(qs_ds[i]) + """

        """

    conversation = [
        {"role": "system", "content": f"""
        # Context : you are an expert in the field of medical devices.You will always perform your tasks based on fact and not consider any external information apart from the ones provided.

        # Task list:
        You are responsible to perform following actions on any provided question: 

        Task 1> If one or more SKU / Component  names or alphanumeric/numeric IDs , possibly separated by comma are provided, extract a python list data structure of them otherwise return a blank list . SKUs can be referred to as SKU / product / finished goods / product name / medical device name . Components can be referred to as components / materials / constituents / raisins / compositions / raw materials. Don't extract any number or alphanumeric names when it talks about packaging material changed or any changes related instead assign it under 'product_feature_list'.

        Task 2> If SKU keyword or keywords are mentioned comma seperated :
        - Create a SQL query that can be used to match mentioned keyword or keywords against  against 'parent_id' field or 'parent_description' field in '{schema}.{components_table}' table to shortlist the list of relevant SKUs / Products / Components
        - Query should be written in a way such that it compares criteria keywords in both upper and lowercase after removing preceding and trailing spaces
        - In a question both SKU IDs / SKU names / Product names and the criteria can be mentioned. In those cases create the SQL query using only the mentioned criteria while ignoring the SKU IDs/material IDs/ Product names given
        - If no criteria is mentioned and instead only a list of SKU / product / component is given then return 'N/A'.
        - **Do not confuse Plant Names or Product Feature with SKU keywords**
        - If there multiple distinct keywords (comma seperated, not space seperated), the sql query should return SKUs that contains all of these keywords.

        Task 3> Extract time related filter mentioned within the question, but only when they are not referring to any kind of changes, updates or modifications. The time related filter should get converted into a a easy to parse format. For example 'between 2020 and 2021' should be converted to '#Date1: 2020-01-01 ,#Date2: 2021-12-31', 'before 2022' should be converted to '#Date1: 1900-01-01 , #Date2: 2021-12-31', 'after 2022' should be converted to '#Date1: 2023-01-01 ,#Date2: 2200-01-01"' If no valid date criteria is mentioned or it relates to changes return 'N/A'

        Task 4> Extract any manufacturing site / plant / production plant / factory / assembly line related criteria and convert it into a list of keywords. For example if query is asking for 'prducts manufactured in tijuana and plant code 7708' the provide ['tijuana','7708'] as output. If no manufacturing site / plant is mentioned return [].

        Task 5> Extract a flag that will be set to 'True' when you think the question is about any change / change requests / updates / upgrades to any SKU / products / components / materials else will be set to 'False'

        Task 6> Extract the value along with unit from the question when you think the question is about any change / change requests / updates / upgrades to any SKU / products / components / materials else will be set to []. For example if query is asking 'change in past 5 years' , 'updates happend in last 20 months' then provide ['5 years'] or ['20 months'] as output respectively. 

        Task 7> Extract a python list datastructure containing list of all product features / component features / component names / features / materials/ packaging material changed/ any change material feature or keyword mentioned in the question. Product features will typically be entered by user in a comma separated way. If the user mentions 'Spike , Leuer Lock and stop cock' the product feature list should be ['Spike','Leuer Lock','stop cock' ] or user mentions 'rp142 material changed' the profuct feature list should be ['rp142']. Return [] if no product features or no any changes related materials are mentioned.

        Task 8> If one or more DIR / Documents IDs/Names in alphanumeric/numeric type, possibly separated by comma are provided, extract a python list data structure of them otherwise return a blank list . DIR can be referred to as DIR / document / document name / document ID / document number.

        ## Known question category and their repective explanations:
        """ + question_type + """

        # Format instruction:
        Output should be in the following JSON Format
        {'Raw_question' : Question as provided by user without any change,
        "SKU_component_list": list data structure with of components or materials that are mentioned explicitly in the question else [],
        "SKU_component_query": The SQL query to extract SKU / product / component list if a criteria is given or "N/A",
        "Date_filter" : Date filtration as mentioned in user query or "N/A",
        "manufacturing_site": manufacturing site filter as mentioned in user query or return [],
        "change_flag": "True" if the question is about any change / change requests / updates / upgrades to any SKU / products / components / materials else will be set to "False",
        change_value": list of value along with unit from the question when you think the question is about any change / change requests / updates / upgrades to any SKU / products / components / materials else will be set to [],
        "product_feature_list": list of all product features / component features / component names / features / materials mentioned in the question. Product features will typically be entered by user in a comma separated way. If no product features are mentioned then return [],
        "dir_list": list data structure with of DIR/ Documents that are mentioned explicitly in the question else []
        }
                """},
        {"role": "user", "content": f"{question}"}
    ]
    response = get_json_response(payload=conversation, client_llm = client, deployment_name = deployment_name)
    return response

def extract_all_entities(query_dict):
    results = {}
    for key, questions in query_dict.items():
        if isinstance(questions, str):
            questions = [questions]
        key_results = []
        for question in questions:
            output_dict = sku_plant_dir_entity_extraction(question)
            sku_trad = output_dict['SKU_component_list']
            plant_trad = output_dict['manufacturing_site']
            dir_trad = output_dict['dir_list']
            entity_llm = json.loads(entity_extraction_llm(question))
            sku_llm = entity_llm['SKU_component_list']
            plant_llm = entity_llm['manufacturing_site']
            dir_llm = entity_llm['dir_list']
            # Normalize for comparison: lowercase + strip
            sku_llm_norm = {s.lower().strip() for s in sku_llm}
            sku_combined = sku_llm.copy()
            for s in sku_trad:
                if s.lower().strip() not in sku_llm_norm:
                    sku_combined.append(s)
            entity_llm['SKU_component_list'] = sku_combined
            # Same for plant
            plant_llm_norm = {p.lower().strip() for p in plant_llm}
            plant_combined = plant_llm.copy()
            for p in plant_trad:
                if p.lower().strip() not in plant_llm_norm:
                    plant_combined.append(p)
            entity_llm['manufacturing_site'] = plant_combined
            #same for dir
            dir_llm_norm = {d.lower().strip() for d in dir_llm}
            dir_combined = dir_llm.copy()
            for d in dir_trad:
                if d.lower().strip() not in dir_llm_norm:
                    dir_combined.append(d)
            entity_llm['dir_list'] = dir_combined
            # Define the mapping
            entity_mapping = {
                'manufacturing_site': 'plant id',
                'SKU_component_list': 'material id',
                'Date_filter': 'date',
                'product_feature_list': 'feature',
                'SKU_component_query' : 'material id',
                'dir_list' : 'dir id'
            }

            modified_question = question
            for entity_key, replacement_text in entity_mapping.items():
                if entity_llm.get(entity_key):
                    values = entity_llm[entity_key]
                    if not isinstance(values, list):
                        values = [values]
                    for val in values:
                        if isinstance(val, str):
                            like_pattern = re.findall(r"LIKE\s*'%([^%]+)%'", val, re.IGNORECASE)
                            if like_pattern:
                                for keyword in like_pattern:
                                    if keyword in modified_question:
                                        modified_question = modified_question.replace(keyword, replacement_text)
                            else:
                                modified_question = modified_question.replace(str(val), replacement_text)
            entity_llm['Modified_question'] = modified_question
            key_results.append(entity_llm)
        if len(key_results) == 1:
            results[key] = key_results[0]
        else:
            results[key] = key_results
    return results

### Query Augmentation Pipeline

def query_aug(question):
  
  conversation = [
      {"role": "system", "content": f"""
      Context:
          You are an expert in the field of medical devices. Your responses must be based **strictly** on the input data and explicit information provided. Do not incorporate any external information, knowledge, assumptions or inferred meaning beyond the given content.

      Task:
          Your task is to generate diverse, accurate variations of the provided question, using the six distinct approaches described below - 
          ---Generate 10 distinct variations per approach, resulting in a total of 60 variations.
          ---Ensure **no duplicate** variations is generated across or within the approaches.
          ---Do not alter any text present inside square brackets [].
          ---Every variations must preserve the original factual intent abd meaning of the question.
          ---Do not add any additional context or information not present in the input.

      Approach:
          1. Spelling/Grammar Errors, Acronyms, Synonyms:
              Introduce minor spelling or grammatical mistakes, use commonly known acronyms, and/or substitute non-critical words with appropriate synonyms, without affecting factual accuracy or clarity.
          2. Elaborate Versions:
              Expand the question with additional descriptive words or clarifying phrases, but do not introduce any new concepts or assumptions. Focus on keeping the original meaning intact while making the question more verbose.
          3. Paraphrasing:
              Rewrite the question using different sentence structures and phrasing while maintaining a neutral, formal tone and ensuring the original meaning remains unchanged.
          4. Question Shortening:
              Create concise versions of the question by removing filler words or simplifying the sentence structure while retaining its full intent.
          5. Tone Adjustment:
              Rewrite the question using different tones (e.g., formal, semi-formal, friendly, or casual), while ensuring the technical correctness and intent remain consistent.
          6. Combinations of all the above:
              Create variations by mixing techniques from the above categories—e.g., applying a synonym and shortening, or changing tone and paraphrasing. Each variation should still be clear, factual, and unique

      Output Format:
          Provide your output in the following structured format. Do not include approach headers and strictly do not leave a blank line between and after entries. Generate all 60 variations every time.
          Example:
          1.)...
          2.)...so on
          9.)...
          10.)...
          11.)...so on
          12.)...
          13.)...so on
          59.)...
          60.)... 

      """}
  ]
  conversation.append({"role": "user", "content": f"{question}"})

  response = client.chat.completions.create(
      model=deployment_name,
      messages=conversation,
      temperature=0.0,
  )

  return response.choices[0].message.content

def generate_augmented_queries(query):
    # Generate augmented queries for each key in the query dictionary
    outputs = [(key, query_aug(q)) for key in query for q in query[key]]

    columns = ['Key', 'Query_No', 'Queries']
    all_dfs = []
    query_no_counter = 1

    for key, output in outputs:
        query = output.split('\n')  # Split the output into individual queries
        query_no = list(range(query_no_counter, query_no_counter + len(query)))  # Generate query numbers
        query_no_counter += len(query)  # Update the query number counter
        query = [re.sub(r'^\d+\.\s*|\)', '', q) for q in query]  # Remove numbers and closing brackets from the beginning of each query
        df = pd.DataFrame(list(zip([key]*len(query), query_no, query)), columns=columns)  # Create a DataFrame for the current set of queries
        all_dfs.append(df)  # Append the DataFrame to the list

    # Concatenate all DataFrames into a single DataFrame
    final_df = pd.concat(all_dfs, ignore_index=True)
    final_df = final_df.dropna()  # Drop any rows with NaN values
    final_df = final_df.drop_duplicates(subset=['Queries'])  # Drop duplicate queries

    # Rearrange Query_No accordingly
    final_df['Query_No'] = range(1, len(final_df) + 1)

    return final_df