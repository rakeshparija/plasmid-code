from io import BytesIO
from PyPDF2 import PdfReader
from logs.logger import get_logger
import pdfplumber
from pyspark.dbutils import DBUtils
from pyspark.sql.functions import lit, current_timestamp, col, when, ceil
from azure.storage.blob import BlobServiceClient
logger = get_logger()

def process_page_count(spark, config):
    
    catalog = config['TARGET_CATALOG']
    schema = config['SILVER_SCHEMA']
    unstructured_schema = config['UNSTRUCTURED_SCHEMA_EVEREST']
    output_table = config['TARGET_TABLE_NAME_PAGE_COUNT_DETAILS']
    dbutils = DBUtils(spark)
    env = config['ENV']
    rows = []
    source = 'everest'
    if env == 'sbx':
        keyvault_scope = config['KEYVAULT_SCOPE']
        storage_name = dbutils.secrets.get(scope=keyvault_scope, key = 'BLOB-STORAGE-ACCOUNT-NAME')
        account_key = dbutils.secrets.get(scope=keyvault_scope, key='BLOB-STORAGE-ACCESS-KEY')
        BLOB_CONNECTION_STRING = f"DefaultEndpointsProtocol=https;AccountName={storage_name};AccountKey={account_key};EndpointSuffix=core.windows.net"
        blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
        pdf_container = blob_service_client.get_container_client(config['UNSTRUCTURED_CONTAINER'])
        prefix = f"{source}/pdf_files/raw/"
        blob_list = pdf_container.list_blobs(name_starts_with=prefix)
        files = [blob.name for blob in blob_list]
    else:
        # Read from mounted volume in Databricks
        volume_path = f'/Volumes/{catalog}/{unstructured_schema}/{source}/pdf_files/raw/'
        files = dbutils.fs.ls(volume_path)
    if len(files)==0:
        logger.info("No documents for ocr")
        return
    
    for file in files:
        
        if env == 'sbx':
            blob = pdf_container.get_blob_client(file)
            # grab just the filename
            name = blob.blob_name.rsplit("/", 1)[-1]
            # skip non-PDFs by extension
            if not name.lower().endswith(".pdf", ".xls", ".xlsx", ".xlsm")):
                skipped_path = blob.blob_name.replace("/raw/", "/skipped/")
                dest_client = pdf_container.get_blob_client(skipped_path)
                dest_client.start_copy_from_url(blob.url)
                blob.delete_blob()
                continue
            
            if name.lower().endswith(".pdf"):
                
                # compute size in MB
                size_mb = round(blob.get_blob_properties().size / (1024 * 1024), 2)
                
                # try to open & count pages, skip on any error
                try:
                    data = blob.download_blob().readall()
                    reader = PdfReader(BytesIO(data))
                    num_pages = len(reader.pages)
                except Exception as e:
                    try:
                        # blob_client = container_client.get_blob_client(blob.name)
                        # content = blob.download_blob().readall()
                        with pdfplumber.open(BytesIO(data)) as pdf:
                            num_pages = len(pdf.pages)
                    except Exception as e:
                        num_pages = None
                        fail_path = f'{source}/pdf_files/failed/page_count/{name}'
                        pdf_container.upload_blob(name=fail_path, data=data, overwrite=True)
                        blob.delete_blob()
                        logger.info(f"Skipping {name}: not a valid PDF ({e})")
                        continue
                
                rows.append((name, size_mb, num_pages))
        
        else:
            
            name = file.name
            raw_path = file.path.replace("dbfs:", "")
            
            # Skip unsupported formats
            if not name.lower().endswith((".pdf", ".xls", ".xlsx", ".xlsm")):
                skipped_path = raw_path.replace("/raw/", "/skipped/")
                dbutils.fs.cp(raw_path, skipped_path)
                dbutils.fs.rm(raw_path)
                logger.info(f"Moved unsupported file to: {skipped_path}")
                continue
            
            if name.lower().endswith(".pdf"):
                
                size_mb = round(file.size / (1024 * 1024), 2)
                
                try:
                    with open(raw_path, "rb") as f:
                        reader = PdfReader(f)
                        num_pages = len(reader.pages)
                except Exception:
                    try:
                        with open(raw_path, "rb") as f:
                            with pdfplumber.open(f) as pdf:
                                num_pages = len(pdf.pages)
                    except Exception as e:
                        num_pages = None
                        fail_path = file.path.replace("/raw/", "/failed/page_count/")
                        dbutils.fs.cp(file.path, fail_path)
                        dbutils.fs.rm(file.path)
                        logger.info(f"Moved failed file to: {fail_path}")
                        continue
                
                rows.append((name, size_mb, num_pages))
    
    # build and display the DataFrame
    df = spark.createDataFrame(rows, ["filename", "file_size_mb", "num_pages"])
    df = df.withColumn("source", lit("Everest"))
    df = df.withColumn("LastUpdatedAt", current_timestamp())
    df = df.withColumn("IsClassification", lit("no"))
    df = df.withColumnRenamed("filename", "PdfFile")
    df = df.withColumnRenamed("num_pages", "PageCount")
    df = df.withColumnRenamed("file_size_mb", "FileSizeMb")
    df = df.withColumn("BusinessUnit",lit("plastipak"))
    df = df.withColumn(
        "NoOfSplits",
        when(col("PageCount") < 51, 0).otherwise(ceil((col("PageCount") / 10)).cast("int") )
    )
    
    # display(df.limit(5))
    from delta.tables import DeltaTable
    
    # target_table_path = f"/path/to/{catalog}/{schema}/{output_table}"  # Use actual path if needed
    try:
        delta_table = DeltaTable.forName(spark, f"{catalog}.{schema}.{output_table}")
        
        delta_table.alias("target").merge(
            df.alias("source"),
            "target.PdfFile = source.PdfFile"
        ).whenNotMatchedInsertAll().execute()
    except Exception as e:
        df.write.mode("append").option("mergeSchema", "true").saveAsTable(f"{catalog}.{schema}.{output_table}")
    
    logger.info("Completed evaluating Page count for available documents")