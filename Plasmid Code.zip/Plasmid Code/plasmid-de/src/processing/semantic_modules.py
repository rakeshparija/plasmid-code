from typing import List, Optional
from langchain_experimental.text_splitter import SemanticChunker
from langchain_openai.embeddings import AzureOpenAIEmbeddings
import re

class CustomSemanticChunker(SemanticChunker):
    def __init__(
        self,
        embeddings: AzureOpenAIEmbeddings,
        buffer_size: int = 1,
        add_start_index: bool = False,
        breakpoint_threshold_type: str = "percentile",
        breakpoint_threshold_amount: Optional[float] = None,
        number_of_chunks: Optional[int] = None,
        sentence_split_regex: str = r"(?<=[.?!])\s+",
        max_tokens: Optional[int] = None,  # Add max_tokens parameter
    ):
        super().__init__(
            embeddings,
            buffer_size,
            add_start_index,
            breakpoint_threshold_type,
            breakpoint_threshold_amount,
            number_of_chunks,
            sentence_split_regex,
        )
        self.max_tokens = max_tokens  # Initialize max_tokens

    def split_text(
        self,
        text: str,
    ) -> List[str]:
        # Splitting the text into sentences based on the specified regex
        single_sentences_list = re.split(self.sentence_split_regex, text)

        # If there's only one sentence, return it as the only chunk
        if len(single_sentences_list) == 1:
            return single_sentences_list
        # If there are only two sentences and using gradient, return them as chunks
        if (
            self.breakpoint_threshold_type == "gradient"
            and len(single_sentences_list) == 2
        ):
            return single_sentences_list

        # Calculate distances between sentences using embeddings
        distances, sentences = self._calculate_sentence_distances(single_sentences_list)

        # Determine the breakpoint threshold for chunking
        if self.number_of_chunks is not None:
            breakpoint_distance_threshold = self._threshold_from_clusters(distances)
            breakpoint_array = distances
        else:
            (
                breakpoint_distance_threshold,
                breakpoint_array,
            ) = self._calculate_breakpoint_threshold(distances)

        # Identify indices where the distance exceeds the threshold
        indices_above_thresh = [
            i
            for i, x in enumerate(breakpoint_array)
            if x > breakpoint_distance_threshold
        ]

        chunks = []
        start_index = 0

        # Iterate through the breakpoints to slice the sentences into chunks
        for index in indices_above_thresh:
            end_index = index
            group = sentences[start_index : end_index + 1]
            combined_text = " ".join([d["sentence"] for d in group])

            # Merge small chunks if specified
            if (
                self.min_chunk_size is not None
                and len(combined_text) < self.min_chunk_size
            ):
                continue

            # Truncate the chunk if it exceeds max_tokens
            if self.max_tokens is not None:
                tokens = combined_text.split()
                if len(tokens) > self.max_tokens:
                    combined_text = " ".join(tokens[:self.max_tokens])
            
            chunks.append(combined_text)
            start_index = index + 1

        # Handle the last group of sentences
        if start_index < len(sentences):
            combined_text = " ".join([d["sentence"] for d in sentences[start_index:]])
            if self.max_tokens is not None:
                tokens = combined_text.split()
                if len(tokens) > self.max_tokens:
                    combined_text = " ".join(tokens[:self.max_tokens])
            chunks.append(combined_text)
        return chunks


