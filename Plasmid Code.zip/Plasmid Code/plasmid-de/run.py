import argparse
import importlib
import sys
import yaml
from pyspark.sql import SparkSession
from logs.logger import get_logger

logger = get_logger()

def read_config(file_path="config.yml"):
    """ Load configuration from a YAML file """
    with open(file_path, "r") as file:
        config = yaml.safe_load(file)
    return config


def main():
    arg_parser = argparse.ArgumentParser(description="Main arguments")
    arg_parser.add_argument(
        "function",
        help="Function to call (e.g., src.utils.mlflow_utils.create_mlflow.mlflow_main)"
    )
    args, unknown = arg_parser.parse_known_args()

    if args.function is None:
        logger.error("Function not provided!")
        sys.exit(1)

    config = read_config()

    try:
        spark = SparkSession.builder.getOrCreate()
        function_path = args.function.split('.')
        module_path = '.'.join(function_path[:-1])
        function_name = function_path[-1]

        module = importlib.import_module(module_path)
        function_to_call = getattr(module, function_name)

        logger.info(f"Calling function: {args.function}")
        function_to_call(spark, config)

    except (AttributeError, ModuleNotFoundError) as e:
        logger.error(f"Function {args.function} not found or module could not be imported")
        logger.error(f"Error: {e}")
        sys.exit(1)

    except Exception as e:
        logger.error(f"An error occurred: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
